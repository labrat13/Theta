namespace TappTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.testsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mProjectInfotestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectOpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pojectCloseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(292, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // testsToolStripMenuItem
            // 
            this.testsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mProjectInfotestToolStripMenuItem,
            this.logTestToolStripMenuItem,
            this.projectOpenToolStripMenuItem,
            this.pojectCloseToolStripMenuItem});
            this.testsToolStripMenuItem.Name = "testsToolStripMenuItem";
            this.testsToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.testsToolStripMenuItem.Text = "Tests";
            // 
            // mProjectInfotestToolStripMenuItem
            // 
            this.mProjectInfotestToolStripMenuItem.Name = "mProjectInfotestToolStripMenuItem";
            this.mProjectInfotestToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.mProjectInfotestToolStripMenuItem.Text = "MProjectInfo_test";
            this.mProjectInfotestToolStripMenuItem.Click += new System.EventHandler(this.mProjectInfotestToolStripMenuItem_Click);
            // 
            // logTestToolStripMenuItem
            // 
            this.logTestToolStripMenuItem.Name = "logTestToolStripMenuItem";
            this.logTestToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.logTestToolStripMenuItem.Text = "LogTest";
            this.logTestToolStripMenuItem.Click += new System.EventHandler(this.logTestToolStripMenuItem_Click);
            // 
            // projectOpenToolStripMenuItem
            // 
            this.projectOpenToolStripMenuItem.Name = "projectOpenToolStripMenuItem";
            this.projectOpenToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.projectOpenToolStripMenuItem.Text = "ProjectOpen";
            this.projectOpenToolStripMenuItem.Click += new System.EventHandler(this.projectOpenToolStripMenuItem_Click);
            // 
            // pojectCloseToolStripMenuItem
            // 
            this.pojectCloseToolStripMenuItem.Name = "pojectCloseToolStripMenuItem";
            this.pojectCloseToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.pojectCloseToolStripMenuItem.Text = "PojectClose";
            this.pojectCloseToolStripMenuItem.Click += new System.EventHandler(this.pojectCloseToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem testsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mProjectInfotestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectOpenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pojectCloseToolStripMenuItem;
    }
}

