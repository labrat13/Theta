using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Walk;

namespace TappTest
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Container
        /// </summary>
        private MEngine m_engine;
        public Form1()
        {
            InitializeComponent();
        }

        private void mProjectInfotestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MProjectInfo pi1 = new MProjectInfo();
            pi1.ContainerDefaultCellMode = MCellMode.Normal;
            pi1.ContainerServiceFlag = 77;
            pi1.ContainerState = 32768;
            pi1.CreationDate = DateTime.MaxValue;
            pi1.DatabaseName = "databaseName";
            pi1.DatabaseServerPath = "serverpath://path\\path\\path///path";
            pi1.DatabaseType = MDatabaseType.NoDatabase;
            pi1.ProjectDescription = "database < > ! @ # $ % ^&*( )~{ }[]`'\"|�description text ";
            pi1.EngineSubVersion = 77;
            pi1.EngineVersion = 55;
            pi1.LogDetailsFlags = 7;
            pi1.LogfileNumber = 33;
            pi1.DatabasePortNumber = 3333;
            pi1.ProjectFilePath = "C:\\prjfile.tapj"; //not stored to db
            pi1.ProjectId = 555;
            pi1.ProjectName = "projectName";
            pi1.SnapshotNumber = 456;
            pi1.DatabaseTimeout = 55;
            pi1.UseIntegratedSecurity = true;
            pi1.UserName = "username";
            pi1.UserPassword = "password";
            pi1.ContainerIsActiveFlag = true;
            //save to ProjectFilePath path
            pi1.Save();

            MProjectInfo pi2 = MProjectInfo.Load("C:\\prjfile.tapj");
            //check properties manually
            return;
           }
        /// <summary>
        /// Create project info object
        /// </summary>
        /// <returns>Returns fulfilled project info object</returns>
        private MProjectInfo createProjectInfo()
        {
            MProjectInfo pi1 = new MProjectInfo();
            pi1.ContainerDefaultCellMode = MCellMode.Normal;
            pi1.ContainerServiceFlag = 0;
            pi1.ContainerState = 0;
            pi1.CreationDate = DateTime.Now;
            pi1.DatabaseName = "testdbname";
            pi1.DatabaseServerPath = "localhost";
            pi1.DatabaseType = MDatabaseType.NoDatabase;
            pi1.ProjectDescription = "database description text";
            pi1.EngineSubVersion = 1;
            pi1.EngineVersion = 23;
            pi1.LogDetailsFlags = (uint) MLogMessageClass.All;
            pi1.LogfileNumber = 1;
            pi1.DatabasePortNumber = 0; //for using default values
            pi1.ProjectFilePath = "C:\\testprj.tapj";
            pi1.ProjectId = 1;
            pi1.ProjectName = "projectName";
            pi1.SnapshotNumber = 1;
            pi1.DatabaseTimeout = 60;
            pi1.UseIntegratedSecurity = true;
            pi1.UserName = "username";
            pi1.UserPassword = "password";
            pi1.ContainerIsActiveFlag = true;
            return pi1;
        }

        private void logTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(System.Reflection.MethodBase.GetCurrentMethod().ToString(), "CurrentFunctionName");
        }
        /// <summary>
        /// Show MessageBox for Exception
        /// </summary>
        /// <param name="ex"></param>
        private void ShowMessageBox(Exception ex)
        {
            MessageBox.Show(ex.ToString(), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        private void projectOpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                //fill info and create project file 
                MProjectInfo info = this.createProjectInfo();
                info.Save();
                //open project
                this.m_engine = MProject.ProjectOpen(info.ProjectFilePath);
            }
            catch (Exception ex)
            {
                ShowMessageBox(ex);
            }
            return;
        }
        /// <summary>
        /// ProjectClose test
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pojectCloseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_engine != null)
                    m_engine.ProjectManager.ProjectClose(false);
            }
            catch (Exception ex)
            {
                ShowMessageBox(ex);
            }
            return;         
        }
    }
}