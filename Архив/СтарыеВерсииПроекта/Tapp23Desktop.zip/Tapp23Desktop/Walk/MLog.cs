using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Walk
{
    /// <summary>
    /// ��������� �������� ���� �������
    /// </summary>
    /// <remarks></remarks>
    /// <seealso cref=""/>
    public class MLog
    {
        #region *** Fields ***
        /// <summary>
        /// Log file writer
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private StreamWriter m_writer;
        /// <summary>
        /// Container object
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private MEngine m_container;
        #endregion
        /// <summary>
        /// Default constructor
        /// </summary>
        /// <param name="engine">Container object</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MLog(MEngine engine)
        {
            m_container = engine;
            
        }

        #region *** Properties ***

        #endregion
        /// <summary>
        /// ������� ���������� ���� ��� ������ ���������.
        /// </summary>
        /// <param name="info"></param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        internal void Open(MProjectInfo info)
        {
            
            m_writer = new StreamWriter(this.getLogPathname(), true, Encoding.UTF8);
            m_writer.AutoFlush = true;
            //add message about session starts
        }

        /// <summary>
        /// ������� ���������� ����
        /// </summary>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        internal void Close()
        {
            //add message about session end
            //close log file
            if (m_writer != null)
            {
                m_writer.Flush();
                m_writer.Close();
            }
        }

        /// <summary>
        /// Insert text,  for simple debug only
        /// </summary>
        /// <param name="text"></param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void addSimpleText(String text)
        {
            m_writer.WriteLine(text);
        }

        /// <summary>
        /// Get pathname for log file opening
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        private string getLogPathname()
        {
            //name like ..\ProjectName.01.log
            string file = this.m_container.ProjectFile.getProjectName16();
            //add step number and ext
            file = String.Format("{0}.{1}.{2}", file, this.m_container.ProjectFile.LogfileNumber, MProject.m_LogFileExtension);
            //add full path
            string s = Path.Combine(this.m_container.ProjectManager.LogFolderPath, file);
            return s;
        }

        /// <summary>
        /// Get string representation of object.
        /// </summary>
        /// <returns>Return string representation of object.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public override string ToString()
        {
            throw new NotImplementedException();
        }

    }
}
