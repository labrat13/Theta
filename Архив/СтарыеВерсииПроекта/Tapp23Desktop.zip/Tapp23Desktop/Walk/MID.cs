using System;
using System.Collections.Generic;
using System.Text;

namespace Walk
{
    /// <summary>
    /// Item identifier
    /// </summary>
    /// <remarks></remarks>
    /// <seealso cref=""/>
    public class MID: ImSerializable, ICloneable
    {
        #region *** Fields ***
        /// <summary>
        /// Element identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private int m_elementid;
        /// <summary>
        /// Container identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private int m_containerid;
        #endregion

        /// <summary>
        /// �����������
        /// </summary>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MID()
        {
            m_elementid = 0;
            m_containerid = 0;
        }
        /// <summary>
        /// ����������� � �����������
        /// </summary>
        /// <param name="containerId">Container ID number</param>
        /// <param name="elementId">Element ID number</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MID(int containerId, int elementId)
        {
            m_containerid = containerId;
            m_elementid = elementId;
        }

        /// <summary>
        /// ����������� �����
        /// </summary>
        /// <param name="copy">Source object</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MID(MID copy)
        {
            m_elementid = copy.m_elementid;
            m_containerid = copy.m_containerid;
        }

        #region *** Properties ***
        /// <summary>
        /// Container identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public int ContainerId
        {
            get { return m_containerid; }
            set { m_containerid = value; }
        }
        /// <summary>
        /// Element identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public int ElementId
        {
            get { return m_elementid; }
            set { m_elementid = value; }
        }
        #endregion

        #region ImSerializable Members
        /// <summary>
        /// Serialize object data to binary stream
        /// </summary>
        /// <param name="writer">Binary writer for data</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void toBinary(System.IO.BinaryWriter writer)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Deserialize object data from binary stream
        /// </summary>
        /// <param name="reader">Binary reader for data</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void fromBinary(System.IO.BinaryReader reader)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Serialize object data to text stream
        /// </summary>
        /// <param name="writer">Text writer for data</param>
        /// <param name="withHex">True - include HEX representation of binary data.False - text representation only.</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void toText(System.IO.TextWriter writer, bool withHex)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Deserialize object data from text stream
        /// </summary>
        /// <param name="reader">Text reader for data</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void fromText(System.IO.TextReader reader)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region ICloneable Members
        /// <summary>
        /// ���������� ����� �������� �������.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public Object Clone()
        {
            MID res = new MID(this.m_containerid, this.m_elementid);
            return res;
        }

        #endregion

        /// <summary>
        /// NT-������� ��������� ������������� - ��� �������� ����������
        /// </summary>
        /// <param name="elementId">������������� ��������</param>
        /// <returns>���������� ��������� �������������.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public static MID CreateLocalID(int elementId)
        {
            return new MID(MEngine.CurrentContainer.ContainerIdNumber, elementId);
        }
        /// <summary>
        /// NT-���������, ��� ������������� ��������, �� ���� ����������� �������� ����������.
        /// ������������� ������ ����� �������� ������������������.
        /// </summary>
        /// <returns>Returns True if Id is local, False otherwise</returns>
        /// <remarks></remarks>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public bool IsLocalId()
        {
            return (m_containerid == MEngine.CurrentContainer.ContainerIdNumber);
        }

        ///// <summary>
        ///// Check that current Id is Temporary
        ///// </summary>
        ///// <returns>Returns True if Id is temporary, False otherwise</returns>
        //public bool isTemporaryId()
        //{
        //    return (m_elementid < 0);
        //}

        ///// <summary>
        ///// Check that specified element identifier is Temporary
        ///// </summary>
        ///// <param name="elementid">element id value</param>
        ///// <returns>Returns True if specified element id is Temporary element, False otherwise.</returns>
        //public static bool isTemporaryId(int elementid)
        //{
        //    return (elementid < 0);
        //}

        ///// <summary>
        ///// Check ordinal Id value and throw exception
        ///// </summary>
        //public void checkId()
        //{
        //    if (m_elementid == 0)
        //        throw new Exception("Invalid element identifier");
        //    else if((m_elementid == Int32.MaxValue) || (m_elementid == Int32.MinValue))
        //        throw new Exception("Too big cell identifier");
        //}

        ///// <summary>
        ///// Get new element id for new constant element
        ///// </summary>
        ///// <param name="maxId">max of existing constant element id</param>
        ///// <returns>Returns new element id for new constant element</returns>
        //public static int getNewConstId(int maxId)
        //{
        //    return maxId + 1;
        //}

        ///// <summary>
        ///// Get new element id for new temporary element
        ///// </summary>
        ///// <param name="maxId">max of existing temporary element id</param>
        ///// <returns>Returns new element id for new temporary element</returns>
        //public static int getNewTempId(int maxId)
        //{
        //    return maxId - 1;
        //}

        ///// <summary>
        ///// Return true if identifiers is equal
        ///// </summary>
        ///// <param name="tid">Compared identifier</param>
        ///// <returns>Returns True if identifiers is equals, False otherwise</returns>
        //public bool isEqual(MID tid)
        //{
        //    return ((tid.m_elementid == this.m_elementid) && (tid.m_containerid == this.m_containerid));
        //} 

        /// <summary>
        /// Get string representation of object
        /// </summary>
        /// <returns>Returns string representation of object, like 0:0</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public override string ToString()
        {
            return String.Format("{0}:{1}", m_containerid, m_elementid);
        }


        /// <summary>
        /// NT-Unpack element identifier from U64 value
        /// </summary>
        /// <param name="id">Packed to U64 identifier</param>
        /// <returns>Returns unpacked element identifier.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public static MID FromU64(UInt64 id)
        {
            Int32 elementid = (Int32)(id & 0xFFFFFFFF);
            Int32 containerid = (Int32)(id >> 32);
            return new MID(containerid, elementid);
        }
        /// <summary>
        /// NT-Pack element identifier to U64 value
        /// </summary>
        /// <returns>Returns packed element identifier as U64 value.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public UInt64 ToU64()
        {
            UInt64 res = 0;
            res = res | ((UInt64)((UInt32)this.m_containerid));
            res = res << 32;
            res = res | ((UInt64)((UInt32)this.m_elementid));
            return res;
        }
        ///// <summary>
        ///// NR-Extract Element ID from U64 value
        ///// </summary>
        ///// <param name="p">U64 id value</param>
        ///// <returns>Element Id part of U64 argument value</returns>
        //internal static int ElementIdFromU64(UInt64 p)
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}


    }
}
