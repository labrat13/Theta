using System;
using System.Collections.Generic;
using System.Text;

namespace Walk
{
    /// <summary>
    /// ��������� ������, ����������� � ������ ����������.
    /// </summary>
    /// <remarks></remarks>
    /// <seealso cref=""/>
    public class MLinkCollection
    {
        #region *** Fields ***
        /// <summary>
        /// List of links
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private List<MLink> m_items;

        #endregion
        /// <summary>
        /// Default constructor
        /// </summary>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MLinkCollection()
        {
            m_items = new List<MLink>();
        }

        #region *** Properties ***
        /// <summary>
        /// Get list of links in collection
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public List<MLink> Items
        {
            get
            {
                return m_items;
            }
        }
        /// <summary>
        /// Get count of links in collection
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public int Count
        {
            get
            {
                return m_items.Count;
            }
        }
        #endregion

        /// <summary>
        /// Get string representation of object.
        /// </summary>
        /// <returns>Return string representation of object.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public override string ToString()
        {
            throw new NotImplementedException();
        }

    }
}
