using System;
using System.Collections.Generic;
using System.Text;

namespace Walk
{
    /// <summary>
    /// ��������� ����������
    /// </summary>
    /// <remarks></remarks>
    /// <seealso cref=""/>
    public enum MEngineState
    {
        /// <summary>
        /// Unknown state
        /// </summary>
        Unknown = 0,
        /// <summary>
        /// Engine is opened and ready to work
        /// </summary>
        Open = 1,
        /// <summary>
        /// Engine is inactive
        /// </summary>
        Closed = 2,
        /// <summary>
        /// Engine is brocken
        /// </summary>
        Broken = 3,
        /// <summary>
        /// Engine executes some operations. Wait for Open state.
        /// </summary>
        Executing = 4,
    }
}
