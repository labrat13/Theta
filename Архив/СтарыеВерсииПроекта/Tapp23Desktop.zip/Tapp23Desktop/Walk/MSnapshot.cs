using System;
using System.Collections.Generic;
using System.Text;

namespace Walk
{
    /// <summary>
    /// ��������� ������� �� �������� �������
    /// </summary>
    /// <remarks></remarks>
    /// <seealso cref=""/>
    public class MSnapshot
    {
        #region *** Fields ***
        /// <summary>
        /// Container object
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private MEngine m_container;
        #endregion
        /// <summary>
        /// Default constructor
        /// </summary>
        /// <param name="engine">Container object</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MSnapshot(MEngine engine)
        {
            m_container = engine;
        }

        #region *** Properties ***

        #endregion
        /// <summary>
        /// Open manager
        /// </summary>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void Open(MProjectInfo info)
        {
            //throw new NotImplementedException(); - called
        }
        /// <summary>
        /// Close manager
        /// </summary>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void Close()
        {
            //throw new NotImplementedException(); - called
        }
        /// <summary>
        /// Get string representation of object.
        /// </summary>
        /// <returns>Return string representation of object.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public override string ToString()
        {
            return base.ToString();
        }

    }
}
