using System;
using System.Collections.Generic;
using System.Text;

namespace Walk
{
    /// <summary>
    /// ������������ ��������� � ����� ������ ��� ���� ��������� �����.
    /// </summary>
    /// <remarks></remarks>
    /// <seealso cref=""/>
    public abstract class MCell : ImElement, ImSerializable
    {
        #region *** Fields ***

        #endregion
        /// <summary>
        /// �����������
        /// </summary>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MCell()
        {
            throw new NotImplementedException();
        }

        #region *** Properties ***

        #endregion

        /// <summary>
        /// Get string representation of object.
        /// </summary>
        /// <returns>Return string representation of object.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public override string ToString()
        {
            throw new NotImplementedException();
        }


        #region ImElement Members
        /// <summary>
        /// ������������� ��������.
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public MID ElementId
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        /// <summary>
        /// ������ ����� ��������. ��� ����� �� ��������������.
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public string ElementName
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        /// <summary>
        /// ������ �������� ��������
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public string ElementDescription
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        /// <summary>
        /// ���� ���������� ��������
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public bool ElementIsActive
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        /// <summary>
        /// ��������� ��������, ������������ � ��������� ��������� (����� � �����,  ������������ � ��� �����)
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public int ElementServiceValue
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
        /// <summary>
        /// ��������� ������, �����, ����������.
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public MID ElementState
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        #endregion

        #region ImSerializable Members
        /// <summary>
        /// Serialize object data to binary stream
        /// </summary>
        /// <param name="writer">Binary writer for data</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void toBinary(System.IO.BinaryWriter writer)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Deserialize object data from binary stream
        /// </summary>
        /// <param name="reader">Binary reader for data</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void fromBinary(System.IO.BinaryReader reader)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Serialize object data to text stream
        /// </summary>
        /// <param name="writer">Text writer for data</param>
        /// <param name="withHex">True - include HEX representation of binary data.False - text representation only.</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void toText(System.IO.TextWriter writer, bool withHex)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Deserialize object data from text stream
        /// </summary>
        /// <param name="reader">Text reader for data</param>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public void fromText(System.IO.TextReader reader)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
