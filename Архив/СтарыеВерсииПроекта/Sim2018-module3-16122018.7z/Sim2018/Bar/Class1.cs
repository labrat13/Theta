﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar
{
    public class Class1
    {
    }
}
