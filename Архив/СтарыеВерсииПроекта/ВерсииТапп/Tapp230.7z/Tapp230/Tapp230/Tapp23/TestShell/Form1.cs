﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Mary;

namespace TestShell
{
    public partial class TestShellForm : Form
    {
        /// <summary>
        /// Container object
        /// </summary>
        internal MEngine m_container;

        public TestShellForm()
        {
            InitializeComponent();
            m_container = null;
        }


        /// <summary>
        /// NewProject menu item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                NewProjectForm npf = new NewProjectForm();
                if (npf.ShowDialog(this) == DialogResult.OK)
                {
                    //create new project
                    this.toolStripStatusLabel1.Text = String.Format("Creating new project {0}", npf.ProjectName);
                    Application.DoEvents();
                    MEngine.ProjectCreate(npf.ProjectName, npf.ProjectDescription, npf.ParentFolder, npf.SqlServerPath, npf.DatabaseName, npf.UserName, npf.UserPassword, 30);
                    //show any exception here...
                    this.toolStripStatusLabel1.Text = String.Format("Project {0} successfully created. You can open this project now.", npf.ProjectName);
                    playBeep();
                }
            }
            catch (Exception ex)
            {
                ShowExceptionMessageBox(ex);
            }
        }

        private void ShowExceptionMessageBox(Exception ex)
        {
            MessageBox.Show(this, ex.Message, String.Format("TestShell - {0}", ex.GetType().Name), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        /// <summary>
        /// Menu Project-Exit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Menu Project-Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = createFileDialog("Select project file for Delete");
                if (ofd.ShowDialog(this) == DialogResult.OK)
                {
                    this.toolStripStatusLabel1.Text = String.Format("Delete project {0}", ofd.FileName);
                    Application.DoEvents();
                    MEngine.ProjectDelete(ofd.FileName);
                    this.toolStripStatusLabel1.Text = String.Format("Project {0} successfully deleted.", ofd.SafeFileName);
                    playBeep();
                }
            }
            catch (Exception ex)
            {
                ShowExceptionMessageBox(ex);
            }
            return;
        }

        /// <summary>
        /// Creates OpenFileDialog for project file opening
        /// </summary>
        /// <param name="Title"></param>
        /// <returns></returns>
        private OpenFileDialog createFileDialog(string Title)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            ofd.Multiselect = false;
            ofd.RestoreDirectory = true;
            ofd.Title = Title;
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            ofd.DereferenceLinks = true; //use shortcuts for project opening
            ofd.Filter = "Tapp project file(.tapj)|*.tapj|All files|*.*";
            ofd.FilterIndex = 1;
            return ofd;
        }

        /// <summary>
        /// Menu Project-Open
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = createFileDialog("Select project file for Open");
                if (ofd.ShowDialog(this) == DialogResult.OK)
                {
                    this.toolStripStatusLabel1.Text = String.Format("Open project {0}", ofd.FileName);
                    Application.DoEvents();
                    m_container = MEngine.ProjectOpen(ofd.FileName);
                    this.toolStripStatusLabel1.Text = String.Format("Project {0} successfully opened.", ofd.SafeFileName);
                    playBeep();
                }
            }
            catch (Exception ex)
            {
                ShowExceptionMessageBox(ex);
            }
            return;
        }

        /// <summary>
        /// Success sound
        /// </summary>
        public static void playBeep()
        {
            System.Media.SoundPlayer sp = new System.Media.SoundPlayer(Properties.Resources.ding);
            sp.Play();
            
        }
        /// <summary>
        /// Error sound
        /// </summary>
        public static void playError()
        {
            System.Media.SoundPlayer sp = new System.Media.SoundPlayer(Properties.Resources.chord);
            sp.Play();
        }

        /// <summary>
        /// Completion sound
        /// </summary>
        public static void playClick()
        {
            System.Media.SoundPlayer sp = new System.Media.SoundPlayer(Properties.Resources.click);
            sp.Play();
        }

        /// <summary>
        /// Menu Project-Close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //check project opened
            if (m_container == null)
            {
                this.toolStripStatusLabel1.Text = "No opened projects";
                playError();
                return;
            }
            try
            {
                //closing project
                string prjname = m_container.ProjectManager.ProjectFile.ProjectName;
                this.toolStripStatusLabel1.Text = String.Format("Close project {0}", prjname);
                Application.DoEvents();
                //prompt user for save before close
                DialogResult dr = MessageBox.Show(this, "Do you want to save project before closing?", "Closing project", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if ((dr != DialogResult.No) && (dr != DialogResult.Yes))
                {
                    this.toolStripStatusLabel1.Text = String.Format("Project {0} closing cancelled", prjname);
                    return;
                }
                bool save = false;
                if (dr == DialogResult.Yes) save = true;
                //close project
                m_container.ProjectClose(save);
                this.toolStripStatusLabel1.Text = String.Format("Project {0} closed", prjname);
                m_container = null;
                playBeep();
            }
            catch (Exception ex)
            {
                ShowExceptionMessageBox(ex);
            }
            return;
        }

        /// <summary>
        /// Menu Project-Clear
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //check project opened
            if (m_container == null)
            {
                this.toolStripStatusLabel1.Text = "No opened projects";
                playError();
                return;
            }
            try
            {
                string prjname = m_container.ProjectManager.ProjectFile.ProjectName;
                //prompt confirmation to clear project
                DialogResult dr = MessageBox.Show(this, String.Format("Do you want to clear {0} project?", prjname), "Clear project", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    m_container.ProjectClear();
                    this.toolStripStatusLabel1.Text = String.Format("Project {0} cleared", prjname);
                    playBeep();

                }
            }
            catch (Exception ex)
            {
                ShowExceptionMessageBox(ex);
            }
        }


        /// <summary>
        /// Menu Test-LoadCsv
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loadCsvToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //создаем структуру ячеек со связями
            //tableCell -> colsCell, rowsCell
            //colsCell -> columns
            //rowsCell -> rows
            //row -> row fields
            //column -> row fields
            //это будет много связей, и много ячеек.

            //установить здесь тип создаваемых ячеек - чтобы померить скорость для каждого типа
            MCellMode cellMode = MCellMode.DelaySave;
            //идентификаторы осей связей
            const int Axis1 = 1;
            const int Axis2 = 2;
            const int Axis3 = 3;
            const int Axis4 = 4;

            //open csv file
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Open csv file:";
            ofd.Filter = "csv|*.csv";
            if (ofd.ShowDialog() != DialogResult.OK) return;

            //parse file
            System.IO.StreamReader sr = new System.IO.StreamReader(ofd.OpenFile(), Encoding.Default);
            string row = sr.ReadLine();
            // ; is delimiter
            string[] headers = row.Split(new char[] { ';' });
            //this strings is column headers
            int colNum = headers.Length; //columns counter
            int rowNum = 0; //rows counter

            //create table cell
            MCell tableCell = this.m_container.CellCreate(cellMode);
            tableCell.Name = "Table";
            //create column collection cell
            MCell colsCell = this.m_container.CellCreate(cellMode);
            colsCell.Name = "Column collection";
            colsCell.S1_createLink(new MID(Axis1), MAxisDirection.Up, tableCell);
            //create row collection cell
            MCell rowsCell = this.m_container.CellCreate(cellMode);
            rowsCell.Name = "Row collection";
            rowsCell.S1_createLink(new MID(Axis1), MAxisDirection.Up, tableCell);
            //create array of column cells
            MCell[] columns = new MCell[colNum];
            for (int i = 0; i < colNum; i++)
            {
                MCell tt = this.m_container.CellCreate(cellMode);
                tt.Name = headers[i];
                tt.S1_createLink(new MID(Axis2), MAxisDirection.Up, colsCell);
                columns[i] = tt;
            }
            //create row cells
            while (!sr.EndOfStream)
            {
                rowNum++;
                //show rows number
                if ((rowNum & 1023) == 0)
                {
                    this.toolStripStatusLabel1.Text = String.Format("Import row {0}",rowNum.ToString());
                    Application.DoEvents();
                }
                row = sr.ReadLine();
                headers = row.Split(new char[] { ';' });
                if (headers.Length != colNum)
                {
                    MessageBox.Show(String.Format("Invalid record format: {0} fields in {1} \n {2}", headers.Length, colNum, row));
                    return; //exit from loop
                }
                else
                {
                    //create row cell
                    MCell rc = this.m_container.CellCreate(cellMode);
                    rc.Name = rowNum.ToString();
                    //link to row collection cell
                    rc.S1_createLink(new MID(Axis2), MAxisDirection.Up, rowsCell);
                    //create cells
                    for (int i = 0; i < colNum; i++)
                    {
                        //номер столбца в файле будет типом ячейки
                        MCell column = columns[i];
                        //Заголовки столбцов из ксв не пишем - их потом как нибудь...
                        //данные ячейки тоже пока не трогаем - нет конвертера для строк
                        //Надо бы сделать конвертер и задействовать еще и поле данных ячейки
                        MCell mc = this.m_container.CellCreate(cellMode);
                        mc.Name = headers[i];//Имя ячейки - данные
                        mc.TypeId = new MID(column.CellID.ID);  //Тип ячейки - cellid столбца, то есть тип данных в данном случае.

                        //create links to row cell
                        mc.S1_createLink(new MID(Axis3), MAxisDirection.Up, rc);
                        //create links to column cell
                        mc.S1_createLink(new MID(Axis4), MAxisDirection.Up, column);
                    }
                }
            }  //end while
            sr.Close();
            playBeep();
            this.toolStripStatusLabel1.Text = String.Format("File {0} imported", ofd.SafeFileName);

            //save cells - check time
            m_container.SaveAllDelaySavedCells();

            return;
        }

        /// <summary>
        /// Menu Snapshot-Create
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void createSnapshotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //check project opened
            if (m_container == null)
            {
                this.toolStripStatusLabel1.Text = "No opened projects";
                playError();
                return;
            }
            try
            {
                this.toolStripStatusLabel1.Text = "Creating snapshot...";
                Application.DoEvents();
                m_container.SnapshotFullCreate();

                this.toolStripStatusLabel1.Text = "Snapshot created";
                playBeep();
            }
            catch (Exception ex)
            {
                ShowExceptionMessageBox(ex);
            }
            return;



        }

        /// <summary>
        /// Menu Snapshot-Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loadSnapshotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //check project opened
            if (m_container == null)
            {
                this.toolStripStatusLabel1.Text = "No opened projects";
                playError();
                return;
            }
            try
            {
                //Show dialog to open snapshot file
                OpenFileDialog ofd = new OpenFileDialog();
                //ofd.Multiselect = false; by default
                ofd.Title = "Select snapshot file";
                ofd.InitialDirectory = m_container.ProjectManager.SnapshotFolderPath;
                ofd.DereferenceLinks = true; //use shortcuts for opening
                ofd.Filter = "Tapp snapshot file(.step)|*.step|All files|*.*";
                ofd.FilterIndex = 1;
                if (ofd.ShowDialog(this) != DialogResult.OK) return;

                this.toolStripStatusLabel1.Text = String.Format("Loading snapshot {0}", ofd.FileName);
                Application.DoEvents();
                m_container.SnapshotFullLoad(ofd.FileName);

                this.toolStripStatusLabel1.Text = String.Format("Snapshot {0} loaded", ofd.FileName);
                playBeep();
            }
            catch (Exception ex)
            {
                ShowExceptionMessageBox(ex);
            }
            return;
        }

        private void formsTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NavigatorForm.LaunchNavigator(m_container);
        }

    }
}
