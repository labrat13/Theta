﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Mary;

namespace Tapp23
{
    public class CellShape
    {
        public string m_labelText;
        public SizeF m_labelSize;
        public Rectangle m_cellRect;
        public MCell m_Cell;
        public Brush m_Brush;
        public Pen m_Pen;

        public CellShape(MCell cell, Point pt)
        {
            m_Cell = cell;
            m_cellRect = new Rectangle(pt, new Size(100, 50));
            m_Brush = Brushes.Black;
            m_Pen = Pens.Black;
        }

        public void Draw(System.Drawing.Graphics g, Font f)
        {
            //при первом запуске настроить свойства
            if (m_labelText == null)
            {
                //get label size
                m_labelText = m_Cell.ToString();
                m_labelSize = g.MeasureString(m_labelText, f, 200);
                //get cell rect and set up size
                Size s = m_labelSize.ToSize();
                s.Height += 10;
                s.Width += 10;
                m_cellRect.Size = s;
                //set up label rect relative to cell rect
            }
            //set up label rect relative to cell rect
            g.DrawRectangle(m_Pen, m_cellRect);
            g.DrawString(m_labelText, f, m_Brush, new RectangleF(new PointF(5.0F + m_cellRect.X, 5.0F + m_cellRect.Y), m_labelSize)); 
        }
        /// <summary>
        /// Move cell shape to specified position
        /// </summary>
        /// <param name="pt"></param>
        public void MoveTo(Point pt)
        {
            m_cellRect.Location = pt;
        }

        /// <summary>
        /// Get point for link
        /// </summary>
        /// <returns></returns>
        internal Point getShapeCenter()
        {
           //get center of cell
            Point res = new Point();
            res.X = m_cellRect.X + m_cellRect.Width / 2;
            res.Y = m_cellRect.Y + m_cellRect.Height / 2;
            return res;
        }

        /// <summary>
        /// Get point for link
        /// </summary>
        /// <returns></returns>
        internal Point getLinkPoint()
        {
            //get center of cell
            Point res = getShapeCenter();
            Random r = new Random();
            int t = r.Next(50);
            res.X += t - 10;
            t = r.Next(50);
            res.Y += t - 10;
            return res;
        }
    }
}
