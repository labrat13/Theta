﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mary;
using System.Data.SqlClient;
using System.IO;
using System.Media;

namespace Tapp23
{
    public partial class Form1 : Form
    {
        public Mary.MEngine m_container;
        private MProjectFile m_file;
        private Dictionary<int,CellShape> m_cellShapes;
        private List<LinkShape> m_linkShapes;
        private Font m_font;
        private Brush m_normBrush;
        private Brush m_selBrush;
        private Pen m_normPen;
        private Pen m_selPen;

        //drag operation
        private CellShape m_selShape;
        private bool m_dragEnable;
        private bool m_drawShapes;
        
        public Form1()
        {
            InitializeComponent();
            m_cellShapes = new Dictionary<int, CellShape>();
            m_linkShapes = new List<LinkShape>();
            m_font = new Font(FontFamily.GenericMonospace, 10.0F);
            m_normBrush = Brushes.Black;
            m_normPen = Pens.Black;
            m_selBrush = Brushes.Blue; ;
            m_selPen = Pens.Blue;
            m_dragEnable = false;
            m_drawShapes = false; //false prevent drawing container

        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Устаревший код только для примера новых тестов.
            
            //MDbLayer mdb = new MDbLayer();
            //SqlConnectionStringBuilder scb = new SqlConnectionStringBuilder();
            //scb.ConnectTimeout = 30;
            //scb.DataSource = ".";
            //scb.IntegratedSecurity = false;
            //scb.InitialCatalog = "maryland";
            //scb.Password = "astalavista";
            //scb.UserID = "astra";
            //mdb.ConnectionString = scb.ConnectionString;
            //mdb.Open();
            //mdb.Close();



            MEngine me = this.m_container;
            //test link creation
            MLink resLink = null;
            //create cells
            MCell cellA = me.CellCreate(MCellMode.Compact);
            cellA.Name = "Source MCellA";
            MCell cellA0 = me.CellCreate(MCellMode.Compact);
            cellA0.Name = "Target MCellA";                  
            MCell cellB = me.CellCreate(MCellMode.Normal);
            cellB.Name = "Source MCellB";
            MCell cellB0 = me.CellCreate(MCellMode.Normal);
            cellB0.Name = "Target MCellB";
            MCell cellBds = me.CellCreate(MCellMode.DelaySave);
            cellBds.Name = "Source MCellBds";
            MCell cellBds0 = me.CellCreate(MCellMode.DelaySave);
            cellBds0.Name = "Target MCellBds";
            MCell cellBt = me.CellCreate(MCellMode.Temporary);
            cellBt.Name = "Source MCellBt";
            MCell cellBt0 = me.CellCreate(MCellMode.Temporary);
            cellBt0.Name = "Target MCellBt";
            //create links
            MID ax;
            // Down links creation 
            MAxisDirection dir = MAxisDirection.Down;
            ax = new MID(1);
            resLink = cellA.S1_createLink(ax, dir, cellA0);
            resLink = cellA.S1_createLink(ax, dir, cellB);
            resLink = cellA.S1_createLink(ax, dir, cellBds);
            resLink = cellA.S1_createLink(ax, dir, cellBt);

            ax = new MID(2);
            resLink = cellB.S1_createLink(ax, dir, cellA);
            resLink = cellB.S1_createLink(ax, dir, cellB0);
            resLink = cellB.S1_createLink(ax, dir, cellBds);
            resLink = cellB.S1_createLink(ax, dir, cellBt);

            ax = new MID(3);
            resLink = cellBds.S1_createLink(ax, dir, cellA);
            resLink = cellBds.S1_createLink(ax, dir, cellB);
            resLink = cellBds.S1_createLink(ax, dir, cellBds0);
            resLink = cellBds.S1_createLink(ax, dir, cellBt);

            ax = new MID(4);
            resLink = cellBt.S1_createLink(ax, dir, cellA);
            resLink = cellBt.S1_createLink(ax, dir, cellB);
            resLink = cellBt.S1_createLink(ax, dir, cellBds);
            resLink = cellBt.S1_createLink(ax, dir, cellBt0);

            // Up links creation 
            dir = MAxisDirection.Up;
            ax = new MID(1);
            resLink = cellA.S1_createLink(ax, dir, cellA0);
            resLink = cellA.S1_createLink(ax, dir, cellB);
            resLink = cellA.S1_createLink(ax, dir, cellBds);
            resLink = cellA.S1_createLink(ax, dir, cellBt);

            ax = new MID(2);
            resLink = cellB.S1_createLink(ax, dir, cellA);
            resLink = cellB.S1_createLink(ax, dir, cellB0);
            resLink = cellB.S1_createLink(ax, dir, cellBds);
            resLink = cellB.S1_createLink(ax, dir, cellBt);

            ax = new MID(3);
            resLink = cellBds.S1_createLink(ax, dir, cellA);
            resLink = cellBds.S1_createLink(ax, dir, cellB);
            resLink = cellBds.S1_createLink(ax, dir, cellBds0);
            resLink = cellBds.S1_createLink(ax, dir, cellBt);

            ax = new MID(4);
            resLink = cellBt.S1_createLink(ax, dir, cellA);
            resLink = cellBt.S1_createLink(ax, dir, cellB);
            resLink = cellBt.S1_createLink(ax, dir, cellBds);
            resLink = cellBt.S1_createLink(ax, dir, cellBt0);
            ////is log functional?
            //me.Log.addSomeText("Test cell UnLoading 310312");
            //// put all cells and links to log
            //LogContainer(me); //output container, links and cells
            //this.Refresh();


            ////выгрузка ячеек со связями по одной за тест
            //me.S1_intUnloadCell(cellBt);

            //// put all cells and links to log
            //LogContainer(me); //output container, links and cells

            ////загрузка ячейки со связями
            //me.S1_intGetCell(cellBt.CellID);

            //// put all cells and links to log
            //LogContainer(me); //output container, links and cells

            ////Тест создания, получения, изменения свойств и выгрузки ячеек. 
            //MCell ce = me.S1_intCreateCell(MCellMode.Compact);
            //ce.CreaTime = DateTime.Now;
            //ce.Description = "test cell properties";
            //ce.isActive = false;
            //ce.Name = "test MCellA cell";
            //ce.ReadOnly = true;
            //ce.ServiceFlag = 777;
            //ce.State = new MID(33);
            //ce.TypeId = new MID(39);
            //ce.Value = new Byte[] { 0x22, 0x33, 0x44, 0x55 };
            //ce.ValueTypeId = new MID(678);
            //MCell c1 = ce;
            ////
            //ce = me.S1_intCreateCell(MCellMode.Normal);
            //ce.CreaTime = DateTime.Now;
            //ce.Description = "test cell properties";
            //ce.isActive = false;
            //ce.Name = "test MCellB cell";
            //ce.ReadOnly = true;
            //ce.ServiceFlag = 777;
            //ce.State = new MID(33);
            //ce.TypeId = new MID(39);
            //ce.Value = new Byte[] { 0x22, 0x33, 0x44, 0x55 };
            //ce.ValueTypeId = new MID(678);
            //MCell c2 = ce;
            ////
            //ce = me.S1_intCreateCell(MCellMode.DelaySave);
            //ce.CreaTime = DateTime.Now;
            //ce.Description = "test cell properties";
            //ce.isActive = false;
            //ce.Name = "test MCellBds cell";
            //ce.ReadOnly = true;
            //ce.ServiceFlag = 777;
            //ce.State = new MID(33);
            //ce.TypeId = new MID(39);
            //ce.Value = new Byte[] { 0x22, 0x33, 0x44, 0x55 };
            //ce.ValueTypeId = new MID(678);
            //MCell c3 = ce;
            ////
            //ce = me.S1_intCreateCell(MCellMode.Temporary);
            //ce.CreaTime = DateTime.Now;
            //ce.Description = "test cell properties";
            //ce.isActive = false;
            //ce.Name = "test MCellBt cell";
            //ce.ReadOnly = true;
            //ce.ServiceFlag = 777;
            //ce.State = new MID(33);
            //ce.TypeId = new MID(39);
            //ce.Value = new Byte[] { 0x22, 0x33, 0x44, 0x55 };
            //ce.ValueTypeId = new MID(678);
            //MCell c4 = ce;
            ////cell get
            //ce = me.S1_intGetCell(c1.CellID);
            //ce = me.S1_intGetCell(c2.CellID);
            //ce = me.S1_intGetCell(c3.CellID);
            //ce = me.S1_intGetCell(c4.CellID);
            ////cell unload
            //me.S1_intUnloadCell(c1.CellID);
            //me.S1_intUnloadCell(c2.CellID);
            //me.S1_intUnloadCell(c3.CellID);
            //me.S1_intUnloadCell(c4.CellID);
            ////cell loading
            //ce = me.S1_intGetCell(c1.CellID);
            //ce = me.S1_intGetCell(c2.CellID);
            //ce = me.S1_intGetCell(c3.CellID);
            //ce = me.S1_intGetCell(c4.CellID);


            me.Log.addSomeText("Test finished");

            ////test - create 10000 cells
            //MCell res;
            //MessageBox.Show("Test started");
            //DateTime t1 = DateTime.Now;
            //for (int i = 0; i < 10000; i++)
            //    res = me.S1_intCreateCell(MCellMode.Compact);
            ////check time and memory size
            //DateTime t2 = DateTime.Now;
            //TimeSpan tt = t2.Subtract(t1);
            //MessageBox.Show(tt.ToString());


            ////MCell ce = me.GetCell(1);
            //// cell search test
            ////create template
            //MCellTemplate t = new MCellTemplate();
            //t.isActive = true;
            //t.TypeId = new MID(1);
            ////go with mcellb
            //MCellCollection co = me.GetCellsInTable(t, true);
            ////create test data array for Value cell field
            //byte[] dat = { 0x44, 0x33, 0x22, 0x11, 0x00 };

            //foreach (MCell item in co.Items)
            //{
            //    item.Value = dat;
            //}

            ////filter results
            //t.Value = dat;
            //MCellCollection c0 = me.GetCellsInTable(t, true);//must be equal co
            
            
            //MCellCollection c1 = c0.S1_getCells(t);//must be equal c0
            //t.Value = new Byte[] { 0x44, 0x33, 0x22, 0x11, 0x01 };//another data sample
            //MCellCollection c2 = c0.S1_getCells(t);    //must be dummy        

        }

        /// <summary>
        /// write link collection to log
        /// </summary>
        /// <param name="log"></param>
        /// <param name="links"></param>
        private void LogLinks(MLog log, MLinkCollection links)
        {
            foreach (MLink li in links.Items)
                log.addSomeText(li.ToString());
        }

        private void LogContainer(MEngine me)
        {
            me.Log.addSomeText(me.ToString());
            me.Log.addSomeText("Container links list");
            LogLinks(me.Log, me.Links);
            me.Log.addSomeText("Container cells list");
            foreach(MCell cell in me.Cells.Items)
                LogCell(me.Log, cell);
            me.Log.addSomeText("Container output complete");



        }

        private void LogCell(MLog log, MCell cell)
        {
            log.addSomeText(cell.ToString());
            log.addSomeText("Links");
            LogLinks(log, cell.Links);
            log.addSomeText("CellSection output complete");
        }

        private void parseDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //создаем структуру ячеек со связями
            //tableCell -> colsCell, rowsCell
            //colsCell -> columns
            //rowsCell -> rows
            //row -> row fields
            //column -> row fields
            //это будет много связей, и много ячеек.


            //open csv file
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Open csv file:";
            ofd.Filter = "csv|*.csv";
            if (ofd.ShowDialog() != DialogResult.OK) return;
            //parse file
            StreamReader sr = new StreamReader(ofd.OpenFile(), Encoding.Default);
            string row = sr.ReadLine();
            // ; is delimiter
            string[] sar = row.Split(new char[] { ';' });
            //this strings is column headers
            int num = sar.Length; //columns number
            int rowNum = 0; //rows counter
            MCellMode cellMode = MCellMode.Temporary;
            //create table cell
            MCell tableCell = this.m_container.CellCreate(cellMode);
            tableCell.Name = "Table";
            //create column collection cell
            MCell colsCell = this.m_container.CellCreate(cellMode);
            colsCell.Name = "Column collection";
            colsCell.S1_createLink(new MID(1), MAxisDirection.Up, tableCell);
            //create row collection cell
            MCell rowsCell = this.m_container.CellCreate(cellMode);
            rowsCell.Name = "Row collection";
            rowsCell.S1_createLink(new MID(1), MAxisDirection.Up, tableCell);
            //create array of column cells
            MCell[] columns = new MCell[num];
            for (int i = 0; i < num; i++)
            {
                MCell tt = this.m_container.CellCreate(cellMode);
                tt.Name = sar[i];
                tt.S1_createLink(new MID(1), MAxisDirection.Up, colsCell);
                columns[i] = tt;
            }
            //create row cells
            while (!sr.EndOfStream)
            {
                rowNum++;
                //show rows number
                if ((rowNum & 1023) == 0)
                {
                    this.toolStripStatusLabel1.Text = rowNum.ToString();
                    Application.DoEvents();

                }
                row = sr.ReadLine();
                sar = row.Split(new char[] { ';' });
                if (sar.Length != num)
                {
                    MessageBox.Show(String.Format("Invalid record format: {0} fields in {1} \n {2}", sar.Length, num, row));
                    return; //exit from loop
                }
                else
                {
                    //create row cell
                    MCell rc = this.m_container.CellCreate(cellMode);
                    rc.Name = rowNum.ToString();
                    //link to row collection cell
                    rc.S1_createLink(new MID(1), MAxisDirection.Up, rowsCell);
                    //create cells
                    for (int i = 0; i < num; i++)
                    {
                        //номер столбца в файле будет типом ячейки
                        MCell column = columns[i];
                        //Заголовки столбцов из ксв не пишем - их потом как нибудь...
                        //данные ячейки тоже пока не трогаем - нет конвертера для строк
                        //Надо бы сделать конвертер и задействовать еще и поле данных ячейки
                        MCell mc = this.m_container.CellCreate(cellMode);
                        mc.Name = sar[i];//Имя ячейки - данные
                        mc.TypeId = new MID(column.CellID.ID);  //Тип ячейки - cellid столбца, то есть тип данных в данном случае.

                        //create links to row cell
                        mc.S1_createLink(new MID(1), MAxisDirection.Up, rc);
                        //create links to column cell
                        mc.S1_createLink(new MID(2), MAxisDirection.Up, column);
                    }
                }
            }  //end while
            sr.Close();

        }





        private void panel_view_Paint(object sender, PaintEventArgs e)
        {
            if (m_drawShapes == false) return; //to prevent shape drawing
            if((m_container == null) || (m_container.Cells.Count == 0)) return;

            e.Graphics.ResetClip();
            int x = 10; int y = 10;

            //add new shapes to collection
            foreach (MCell cell in m_container.Cells.Items)
            {
                if (!m_cellShapes.ContainsKey(cell.CellID.ID))
                {
                    CellShape cs = new CellShape(cell, new Point(x, y));
                    cs.m_Pen = this.m_normPen;
                    cs.m_Brush = this.m_normBrush;
                    m_cellShapes.Add(cell.CellID.ID, cs);
                    y += 10;
                }
            }
            //draw all existing cell shapes, remove non-existing
            foreach (CellShape cs in m_cellShapes.Values)
            {
                if (m_container.Cells.S1_containsCell(cs.m_Cell.CellID))
                    cs.Draw(e.Graphics, m_font);
                else m_cellShapes.Remove(cs.m_Cell.CellID.ID);
            }
            //create and draw cell links
            foreach (CellShape cs in m_cellShapes.Values)
            {
                foreach(MLink lin in cs.m_Cell.Links.Items)
                {
                    LinkShape ls = new LinkShape(lin,m_cellShapes[lin.upCellID.ID].getLinkPoint(), m_cellShapes[lin.downCellID.ID].getLinkPoint() );
                    if (!m_linkShapes.Contains(ls))
                    {
                        m_linkShapes.Add(ls);
                        ls.Draw(e.Graphics);
                    }
                }
            }

        }

        /// <summary>
        /// Open project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.toolStripStatusLabel1.Text = "Opening container...";
            //Show dialog to open project file
            OpenFileDialog ofd = new OpenFileDialog();
            //ofd.Multiselect = false; by default
            ofd.Title = "Open project file";
            ofd.DereferenceLinks = true; //use shortcuts for project opening
            ofd.Filter = "Tapp projectfile(.tapj)|*.tapj|All files|*.*";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog(this) != DialogResult.OK) return;
            //else

            //get project file, load settings, create connection string and open container
            //каталог проекта берется из указанного пути к файлу проекта, 
            //поскольку файл проекта должен всегда находиться в каталоге проекта,
            //а этот каталог может свободно перемещаться.
            //string projDir = Path.GetDirectoryName(ofd.FileName);
            //MProjectFile pf = MProjectFile.Load(ofd.FileName);
            //check version compatibility
            //if (MVersion.isCompatibleVersion(pf.EngineVersion) == false)
            //{
            //    MessageBox.Show("Project version not supported by current engine!");
            //    return;
            //}
            //m_file = pf;
            ////create connection string
            //SqlConnectionStringBuilder scb = new SqlConnectionStringBuilder();
            //scb.ConnectTimeout = pf.Timeout;
            //scb.DataSource = pf.DatabaseServerPath;
            //scb.IntegratedSecurity = false;
            //scb.InitialCatalog = pf.DatabaseName;
            //scb.Password = pf.UserPassword;
            //scb.UserID = pf.UserName;
            ////test connection
            //SqlConnection con = new SqlConnection(scb.ConnectionString);
            //con.Open();
            //con.Close();

            //open project. All commented checks moved inside
            MEngine me = new MEngine();
            me.Open(ofd.FileName);
            this.m_container = me;
            //for-user message 
            this.toolStripStatusLabel1.Text = "Container opened";
            SystemSounds.Beep.Play();
        }

        /// <summary>
        /// Create new project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //create new project file
            MProjectFile fi = new MProjectFile();
            fi.DatabaseName = "newdb";
            fi.DatabaseServerPath = ".";
            fi.Timeout = 30;
            fi.UserName = "astra";
            fi.UserPassword = "astalavista";
            
            ProjSettForm p = new ProjSettForm();
            p.ProjectFile = fi;
            p.ShowDialog();
            p.Dispose();

            //MEngine.CreateProject(fi, "c:\\temp\\");


            //MEngine.DeleteProject(fi);
        }

        /// <summary>
        /// Close opened project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.toolStripStatusLabel1.Text = "Closing container...";
            this.m_container.Close(true);
            this.m_linkShapes.Clear();
            this.m_cellShapes.Clear();
            this.toolStripStatusLabel1.Text = "Container closed";
        }

        /// <summary>
        /// Show project properties dialog
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void projectFileSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProjSettForm p = new ProjSettForm();
            p.ProjectFile = m_file;
            p.ShowDialog();
            p.Dispose();
        }

        #region Graphic view  functions

        private void panel_view_MouseMove(object sender, MouseEventArgs e)
        {
            if ((m_selShape != null) && m_dragEnable)
            {
                m_selShape.MoveTo(e.Location);
                Refresh();
            }
        }

        private void panel_view_MouseDown(object sender, MouseEventArgs e)
        {
            CellShape c = this.getShapeFromPoint(e.Location);
            if (c != null)
            {
                //deactivate old shape
                if (m_selShape != null)
                {
                    m_selShape.m_Brush = this.m_normBrush;
                    m_selShape.m_Pen = this.m_normPen;
                }
                    //activate new shape
                m_selShape = c;
                m_selShape.m_Brush = this.m_selBrush;
                m_selShape.m_Pen = this.m_selPen;
                m_dragEnable = true;
                this.Refresh();
            }

        }
        /// <summary>
        /// Return shape contains specified point or null
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        private CellShape getShapeFromPoint(Point point)
        {
            foreach (CellShape cs in m_cellShapes.Values)
            {
                if (cs.m_cellRect.Contains(point)) return cs;
            }
            return null;
        }

        private void panel_view_MouseUp(object sender, MouseEventArgs e)
        {
            m_dragEnable = false;
        }

        #endregion


        private void testSerializingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //test snapshot writer
            this.m_container.SnapshotManager.SaveFullSnapshot();

            //Структура снимка уже изменена, поэтому загружаться старые снимки не будут
            //this.m_container.SnapshotManager.LoadFullSnapshot("C:\\Temp\\Tapp23\\UserProjectExample\\Snapshots\\ProjectName.1.step");
            //test snapshot header reader
            //Mary.Serialization.MSnapshotFileInfo fi = Mary.Serialization.MSnapshotFileInfo.Load("");
            ////Тест сериализации ячейки
            ////1 создать ячейку
            //MCell ct = this.m_container.CreateCell(MCellMode.Temporary);
            //ct.Name = "TestCell01234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789";
            ////ct.Description = "DescriptionCell";
            //ct.ServiceFlag = 0x1111;
            ////ct.Value = new Byte[] { 0x22, 0x33, 0x55, 0x77 };
            //ct.ValueTypeId = new MID(1);
            //ct.State = new MID(21);
            //ct.TypeId = new MID(31);

            //MCell ct2 = this.m_container.CreateCell(MCellMode.Temporary);
            //ct2.Name = "";
            //MLink li0 = ct2.S1_createLink(new MID(0x11), MAxisDirection.Up, ct);
            ////2 выполнить сериализацию в поток
            //BinaryWriter bw = new BinaryWriter(File.Create("c:\\serialize.bin"));
            ////ct.toBinary(bw);
            //li0.toBinaryArray();
            //li0.toBinary(bw);
            //bw.Close();
            ////3 ...

        }
        /// <summary>
        /// Delete specified project from database and filesystem
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void deleteProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Show dialog to open project file
            OpenFileDialog ofd = new OpenFileDialog();
            //ofd.Multiselect = false; by default
            ofd.Title = "Select project file";
            ofd.DereferenceLinks = true; //use shortcuts for project opening
            ofd.Filter = "Tapp project file(.tapj)|*.tapj|All files|*.*";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog(this) != DialogResult.OK) return;

            MEngine.ProjectDelete(ofd.FileName);
        }

        private void clearCoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            m_container.ProjectClear();
        }

        private void serializeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            m_container.SnapshotManager.SaveFullSnapshot();
        }

        private void deserializeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            //Show dialog to open snapshot file
            OpenFileDialog ofd = new OpenFileDialog();
            //ofd.Multiselect = false; by default
            ofd.Title = "Select project file";
            ofd.InitialDirectory = m_container.ProjectManager.SnapshotFolderPath;
            ofd.DereferenceLinks = true; //use shortcuts for project opening
            ofd.Filter = "Tapp snapshot file(.step)|*.step|All files|*.*";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog(this) != DialogResult.OK) return;

            m_container.SnapshotManager.LoadFullSnapshot(ofd.FileName);
        }

        

    }
}
