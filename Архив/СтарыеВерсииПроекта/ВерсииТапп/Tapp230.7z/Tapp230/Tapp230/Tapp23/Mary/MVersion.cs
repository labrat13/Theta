﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mary
{
    /// <summary>
    /// Represent engine and assembly version for user application
    /// </summary>
    public class MVersion
    {
        /// <summary>
        /// Engine major version number
        /// </summary>
        /// <remarks>
        /// Отражает изменения, влияющие на формат данных.
        /// </remarks>
        public static int VersionID
        {
            get
            {
                return 23;
            }
 
        }
        /// <summary>
        /// Engine minor version number
        /// </summary>
        /// <remarks>
        /// Отражает изменения, не влияющие на формат данных.
        /// </remarks>
        public static int VersionSubID
        {
            get
            {
                return 0;
            }

        }

        public static string Description
        {
            get
            {
                return "";
            }

        }

        /// <summary>
        /// Returns true if specified version supported by current engine
        /// </summary>
        /// <param name="ver">version number</param>
        /// <returns></returns>
        /// <remarks>Всю проверку совместимости версий реализовывать здесь.</remarks>
        public static bool isCompatibleVersion(int ver)
        {
            return (ver == VersionID);
        }


    }
}
