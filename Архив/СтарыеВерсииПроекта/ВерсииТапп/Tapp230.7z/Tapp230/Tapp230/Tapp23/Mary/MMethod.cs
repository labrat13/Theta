﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mary
{
    public class MMethod
    {
        /// <summary>
        /// Backreference to container
        /// </summary>
        private MEngine m_container;

        //Constructor
        public MMethod(MEngine backref)
        {
            m_container = backref;

        }

        /// <summary>
        /// NR-Init method manager
        /// </summary>
        internal void Init()
        {
            
        }

        /// <summary>
        /// NR-Exit method manager
        /// </summary>
        internal void Exit()
        {
            
        }

    }
}
