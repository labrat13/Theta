﻿using System;
using System.Collections.Generic;
using System.Text;
using Mary.Serialization;
using System.IO;

namespace Mary
{
    public class MEngine: MElement
    {

#region Fields
        /// <summary>
        /// Container id number
        /// </summary>
        private int m_containerId;
        /// <summary>
        /// текстовое описание, null по умолчанию.
        /// </summary>
        private String m_description;
        /// <summary>
        /// flag is element active or deleted //default true
        /// </summary>
        private bool m_isactive;
        /// <summary>
        /// Поле для значения, используемого в сервисных операциях (поиск в графе,  обслуживание и так далее) //default 0
        /// </summary>
        private int m_serviceflag;
        /// <summary>
        /// Вынесен из подклассов как общее свойство. //default 0
        /// </summary>
        /// <remarks>Непонятно зачем здесь нужен и как будет использоваться, но является частью общего для всех элементов интерфейса</remarks>
        private int m_state;
        ///// <summary>
        ///// максимальный идентификатор ячейки в системе. Кэширует значение для быстрого получения идентификатора для новой ячейки. Инициализируется 0, что означает необходимость поиска нового значения.
        ///// </summary>
        //private int m_maxCellId; //заменен на m_maxConstCellID и m_maxTempCellID
        /// <summary>
        /// коллекция ячеек
        /// </summary>
        private MCellCollection m_cells;
        /// <summary>
        /// коллекция связей
        /// </summary>
        private MLinkCollection m_links;
        /// <summary>
        /// слой абстракции БД
        /// </summary>
        private MDbLayer m_dataLayer;
        ///// <summary>
        ///// рабочий каталог системы. Подкаталоги имеют фиксированные имена.
        ///// </summary>
        //private string m_directory;
        /// <summary>
        /// Log
        /// </summary>
        private MLog m_log;
        /// <summary>
        /// имя контейнера для пользователя
        /// </summary>
        private string m_name;
        /// <summary>
        /// Максимальный идентификатор постоянной ячейки
        /// </summary>
        private int m_maxConstCellID;
        /// <summary>
        /// Максимальный идентификатор временной ячейки
        /// </summary>
        private int m_maxTempCellID;

        /// <summary>
        /// Тип создаваемой ячейки, если явно не указан.
        /// </summary>
        private MCellMode m_DefaultCellMode; 
        /// <summary>
        /// Project filesystem manager
        /// </summary>
        private MProject m_prjMan;
        /// <summary>
        /// Resource manager
        /// </summary>
        private MResource m_resMan;
        /// <summary>
        /// Snapshot manager
        /// </summary>
        private MSnapshot m_snapMan;
        /// <summary>
        /// Methods manager
        /// </summary>
        private MMethod m_methodMan;
#endregion


        /// <summary>
        /// NT-Create new container object. Call Open() to open db connection and load container data.
        /// </summary>
        public MEngine()
        {
            m_cells = new MCellCollection();
            m_dataLayer = new MDbLayer();
            m_isactive = true;
            m_DefaultCellMode = MCellMode.Compact;
            m_links = new MLinkCollection();
            m_log = new MLog(this);
            //m_maxCellId = 0; removed 250312
            m_maxConstCellID = 0;
            m_maxTempCellID = 0;
            m_serviceflag = 0;
            m_state = 0;
            m_description = String.Empty;
            m_name = String.Empty;
            //new project managers
            m_methodMan = new MMethod(this);
            m_prjMan = new MProject(this);
            m_resMan = new MResource(this);
            m_snapMan = new MSnapshot(this);
            //store engine reference for all cells
            MCell.Container = this;
        }

#region Properties

        /// <summary>
        /// Element description string
        /// </summary>
        public override string Description
        {
            get
            {
                return m_description;
            }
            set
            {
                m_description = value;
            }
        }

        /// <summary>
        /// Element is active 
        /// </summary>
        public override bool isActive
        {
            get
            {
                return m_isactive;
            }
            set
            {
                m_isactive = value;
            }
        }
        /// <summary>
        /// Value for servicing
        /// </summary>
        public override int ServiceFlag
        {
            get
            {
                return m_serviceflag;
            }
            set
            {
                m_serviceflag = value;
            }
        }
        /// <summary>
        /// Element state id
        /// </summary>
        public override MID State
        {
            get
            {
                return new MID(m_state);
            }
            set
            {
                m_state = value.ID;
            }
        }
        /// <summary>
        /// Container ID number
        /// </summary>
        public int ContainerID
        {
            get { return m_containerId; }
            set { m_containerId = value; }
        }

        /// <summary>
        /// имя контейнера для пользователя
        /// </summary>
        public String Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }

        /// <summary>
        /// коллекция ячеек
        /// </summary>
        public MCellCollection Cells
        {
            get
            {
                return m_cells;
            }
        }

        /// <summary>
        /// коллекция связей
        /// </summary>
        public MLinkCollection Links
        {
            get
            {
                return m_links;
            }
        }

        /// <summary>
        /// Log
        /// </summary>
        public MLog Log
        {
            get
            {
                return m_log;
            }
        }

        /// <summary>
        /// слой абстракции БД
        /// </summary>
        public MDbLayer DataLayer
        {
            get { return m_dataLayer; }
        }

        /// <summary>
        /// Default cell type, can be Compact, Normal or DelaySave only.
        /// </summary>
        /// <remarks>При старте инициализируется значением  Compact, изменяется пользователем или кодом в процессе работы для управления характеристиками структуры.</remarks>
        public MCellMode DefaultCellMode
        {
            get
            {
                return m_DefaultCellMode;
            }
            set
            {
                m_DefaultCellMode = value;
            }
        }

        /// <summary>
        /// Snapshot manager
        /// </summary>
        public MSnapshot SnapshotManager
        {
            get
            {
                return m_snapMan;
            }
        }

        /// <summary>
        /// Resource manager
        /// </summary>
        public MResource ResourceManager
        {
            get
            {
                return m_resMan;
            }
        }

        /// <summary>
        /// Methods manager
        /// </summary>
        public MMethod MethodManager
        {
            get
            {
                return m_methodMan;
            }
        }

        /// <summary>
        /// Project filesystem manager
        /// </summary>
        public MProject ProjectManager
        {
            get
            {
                return m_prjMan;
            }
        }

#endregion



        #region Serialization function implements from MObject
        /// <summary>
        /// NFT-
        /// </summary>
        /// <param name="writer"></param>
        public override void toBinary(System.IO.BinaryWriter writer)
        {
            Int32 sectionLen = 0;
            
            writer.Write((byte)((int)Serialization.MSerialRecordType.Container)); //1byte
            Int64 beginPos = writer.BaseStream.Position;
            writer.Write(sectionLen); //4byte
            writer.Write(this.ContainerID); //4byte
            writer.Write(this.Name); //string
            writer.Write(this.Description); //string
            writer.Write(this.State.toU64()); //8byte id
            writer.Write(this.isActive);//1byte bool
            writer.Write(this.ServiceFlag);//4byte int32
            writer.Write((byte)(int)this.DefaultCellMode );//1byte enum
            writer.Write((int)this.Log.logDetail );//4byte enum
            writer.Write(this.Log.addSymbolicData );//1byte bool
            writer.Write(this.Log.LogFileNumber );//4byte int
            writer.Write(this.DataLayer.Timeout );//4byte int
            writer.Write(this.SnapshotManager.Step );//4byte int
            writer.Write((Int16)0); //checksum field must be last field
            //сюда не включены свойства лога: кодировка, разделитель ксв формата.
            Int64 endPos = writer.BaseStream.Position;
            sectionLen = (Int32)(endPos - beginPos);
            //write section length without sectionLen field
            writer.BaseStream.Position = beginPos;
            writer.Write(sectionLen - 4); //4byte
            //crc16
            Int16 crcval = MCrc16.CalculateCrc16FromStream(writer.BaseStream, beginPos, sectionLen - 2);//get bytes from first(section size) to last before crc field
            writer.BaseStream.Position = endPos - 2; //to crc16 field
            writer.Write(crcval);
            //restore end position
            writer.BaseStream.Position = endPos;

            return;
        }
        /// <summary>
        /// NT-Deserialize container from binary stream
        /// </summary>
        /// <param name="reader"></param>
        /// <remarks>
        /// предполагается, что текущая позиция чтения - на дескрипторе секции.
        /// Позиция при выходе из функции - на следующем дескрипторе секции.
        /// Модифицировать переменные, а не проперти, чтобы избежать запросов в БД итп.
        /// </remarks>
        public override void fromBinary(System.IO.BinaryReader reader)
        {
            //read section code
            MSerialRecordType rt = (MSerialRecordType)(int)reader.ReadByte();
            if (rt != MSerialRecordType.Container) throw new Exception("Invalid section type");//serialization error
            //read section length - skip now
            Int64 beginPos = reader.BaseStream.Position;
            reader.BaseStream.Position = reader.BaseStream.Position + 4;
            
            m_containerId = reader.ReadInt32();
            m_name = reader.ReadString();
            m_description = reader.ReadString();
            State = MID.fromU64(reader.ReadUInt64());
            m_isactive = reader.ReadBoolean();
            m_serviceflag = reader.ReadInt32();
            m_DefaultCellMode = (MCellMode)(int)reader.ReadByte();
            m_log.logDetail = (MMessageClass)reader.ReadInt32();
            m_log.addSymbolicData = reader.ReadBoolean();
            m_log.LogFileNumber = reader.ReadInt32();
            m_dataLayer.Timeout = reader.ReadInt32();
            m_snapMan.Step = reader.ReadInt32();
            //get crc
            Int64 endPos = reader.BaseStream.Position;
            Int16 crc = reader.ReadInt16();
            //checksum
            Int16 cr = MCrc16.CalculateCrc16FromStream(reader.BaseStream, beginPos, (int)(endPos - beginPos));
            if (cr != crc) throw new Exception("Invalid crc value");
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <returns></returns>
        public override byte[] toBinaryArray()
        {
            //create memory stream and writer
            MemoryStream ms = new MemoryStream(64);//initial size for data 
            BinaryWriter bw = new BinaryWriter(ms);
            //convert data
            this.toBinary(bw);
            //close memory stream and get bytes
            bw.Close();
            return ms.ToArray();
        }

        public override string toTextString(bool withHex)
        {
            throw new NotImplementedException();
        }

        public override void toText(System.IO.TextWriter writer, bool withHex)
        {
            throw new NotImplementedException();
        }

        public override void fromText(System.IO.TextReader reader)
        {
            throw new NotImplementedException();
        }
        #endregion

        /// <summary>
        /// NT-Open existing project
        /// </summary>
        /// <param name="projectFilePath">Path of project file to open</param>
        public void Open(string projectFilePath)
        {
            //load project file
            MProjectFile pf = MProjectFile.Load(projectFilePath);
            //check project version
            if (MVersion.isCompatibleVersion(pf.EngineVersion) == false)
                throw new Exception("Project version not supported by current engine!");
            //set up this project and container
            m_prjMan.ProjectFile = pf;
            //PRJNODB: check DB using
            if (pf.IsDBused())
            {     //db used
                string con = MDbLayer.createConnectionString(pf.DatabaseServerPath, pf.DatabaseName, pf.UserPassword, pf.UserName, pf.Timeout, false);
                m_dataLayer.ConnectionString = con;
                m_dataLayer.Timeout = 30;
                m_dataLayer.Open();
                //load container data from table
                m_dataLayer.LoadContainer(this);
                //get max of const cell's ID from cell table
                m_maxConstCellID = m_dataLayer.S1_getMaxCellId();
            }
            else  //db not used
            {
                //TODO: чего тут делать-то, без БД ?
            }
            //TODO: init log
            m_log.Open();
            //TODO: init resources
            m_resMan.Init();
            //TODO:init methods
            m_methodMan.Init();
            //TODO:init snapshots
            m_snapMan.Init();

            return;
        }

        /// <summary>
        /// Save container and project state
        /// </summary>
        public void Save()
        {
            //PRJNODB:if project uses DB, save container state in db
            if (this.m_prjMan.UsesDatabase)
            {
                m_dataLayer.SaveContainer(this);
                //TODO: save all cell changes if need
                
            }
        }

        /// <summary>
        /// NR-Save all delay-save cells in container
        /// </summary>
        public void SaveAllDelaySavedCells()
        {
            //PRJNODB: if project without db, return
            if (m_prjMan.UsesDatabase)
            {
                this.m_cells.SaveCells(MCellMode.DelaySave);
            }
        }

        /// <summary>
        /// NR-Save all temporary cells in container
        /// </summary>
        public void SaveAllTemporaryCells()
        {
            //PRJNODB: if project without db, return
            if (m_prjMan.UsesDatabase)
            {
                this.m_cells.SaveCells(MCellMode.Temporary);
            }
        }

        /// <summary>
        /// Close container and all engine stuff
        /// </summary>
        public void Close(bool withSave)
        {
            //PRJNODB: 
            if(m_prjMan.UsesDatabase)
                if (m_dataLayer.isConnectionOpened)
                {
                    if (withSave)
                    {
                        this.Save();
                        //saving cells before closing

                    }
                    m_dataLayer.Close();
                }
            //clear collections
            m_links.Items.Clear();
            m_cells.S1_Clear();

            //TODO: Resources
            m_methodMan.Exit();
            m_resMan.Exit();
            m_snapMan.Exit();
            //close log
            m_log.Close();
        }

#region New project functions - 210213 - уточнение прототипов функций

        /// <summary>
        /// NFT-Create new project
        /// </summary>
        /// <param name="projectName">New project name, 256 chars max</param>
        /// <param name="projectDescription">New project description, 8192 chars max</param>
        /// <param name="rootFolder">Project root folder</param>
        /// <param name="sqlServerPath">Path to SQLServer if project will use database.  Empty string if project without database.</param>
        /// <param name="databaseName">Database name. If project not use database, this value ignored. If project use database and this value empty, short project name used fr database name.</param>
        /// <param name="userLogin">User login. If project not use database, this value ignored. </param>
        /// <param name="userPassword">User password. If project not use database, this value ignored.</param>
        /// <param name="timeout">Connecton timeout in seconds. If project not use database, this value ignored.</param>
        public static void ProjectCreate(string projectName, string projectDescription, string rootFolder, string sqlServerPath, string databaseName, string userLogin, string userPassword, int timeout)
        {
            //1) Create project file object
            MProjectFile pf = new MProjectFile();
            pf.ProjectName = projectName;
            pf.Description = projectDescription;
            pf.DatabaseServerPath = sqlServerPath;
            pf.DatabaseName = databaseName;
            pf.UserName = userLogin;
            pf.UserPassword = userPassword;
            pf.Timeout = timeout;
            //2) Проверка аргументов
            pf.checkValues(); //throw some exceptions if one of values invalid.

            //3) Проверить, что каталог для проекта существует и доступен на запись. Если это не так, выдать исключение.
            DirectoryInfo di = new DirectoryInfo(rootFolder);
            if (di.Exists == false) throw new Exception("Invalid root folder");
            //create test subfolder and then delete it
            DirectoryInfo disub = di.CreateSubdirectory("test");//Здесь будет исключениеUnautorizedAccessException,  если нет прав на создание папки
            disub.Delete();

            //4) Сейчас входные аргументы проверены и записаны в объект файла проекта. Каталог проекта доступен для работы.
            //PRJNODB:
            if (pf.IsDBused())
            {
                //5) Открыть соединение и создать БД проекта. Если будет исключение, то либо параметры соединения неверные,
                //либо БД уже существует, либо еще чего.
                MDbLayer.CreateDatabase(pf.DatabaseServerPath, pf.UserName, pf.UserPassword, pf.DatabaseName);
                //6) Создать таблицы и индексы БД
                MDbLayer.CreateTablesIndexes(pf.DatabaseServerPath, pf.UserName, pf.UserPassword, pf.DatabaseName);
                //7) Создать объект контейнера, инициализировать его данными
                //! Проблема! Когда контейнер сохраняется в таблицу, эти операции должны записываться в лог.
                //Сейчас файл лога не открыт, да и каталога лога еще нет, поэтому писать в лог нельзя. 
                MEngine me = new MEngine();
                me.Description = pf.Description;
                me.Name = pf.getProjectName16();
                //открыть соединение с БД,
                me.DataLayer.ConnectionString = MDbLayer.createConnectionString(pf.DatabaseServerPath, pf.DatabaseName, pf.UserPassword, pf.UserName, 30, false);
                me.DataLayer.Timeout = 30;
                me.DataLayer.Open(); //! Без лога, или проверять его существование
                //сохранить контейнер в бд, закрыть соединение, разрушить объект контейнера.
                me.DataLayer.SaveContainer(me); //! Без лога, или проверять его существование
                me.DataLayer.Close(); //! Без лога, или проверять его существование
                me = null;
            }
            //8) создать файловую систему проекта
            MProject.CreateProjectFolder(pf, rootFolder); //! Без лога, или проверять его существование
            return;
            
        }

        /// <summary>
        /// NT-Open existing project
        /// </summary>
        /// <param name="projectFilePath">Path of project file to open</param>
        public static MEngine ProjectOpen(string projectFilePath)
        {
            MEngine me = new MEngine();
            me.Open(projectFilePath);
            return me;
        }

 
        /// <summary>
        /// NT-Get project statistics info
        /// </summary>
        /// <returns>Returns project statistic info</returns>
        /// <remarks>Сейчас это просто алиас для getStatistics(), которую надо заменить этой</remarks>
        public MStatistic ProjectStatistics()
        {
            return getStatistics();
        }

        /// <summary>
        /// NT-Saving project
        /// </summary>
        /// <remarks>
        /// Сохранять проект можно только в устойчивых состояниях процесса.
        /// Ксли проект не использует БД, сохранить проект можно только при помощи моментального снимка.
        /// </remarks>
        public void ProjectSave()
        {
            //PRJNODB: if project uses DB, save container state in db
            if (this.m_prjMan.UsesDatabase)
            {
                m_dataLayer.SaveContainer(this);
                //save MCellBds cells
                SaveAllDelaySavedCells();

            }
            //TODO: update project statistics in project file
        }
        /// <summary>
        /// NR-Optimize project
        /// </summary>
        /// <remarks>Основная функция запуска оптимизатора в процессе работы. Пока неясно, что она делает.</remarks>
        public void ProjectOptimize()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// NT-Close project
        /// </summary>
        public void ProjectClose(bool withSave)
        {
            Close(withSave);
        }
        /// <summary>
        /// NT-Clear project. Remove cells and links from memory and database tables. Container name, description and other values not changed.
        /// </summary>
        public void ProjectClear()
        {
            //clear collections
            m_links.Items.Clear();
            m_cells.S1_Clear();
            //clear tables
            //PRJNODB:
            if (m_prjMan.UsesDatabase)
                this.m_dataLayer.ClearCellAndLinkTables();
            //reinit variables
            this.m_maxConstCellID = 0;
            this.m_maxTempCellID = 0;
            this.m_serviceflag = 0;
            this.m_state = 0;
            //TODO: update project file - link and cell counters
            //TODO: Resources subsystem - remove all files
            m_resMan.ClearResources();
            //TODO: log subsystem
        }
        /// <summary>
        /// NT-Delete project from filesystem and database server
        /// </summary>
        /// <param name="projectFilePath">Project file pathname</param>
        public static void ProjectDelete(string projectFilePath)
        {
            //load project file
            MProjectFile pfile = MProjectFile.Load(projectFilePath);
            //PRJNODB: delete database
            if (pfile.IsDBused())
            {
                MDbLayer.DeleteDatabase(pfile.DatabaseServerPath, pfile.UserName, pfile.UserPassword, pfile.DatabaseName);
            }
            //delete project filesystem
            MProject.DeleteFolder(pfile.getProjectDirectory());  
        }

#endregion

#region Snapshot functions

        /// <summary>
        /// NT-Load full snapshot to container. All previous cells and links must be deleted. 
        /// </summary>
        /// <param name="snapshotFilePathName"></param>
        public void SnapshotFullLoad(string snapshotFilePathName)
        {
            //TODO: проверить, что контейнер пустой перед загрузкой
            this.m_snapMan.LoadFullSnapshot(snapshotFilePathName);

        }

        /// <summary>
        /// NT-Create new snapshot file for current project 
        /// </summary>
        public void SnapshotFullCreate()
        {
            this.m_snapMan.SaveFullSnapshot();

        }


#endregion

#region ID internal functions
        /// <summary>
        /// Get max ID of existing constant cells (from cells table)
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Постоянные ячейки всегда существуют в таблице, поэтому там их и считаем.
        /// Если ячеек нет, возвращает 0.
        /// </remarks>
        private int S1_intGetMaxCellConstID()
        {
            if (m_maxConstCellID == 0) m_maxConstCellID = m_dataLayer.S1_getMaxCellId();
            return m_maxConstCellID;
        }
        /// <summary>
        /// Get max ID of existing temporary cells (from cells collection in memory)
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Временные ячейки существуют только в памяти, поэтому там их и считаем.
        /// Если ячеек нет, возвращает 0.
        /// </remarks>
        private int S1_intGetMaxCellTempID()
        {
            if (m_maxTempCellID == 0) m_maxTempCellID = m_cells.S1_getMaxTempCellID();
            return m_maxTempCellID;
        }

        /// <summary>
        /// Изменяет значение соответствующего кеша для временной или постоянной ячейки
        /// </summary>
        /// <param name="cellid">Identifier of new cell</param>
        /// <remarks>
        /// Для временной ячейки должен вызываться при создании ячейки около добавления в список ячеек.
        /// Для постоянной ячейки после записи ячейки в БД
        /// </remarks>
        private void S1_ChangeIdCashOnCreateCell(int cellid)
        {
            if(MID.isTemporaryID(cellid))
                m_maxTempCellID = cellid;
            else
                m_maxConstCellID = cellid;
        }
        /// <summary>
        /// Изменяет значение соответствующего кеша для временной ячейки.
        /// </summary>
        /// <param name="cellid">Identifier of new cell</param>
        private void S1_ChangeIdCashOnRemoveTempCell(int cellid)
        {
            //Проверка что ид временных ячеек - вообще-то не должно быть вызовов для постоянных ячеек, поэтому TODO: после отладки движка убрать проверку.
            if (!MID.isTemporaryID(cellid)) throw new Exception("Invalid cell identifier");
            //Если удаляемая ячейка имеет наибольший ИД, сбрасываем кеш для последующего пересчета ИД.
            if (m_maxTempCellID == cellid) m_maxTempCellID = 0;
        }

        /// <summary>
        /// Returns id for new cell without update cash values
        /// Cash values must be updated after succesful cell creation
        /// </summary>
        /// <param name="forTempCell">True for temporary cell, False for constant cell.</param>
        /// <returns></returns>
        internal MID getNewCellId(bool forTempCell)
        {
            int t = 0;
            if (forTempCell)
            {
                t = S1_intGetMaxCellTempID();
                t = MID.getNewTempId(t);
            }
            else
            {
                t = S1_intGetMaxCellConstID();
                t = MID.getNewConstId(t);
            }
            return new MID(t);
        }

        /// <summary>
        /// Set new cash value for cell id's
        /// </summary>
        /// <param name="newId"></param>
        internal void changeIdCashOnCreateCell(MID newId)
        {
            this.S1_ChangeIdCashOnCreateCell(newId.ID);
        }

        /// <summary>
        /// Set new cash value for cell id's
        /// </summary>
        internal void changeIdCashOnRemoveTempCell(MID oldId)
        {
            this.S1_ChangeIdCashOnRemoveTempCell(oldId.ID);
        }

#endregion


#region Cell functions

        /// <summary>
        /// NT-Get first valid cell in project. Return null if no cells in project.
        /// </summary>
        /// <returns></returns>
        /// <remarks>Функция вспомогательная, вызывается только из навигатора, для получения начальной позиции при запуске навигатора</remarks>
        public MCell CellGetAny()
        {
            //get minimal cell in project database or memory
            int id = 0;
            // PRJNODB
            if (m_prjMan.UsesDatabase)
                id = m_dataLayer.getMinCellId();
            if (id != 0)
            {
                return this.CellGet(new MID(id));
            }
            else
            {
                //get first cell in memory
                return m_cells.getFirstCell();
            }
        }

        /// <summary>
        /// NR-Create container cell with mode. Return cell or throw exception
        /// </summary>
        /// <param name="mode">Cell mode for new cell</param>
        /// <returns></returns>
        /// <remarks>Публичная функция, должна обрабатывать ошибки и выдавать пользователю правильные исключения. Сейчас просто набросок.  </remarks>
        public MCell CellCreate(MCellMode mode)
        {
            //260213 PRJNODB: cellmode = Temporary only
            if (!m_prjMan.UsesDatabase) mode = MCellMode.Temporary;
            return S1_intCreateCell(mode);

        }

        /// <summary>
        /// NR-Get cell by cell ID. If cell not in memory, load it from table. 
        /// Returns null if cell not exists in project.
        /// </summary>
        /// <param name="cellID">cell id</param>
        /// <returns></returns>
        public MCell CellGet(MID cellID)
        {
            return S1_intGetCell(cellID);
        }
        /// <summary>
        /// NR-Get cell and mark as inactive. Cell not deleted.
        /// </summary>
        /// <param name="cellID">cell id</param>
        public void CellDelete(MID cellID)
        {
            S1_intDeleteCell(cellID);
        }
        /// <summary>
        /// NR-Unload cell from container memory.
        /// See also MCell.Unload()
        /// </summary>
        /// <param name="cellID">cell id</param>
        public void CellUnload(MID cellID)
        {
            S1_intUnloadCell(cellID);
        }

        /// <summary>
        /// NT-Check cell name is unique
        /// </summary>
        /// <param name="cellName">Some name</param>
        /// <returns>Returns True if cell with same name not exists in project, False otherwise.</returns>
        /// <remarks>Функция не изменяет ничего.</remarks>
        public bool CellIsUniqueName(string cellName)
        {
            //check memory
            if (m_cells.S1_containsName(cellName)) return false;
            //check database
            if (m_dataLayer.CellContainsName(cellName)) return false;
            return true;
        }

        // internal functions

        /// <summary>
        /// NT-Создать ячейку в контейнере. Возвращает ссылку на ячейку или исключение.
        /// </summary>
        /// <param name="mode">Тип создаваемой ячейки</param>
        /// <returns>Возвращает ссылку на ячейку или исключение.</returns>
        internal MCell S1_intCreateCell(MCellMode mode)
        {
             /*  1)Создается новый идентификатор для ячейки согласно cellMode.
             *  2)Проверяется, что созданный идентификатор допустим.
             *  3)Создается экземпляр ячейки McellB с значениями по умолчанию.
             *  4)Присваивается cellMode и идентификатор.
                5)Если не McellBt,  ячейка добавляется в таблицу.
             *   (Поскольку ячейка McellA не содержит полей, а нужно создать запись в таблице, используем McellB как заготовку.)
                6)Если McellA, берем идентификатор, уничтожаем старую ячейку, создаем McellA, присваиваем идентификатор.
             *  7)Добавляем ячейку в список ячеек контейнера.
             *    Ячейка не имеет связей, так что просто добавляем в список и все.
             *  8)Обновляем значение соответствующего кеша ИД  
             *  9)Возвращаем ссылку на ячейку. 
             *  
             * Обработка ошибок:
             * Функция должна выбрасывать исключения, при этом произведенные изменения должны быть уже отменены.
             * Ошибки:
             * 2 - неправильный идентификатор
             *   Нет изменений для отмены
             * 3 - недостаток памяти
             *   Нет изменений для отмены
             * 5 - ошибка сохранения в БД
             *   Если записи не произошло, нечего отменять. Другие изменения можно откатить внутри функции записи в БД.
             * 6 - недостаток памяти
             *   Надо создать ячейку до записи в БД.
             * 7 - ошибка словаря ячеек
             *   Надо удалить запись из таблицы в обработчике исключения. Хотя это сложно. 
             *   Проще сначала добавить ячейку в список, затем записать в таблицу.
             *   Если при записи будет ошибка, проще удалить ячейку из списка.
             *   
             * Код переделан.
             */

            //1 create cell id - no any global changes
            //можно заменить на вызов internal MID getNewCellId(bool forTempCell) это соответствует концепции идентификаторов, но медленнее. Тогда надо здесь и S1_ChangeIdCashOnCreateCell(cellid) заменить.
            int cellid;
            if (mode == MCellMode.Temporary)
                cellid = MID.getNewTempId(this.S1_intGetMaxCellTempID());
            else
                cellid = MID.getNewConstId(this.S1_intGetMaxCellConstID());
            //2 check cell id and throw exception  - no any global changes
            MID.checkID(cellid); 
            //3 create MCellB object and init by default
            MCellB cell = new MCellB(mode);
            cell.CellID = new MID(cellid); //set cell id
            //6 if MCellA cell required  - no any global changes
            MCell result;
            if (mode == MCellMode.Compact)
            {
                result = new MCellA();
                result.CellID = cell.CellID; //copy cell id value
            }
            else result = cell;
            //7 add cell to container cell list - cell list changed
            this.m_cells.S1_AddCell(result);
            try
            {
                //5 save to database if not temporary cell mode - cell table changed
                if (mode != MCellMode.Temporary) this.m_dataLayer.insertCell(cell);
            }
            catch (Exception e)
            {
                //Убедиться, что ловится только исключение из this.m_dataLayer.insertCell(cell);
                //Если это не так, сделать специальный класс исключения и вписать сюда
                //remove cell from cell collection
                this.m_cells.S1_RemoveCell(cell);
                //send exception to caller - чтобы избежать изменения ID cash value, и для информации об ошибке (проверить)
                throw e; 
            }
            //8 change ID cash - id cash changed
            S1_ChangeIdCashOnCreateCell(cellid); //change ID cash value
            //9 return
            return result;
        }

        /// <summary>
        /// NT-Получить ячейку по идентификатору или null если ячейка не найдена в контейнере и в БД.
        /// </summary>
        internal MCell S1_intGetCell(MID cellId)
        {
            /* 1) запросить ячейку из списка ячеек контейнера
             * 2) если ее нет, проверить что ячейка постоянная
             *   если нет, вернуть null
             * 3) если да, загружать ячейку из БД
             * 4) если загружена - вернуть ячейку
             * 5) если не найдена - вернуть null
             */
            //1 get cell from cells collection
            MCell result = this.Cells.S1_getCell(cellId);
            //2 if cell not exists, try load from database
            //260213 if PRJNODB skip load from database
            if ((result == null) && (this.ProjectManager.UsesDatabase))
            {
                //3 if cellid not Temporary, load cell from DB
                if (!cellId.isTemporaryID())
                {
                    result = this.S1_intLoadCell(cellId, this.DefaultCellMode);
                    //4 if cell loaded, return cell. Else return null
                }
            }
            return result;
        }

        /// <summary>
        /// NT-Загрузить ячейку из БД в контейнер. Возвращает ссылку на ячейку или null если ячейка не загружена
        /// </summary>
        /// <remarks>
        /// При исключениях необходимо откатить все изменения и вернуть null.
        /// Если вернуть null не получается, переделать все вызывающие функции для перехвата и обработки исключений.
        /// </remarks>
        internal MCell S1_intLoadCell(MID cellId, MCellMode cellMode)
        {
            /* Загрузка ячейки по типам:
             * MCellA - загрузить ячейку 
             * MCellB - загрузить ячейку, получить связи из таблицы, слить со связями из контейнера.
             * MCellBds - как MCellB
             * MCellBt - исключение выдать.
             */
            MCell result = null;
            switch (cellMode)
            {
                case MCellMode.Compact:
                    result = this.DataLayer.selectCell(cellId, false);
                    break;
                case MCellMode.Normal:
                case MCellMode.DelaySave:
                    MCellB res = (MCellB)this.DataLayer.selectCell(cellId, true);
                    //получить связи из таблицы, слить со связями из контейнера.
                    if (res != null)
                    {
                        //1) получить все связи ячейки из таблицы. 
                        MLinkCollection colD = this.DataLayer.getCellLinks(cellId.ID, MAxisDirection.Any);
                        //2) получить все связи ячейки из списка связей контейнера
                        MLinkCollection colM = this.Links.S1_getCellLinks(cellId);
                        //3) добавить в выходной список связи из таблицы, если их нет в списке связей из контейнера
                        //связи ячейки, которых нет в контейнере, надо туда добавить. А для этого надо получить разностный список связей.
                        List<MLink> links = colM.getUnicalLinks(colD);
                        // add links to container and to memory links collection
                        this.Links.Items.AddRange(links); //тут связи добавляются в контейнер. Если здесь или дальше будет исключение, нужно откатить добавление связей.
                        colM.Items.AddRange(links);// это будет список связей ячейки
                        res.setLinkCollection(colM);//add links to cell
                    }
                    result = res;
                    break;
                default:
                case MCellMode.Temporary:
                    throw new Exception("Invalid cell mode!");
                    //break;
            }
            //устанавливать ссылки на ячейку в связях будем отдельно. Но если нужно, то удобно здесь.
            //add cell to container
            if (result != null) this.Cells.S1_AddCell(result);
            return result;
        }

        /// <summary>
        /// NR-Найти и пометить ячейку удаленной. Ячейка загружается в память и помечается удаленной.
        /// </summary>
        internal void S1_intDeleteCell(MID cellId)
        {
            MCell t = this.S1_intGetCell(cellId);
            if (t != null) t.S1_Delete();
            else throw new Exception("Cell not found");
            //TODO: Надо ли выгружать ячейку, если она помечена удаленной?
        }

        /// <summary>
        /// NT-Выгрузить ячейку из памяти по идентификатору. Если ячейка не загружена, ничего не происходит. См. MCell.Unload().
        /// </summary>
        /// <remarks>Этот код лучше исполнять здесь из-за приватных функций контейнера, а MCell.Unload() будет его вызывать. </remarks>
        internal void S1_intUnloadCell(MID cellId)
        {
            //get cell from cell collection
            MCell cell = this.m_cells.S1_getCell(cellId);
            //if cell exists in memory, unload it.
            if (cell != null) this.S1_intUnloadCell(cell);
        }

        /// <summary>
        /// NT-Выгрузить ячейку из памяти. См. MCell.Unload().
        /// </summary>
        /// <remarks>Этот код лучше исполнять здесь из-за приватных функций контейнера, а MCell.Unload() будет его вызывать. </remarks>
        internal void S1_intUnloadCell(MCell cell)
        {
            /*
             * Для McellBds, McellBt - если выгрузка с сохранением, выполняется сохранение,
             * (ячейка превращается в McellB) затем выгрузка как McellB. Остальные типы ячеек не нуждаются в сохранении.
Для McellB типовой процесс:
Получить все связи ячейки. Связи с загруженными ячейками изменить — сбросить ссылки на ячейку. 
             * Связи с незагруженными ячейками удалить из списка связей контейнера.
Незагруженные ячейки — это ячейки, которые отсутствуют в списке ячеек контейнера;
  если в связи отсутствует ссылка на ячейку, это не означает, что ячейка отсутствует в памяти.
Загруженные ячейки присутствуют в списке связей контейнера, могут иметь ссылку на ячейку в связях.
Очистить список связей ячейки. При этом связи, на которые нет ссылок в контейнере или списках других ячеек, будут со временем удалены.
Удалить ячейку из списка контейнера.
McellBt
Для временной ячейки выгрузка эквивалентна полному удалению — отовсюду удаляются все связи с ячейкой и сама ячейка.
McellBds
Ячейка может содержать постоянные и временные связи с другими ячейками. Поскольку ячейка не была сохранена,
временные связи должны быть выгружены (без сохранения), за исключением связей с временными ячейками. 
(Подумать, как могут использоваться временные связи с другими ячейками и как их обрабатывать
     — а как будет использоваться сама ячейка?).
Выгружаются связи ячейки с незагруженными ячейками, выгружается ячейка, обнуляются ссылки на ячейку 
 в списке связей контейнера. ?
McellB
Сбросить все ссылки на ячейку в связях ячейки, выгрузить из памяти (списка контейнера) 
             * все связи этой ячейки с незагруженными в память ячейками, выгрузить ячейку. См выше.
McellA
Сбросить все ссылки на ячейку в списке связей контейнера. Лучше всего проходом по списку связей контейнера.
             * Одновременно? удалить из списка связей контейнера  все связи этой ячейки с незагруженными в память ячейками 
             * (а они там могут быть? Связи McellA-MCellA и McellA-id не хранятся в контейнере, не должны.), 
             * удалить ячейку из списка ячеек контейнера.
            Ячейка может иметь временные связи, их  не выгружать.

             * */
            //пока накидаем кучу по типам, потом переделаем, с учетом исключений
            //Проверить код по диаграмме связей! Что получится при выгрузке каждой из ячеек.
            //И проверить потом на тесте ячеек.
            switch (cell.CellMode)
            {
                case MCellMode.Compact: //MCellA - готово
                    //Сбросить все ссылки на ячейку в списке связей контейнера проходом.
                    this.Links.S1_setCellRefs(cell.CellID, null);
                    //Ячейка может иметь временные связи, их не выгружать - они управляются соотв. ячейкой.
                    //Удалить ячейку из списка ячеек контейнера.
                    this.Cells.S1_RemoveCell(cell);
                    break;
                case MCellMode.Normal: //готово
                    //Получить все связи ячейки - они в списке связей ячейки
                    //Связи с загруженными ячейками изменить — сбросить ссылки на текущую ячейку.
                    //Связи с незагруженными ячейками удалить из списка связей контейнера.
                    //связи с MCellA тоже надо удалять из контейнера
                    //За один проход желательно.
                    foreach (MLink li in cell.Links.Items)
                    {
                        //get id of linked cell
                        MID cid = li.getLinkedCellId(cell.CellID);
                        if (cid != null) 
                        {
                            //связанная ячейка загружена?
                            MCell ce = this.Cells.S1_getCell(cid);
                            //MCellA связи тоже удалять из контейнера
                            if ((ce != null) && (ce.CellMode != MCellMode.Compact))
                                    li.setCellRefsIfExists(cell.CellID, null); //сбросить ссылку на текущую ячейку
                            else
                                this.Links.S1_Remove(li); //удалить из контейнера (медленно?)
                        }
                    }
                    //Очистить список связей ячейки. При этом связи, на которые нет ссылок в контейнере 
                    // или списках других ячеек, будут со временем удалены.
                    cell.Links.Clear();
                    //Удалить ячейку из списка ячеек контейнера.
                    this.Cells.S1_RemoveCell(cell);
                    break;
                case MCellMode.DelaySave: //готово
                    //Получить все связи ячейки - они в списке связей ячейки
                    //Связи с загруженными ячейками:
                    //Временные:
                    // С MCellBds, MCellBt — сбросить ссылки на текущую ячейку. Связи остаются в контейнере и списке связанной ячейки.
                    // C MCellB - удалить из контейнера и связанной ячейки. Поскольку выгружается ячейка, обслуживающая эти связи.
                    // С MCellA - удалить из контейнера. Потому же. 
                    //Постоянные:
                    // С MCellBds, MCellB — сбросить ссылки на текущую ячейку. Связи остаются в контейнере и списке связанной ячейки.
                    // С MCellBt - исключение. Не может быть постоянных связей у временной ячейки.
                    // C MCellA - удалить из контейнера. 
                    //Связи с незагруженными ячейками удалить из списка связей контейнера.
                    foreach (MLink li in cell.Links.Items)
                    {
                        //get id of linked cell
                        MID cid = li.getLinkedCellId(cell.CellID);
                        if (cid != null)
                        {
                            //связанная ячейка загружена?
                            MCell ce = this.Cells.S1_getCell(cid);
                            //MCellA связи тоже удалять из контейнера
                            if (ce != null)
                            {
                                //загруженная ячейка
                                switch (ce.CellMode)
                                {
                                    case MCellMode.Compact:
                                        this.Links.S1_Remove(li);
                                        break;
                                    case MCellMode.Normal:
                                        if (li.isLinkNotTemporary)
                                        {
                                            li.setCellRefsIfExists(cell.CellID, null); //сбросить ссылку на текущую ячейку
                                        }
                                        else
                                        {
                                            this.Links.S1_Remove(li); //незагруженная ячейка. удалить из контейнера (медленно?)
                                            ce.Links.S1_Remove(li);//удалить из связанной ячейки
                                        }
                                        break;
                                    case MCellMode.DelaySave:
                                        li.setCellRefsIfExists(cell.CellID, null); //сбросить ссылку на текущую ячейку
                                        break;
                                    case MCellMode.Temporary:
                                        if (li.isLinkNotTemporary)
                                            throw new Exception("Temporary cell have constant link");
                                        else 
                                            li.setCellRefsIfExists(cell.CellID, null); //сбросить ссылку на текущую ячейку
                                        break;
                                }
                                li.setCellRefsIfExists(cell.CellID, null); //сбросить ссылку на текущую ячейку
                            }
                            else
                                this.Links.S1_Remove(li); //незагруженная ячейка. удалить из контейнера (медленно?)
                        }
                    }
                    //Очистить список связей ячейки. При этом связи, на которые нет ссылок в контейнере 
                    // или списках других ячеек, будут со временем удалены.
                    cell.Links.Clear();
                    //Удалить ячейку из списка ячеек контейнера.
                    this.Cells.S1_RemoveCell(cell);
                    break;
                case MCellMode.Temporary:
                    //Удалить связи ячейки из списка ячейки, связанных ячеек и из списка контейнера.
                    //Могут быть временные связи с незагруженными в память ячейками?
                    //Ссылки на ячейку могут быть только во временных связях, а они все удаляются.
                    //Для ускорения процесса хорошо бы сформировать список связанных ячеек, получить их,
                    //и из них выкидывать связи. Но пока можно удалять по одной.
                    //! this.Links не содержит функций для удаления связей!
                    //MCellA - удалить из списка контейнера.
                    //MCellB - удалить из списка контейнера, связанной ячейки
                    //MCellBds - удалить из списка контейнера, связанной ячейки
                    //MCellBt - удалить из списка контейнера, связанной ячейки
                    foreach (MLink li in cell.Links.Items)
                    {
                        if (li.isLinkNotTemporary)
                            throw new Exception("Temporary cell have constant link");
                        else
                        {
                            //get id of linked cell
                            MID cid = li.getLinkedCellId(cell.CellID);
                            if (cid != null)
                            {
                                //связанная ячейка загружена?
                                MCell ce = this.Cells.S1_getCell(cid);
                                if ((ce != null) && (ce.CellMode != MCellMode.Compact))
                                    ce.Links.S1_Remove(li);//удалить из связанной ячейки
                            }
                            this.Links.S1_Remove(li); //удалить из контейнера (медленно?)
                        }
                    }
                    //Очистить список связей ячейки. При этом связи, на которые нет ссылок в контейнере 
                    // или списках других ячеек, будут со временем удалены.
                    cell.Links.Clear();
                    //Удалить ячейку из списка ячеек контейнера.
                    this.Cells.S1_RemoveCell(cell);
                    //если ячейка временная, обновить кеш идентификаторов. Если постоянная, ничего не надо обновлять.
                    S1_ChangeIdCashOnRemoveTempCell(cell.CellID.ID);
                    break;
                default:
                    throw new Exception("Invalid cell mode");
            }

            
        }





 
        ///// <summary>
        ///// NT-Get cells meet specified template. Ячейки не добавляются в список в контейнере, это независимый список.
        ///// </summary>
        ///// <param name="tmp">CellSection template for search. Если не указать ни одного параметра, ничего не найдется.</param>
        ///// <param name="useLargeCells"> True create MCellB cells for small intensive used set's, False create MCellA cells for big set's</param>
        ///// <returns>CellSection collection</returns>
        //public MCellCollection GetCellsInTable(MCellTemplate tmp, bool useLargeCells)
        //{
        //    return m_dataLayer.getCellsByTemplate(tmp, useLargeCells);

        //}
        ///// <summary>
        ///// NT-Get cells meet specified template. Ячейки не добавляются в список в контейнере, это независимый список.
        ///// </summary>
        ///// <param name="tmp">CellSection template for search.</param>
        ///// <param name="useLargeCells"> True create MCellB cells for small intensive used set's, False create MCellA cells for big set's</param>
        ///// <returns>CellSection collection</returns>
        //public MCellCollection GetCells(MCellTemplate tmp, bool useLargeCells)
        //{
        //    throw new NotImplementedException();

        //}




#endregion 


#region LinkSection functions
        ///// <summary>
        ///// Is active link exists in table or memory?
        ///// </summary>
        ///// <param name="srcCell"></param>
        ///// <param name="dstCell"></param>
        ///// <param name="Axis"></param>
        ///// <param name="axisDir"></param>
        ///// <returns></returns>
        //internal bool containsLink(MCell srcCell, MCell dstCell, uint Axis, MAxisDirection axisDir)
        //{
        //    //find link in table
        //    //find link in memory
        //    MLinkTemplate t = new MLinkTemplate();
        //    t.Axis = Axis;
        //    t.setCellsByDirection(axisDir, srcCell.CellID, dstCell.CellID);
        //    t.isActive = true;
        //    int id = this.DataLayer.getLinkID(t.downCellID.Value, t.upCellID.Value, Axis);
        //    if (id != 0) return true; //link exists in table (but may be inactive!)
        //    else
        //        return this.Links.containsLink(t);
        //}



        /// <summary>
        /// NR-Удалить все связи указанной ячейки из контейнера и связанных ячеек. Упрощенная приблизительная версия.
        /// </summary>
        /// <param name="curCell"></param>
        /// <remarks>Не учитывается MCellA особенности!</remarks>
        internal void S1_RemoveCellLinksFromContainerAndCells(MCell curCell)
        {
            //1 получить количество связей. Если список пустой - выходим.
            int linksCount = curCell.Links.Items.Count; //links count
            if (linksCount == 0) return; //no links
            //2 последовательно проходя по списку связей контейнера, ищем связи с текущей ячейкой.
            //Получаем связанную ячейку и удаляем связь из ее списка связей.
            //Удаляем их по позиции, восстанавливаем позицию, и так до конца списка, если список не пустой.
            //в результате список связей текущей ячейки должен быть пуст. Проверяем. Если это не так, выдаем исключенте.
            int i = 0; 
            int cellid = curCell.CellID.ID; //cash cell id value
            MID targCellId = null;
            while (i < linksCount)
            {
                //find any links to/from current cell
                //Будет работать неправильно для связей ячейки с ней самой
                MLink li = this.Links.Items[i];
                targCellId = null; //as flag for id checking
                if (li.intGetDownId() == cellid)
                {
                    //get terget cell id
                    targCellId = li.upCellID;
                }
                else if (li.intGetUpId() == cellid)
                {
                    //get terget cell id
                    targCellId = li.downCellID;
                }
                //if link matched
                if(targCellId != null)
                {
                    //get target cell if loaded, but not load cell if not loaded
                    MCell tcell = this.Cells.S1_getCell(targCellId);
                    //remove link from cell links list if cell is loaded
                    if (tcell != null) tcell.Links.S1_Remove(li);
                    //remove link from current cell links list
                    curCell.Links.S1_Remove(li);
                    //remove link from container list
                    this.Links.S1_RemoveAt(i);
                    //change links counter for valid enumeration
                    linksCount = this.Links.Items.Count;
                    //Предполагается, что при удалении элемента весь остальной список сдвигается вверх. Однако это может быть не так, нужно проверить.
                }
                else
                {
                    //LinkSection not matched
                    i++;
                }

            }


        }


#endregion

        /// <summary>
        /// Get container description text
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0} {1} Cells:{2} Links:{3}", this.ContainerID, this.Name, this.Cells.Items.Count, this.Links.Items.Count );
            return sb.ToString();
        }

        /// <summary>
        /// NT-Get current container and resource statistics
        /// </summary>
        /// <returns></returns>
        internal MStatistic getStatistics()
        {
            MStatistic stat = new MStatistic();

            stat.CellsInMemory = this.Cells.Count;
            //PRJNODB: if project has database
            if (this.ProjectManager.UsesDatabase)
            {
                //get number of cells in cell table
                stat.ConstantCells = this.DataLayer.getNumberOfCells();
                //get number of links in link table
                stat.ConstantLinks = this.DataLayer.getNumberOfLinks();
            }
            //пока неясно как работать с внешними ячейками, пока 0
            stat.ExternalCells = 0;
            stat.ExternalLinks = 0;

            stat.LinksInMemory = this.Links.Items.Count;
            stat.TemporaryCells = this.Cells.getNumberOfTempCells();
            stat.TemporaryLinks = this.Links.getNumberOfTempLinks();

            //Statistics from Resource manager - 210213
            this.ResourceManager.GetResourceStatistics(stat);

            return stat;

        }

    }




}
