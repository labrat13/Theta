﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// Represent item categories
    /// </summary>
    public class ACategory : AItem
    {
    }
}
