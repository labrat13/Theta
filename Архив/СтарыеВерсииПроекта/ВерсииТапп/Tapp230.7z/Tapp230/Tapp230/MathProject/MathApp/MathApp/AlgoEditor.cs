﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MathApp
{
    public partial class AlgoEditor : Form
    {
        public AlgoEditor()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Drawing paint
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        /// <summary>
        /// Drawing click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void splitContainer1_Panel2_Click(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Drawing dblclick
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void splitContainer1_Panel2_DoubleClick(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Drawing drag drop
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void splitContainer1_Panel2_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void splitContainer1_Panel2_DragEnter(object sender, DragEventArgs e)
        {

        }

        private void splitContainer1_Panel2_DragLeave(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel2_DragOver(object sender, DragEventArgs e)
        {

        }

        private void splitContainer1_Panel2_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {

        }
    }
}
