﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    public class AArgument
    {
        /// <summary>
        /// Argument function id
        /// </summary>
        /// <remarks>Идентификатор функции, которой принадлежит аргумент, для поиска в таблице</remarks>
        private int m_funcID;
        /// <summary>
        /// Argument id
        /// </summary>
        /// <remarks>Идентификатор аргумента в таблице</remarks>
        private int m_id;
        /// <summary>
        /// Argument name
        /// </summary>
        private string m_name;
        /// <summary>
        /// Argument short description text
        /// </summary>
        private string m_shortDescr;
        /// <summary>
        /// Argument full description text
        /// </summary>
        private string m_fullDescr;
        /// <summary>
        /// Argument text value
        /// </summary>
        private string m_textValue;
        /// <summary>
        /// Argument datatype
        /// </summary>
        private ADatatype m_datatype;
        /// <summary>
        /// Argument typical order in arguments list
        /// </summary>
        /// <remarks>Размещение коннектора аргумента на чертеже, слева направо.</remarks>
        private int m_argOrder;

        /// <summary>
        /// Argument id
        /// </summary>
        public int ID
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /// <summary>
        /// Argument function id
        /// </summary>
        public int FunctionID
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /// <summary>
        /// Argument name
        /// </summary>
        public string Name
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /// <summary>
        /// Argument short description text
        /// </summary>
        public string ShortDescription
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /// <summary>
        /// Argument full description text
        /// </summary>
        public string FullDescription
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /// <summary>
        /// Argument datatype
        /// </summary>
        public ADatatype Datatype
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /// <summary>
        /// Argument text value
        /// </summary>
        public string TextValue
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
