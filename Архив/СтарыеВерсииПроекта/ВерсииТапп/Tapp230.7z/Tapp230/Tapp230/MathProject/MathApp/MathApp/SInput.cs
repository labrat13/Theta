﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// Represent input string from console
    /// </summary>
    /// <remarks>
    /// Ожидает ввод текста с консоли. 
    /// Возвращает строковую константу, полученную с клавиатуры
    /// </remarks>
    public class SInput : SElement
    {
    }
}
