﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// Represent Constant element
    /// </summary>
    public class AConstant : AElement
    {
        /// <summary>
        /// Constant text value
        /// </summary>
        private string m_textValue;
    }
}
