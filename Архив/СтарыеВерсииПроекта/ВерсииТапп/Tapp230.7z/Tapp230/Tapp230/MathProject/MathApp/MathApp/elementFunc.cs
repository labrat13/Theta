﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace MathApp
{
    /// <summary>
    /// Element Function
    /// </summary>
    public class elementFunc
    {
        private Rectangle m_shapeRectangle;


        public elementFunc()
        {

        }
        /// <summary>
        /// Return true if shape contains specified point
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        public bool ptInShape(Point pt)
        {
            return m_shapeRectangle.Contains(pt);
        }

        /// <summary>
        /// Return internal shape coords for specified point
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        public Point CalcInternalCoords(Point pt)
        {
            return new Point(pt.X - m_shapeRectangle.X, pt.Y - m_shapeRectangle.Y);
        }

        /// <summary>
        /// Draw function graphics
        /// </summary>
        public void Draw(Graphics g)
        {


        }

    }
}
