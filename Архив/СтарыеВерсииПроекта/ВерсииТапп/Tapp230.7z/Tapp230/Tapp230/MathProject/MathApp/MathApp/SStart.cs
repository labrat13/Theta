﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent begin of function
    /// </summary>
    /// <remarks>Ничего не принимает, ничего не возвращает, является начальной точкой потока управления в функции</remarks>
    public class SBegin : SElement
    {
    }
}
