﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    public class SShape
    {
        /// <summary>
        /// overall rectangle of shape
        /// </summary>
        private System.Drawing.Rectangle m_rect;
        private bool m_selected;

        /// <summary>
        /// Rectangle of entire shape
        /// </summary>
        public System.Drawing.Rectangle OverallRectangle
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public virtual void DrawShape()
        {
            throw new System.NotImplementedException();
        }
    }
}
