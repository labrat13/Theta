﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent return from function
    /// </summary>
    /// <remarks>Принимает аргумент возвращаемого функцией типа, ничего не возвращает, является конечной точкой потока управления.</remarks>
    public class SReturn : SElement
    {
    }
}
