﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent function
    /// </summary>
    /// <remarks>
    /// Принимает и возвращает значения
    /// Участвует в потоке управления
    /// </remarks>
    public class SFunction : SElement
    {
    }
}
