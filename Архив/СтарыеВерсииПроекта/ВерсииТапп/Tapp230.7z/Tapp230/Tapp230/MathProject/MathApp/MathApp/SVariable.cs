﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent variable
    /// </summary>
    /// <remarks>принимает и возвращает значение. Не участвует в потоке управления</remarks>
    public class SVariable : SElement
    {
    }
}
