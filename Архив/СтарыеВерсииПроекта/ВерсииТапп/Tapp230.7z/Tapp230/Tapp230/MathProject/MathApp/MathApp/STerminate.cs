﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent program termination
    /// </summary>
    /// <remarks>Принимает строку сообщения. Прерывает выполнение всей программы и выводит на консоль сообщение о завершении работы и сообщение из аргумента.</remarks>
    public class STerminate : SElement
    {
    }
}
