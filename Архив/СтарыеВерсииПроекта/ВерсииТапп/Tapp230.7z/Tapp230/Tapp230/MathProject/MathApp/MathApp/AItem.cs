﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    public class AItem
    {
        /// <summary>
        /// Item identifier
        /// </summary>
        private int m_id;
        /// <summary>
        /// Item name
        /// </summary>
        private string m_name;
        /// <summary>
        /// Item short description text
        /// </summary>
        private string m_shortDescr;
        /// <summary>
        /// Item full description text
        /// </summary>
        private string m_fullDescr;
        /// <summary>
        /// Item creation date
        /// </summary>
        private DateTime m_createDate;
        /// <summary>
        /// Item last modification date
        /// </summary>
        private DateTime m_modifyDate;
        /// <summary>
        /// Item creator identifier
        /// </summary>
        private int m_creatorId;
        /// <summary>
        /// Item read-only flag
        /// </summary>
        private bool m_readOnlyFlag;
        /// <summary>
        /// Item parent category identifier
        /// </summary>
        private int m_parentCategoryId;

        /// <summary>
        /// Item identifier
        /// </summary>
        public int ID
        {
            get
            {
                return m_id;
            }
            set
            {
                m_id = value;
            }
        }

        /// <summary>
        /// Item name
        /// </summary>
        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }

        /// <summary>
        /// Item short description text
        /// </summary>
        public string ShortDescription
        {
            get
            {
                return m_shortDescr;
            }
            set
            {
                m_shortDescr = value;
            }
        }

        /// <summary>
        /// Item full description text
        /// </summary>
        public string FullDescription
        {
            get
            {
                return m_fullDescr;
            }
            set
            {
                m_fullDescr = value;
            }
        }

        /// <summary>
        /// Item creation date
        /// </summary>
        public DateTime CreationDate
        {
            get
            {
                return m_createDate;
            }
            set
            {
                m_createDate = value;
            }
        }

        /// <summary>
        /// Item last modification date
        /// </summary>
        public DateTime ModificationDate
        {
            get
            {
                return m_modifyDate;
            }
            set
            {
                m_modifyDate = value;
            }
        }

        /// <summary>
        /// Item creator identifier
        /// </summary>
        public int CreatorID
        {
            get
            {
                return m_creatorId;
            }
            set
            {
                m_creatorId = value;
            }
        }

        /// <summary>
        /// Item read-only flag
        /// </summary>
        public bool ReadOnlyFlag
        {
            get
            {
                return m_readOnlyFlag;
            }
            set
            {
                m_readOnlyFlag = value;
            }
        }

        /// <summary>
        /// Item parent category identifier
        /// </summary>
        public int ParentCategoryID
        {
            get
            {
                return m_parentCategoryId;
            }
            set
            {
                m_parentCategoryId = value;
            }
        }


    }
}
