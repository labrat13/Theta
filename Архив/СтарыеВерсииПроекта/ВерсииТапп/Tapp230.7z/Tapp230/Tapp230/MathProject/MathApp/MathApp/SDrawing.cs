﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// Represent drawing
    /// </summary>
    public class SDrawing : SShape
    {
    }
}
