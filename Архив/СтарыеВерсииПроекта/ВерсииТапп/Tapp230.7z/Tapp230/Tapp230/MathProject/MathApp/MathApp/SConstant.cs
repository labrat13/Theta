﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent constant value
    /// </summary>
    /// <remarks>
    /// Не принимает, только  выдает значение.
    /// Не участвует в потоке управления.
    /// </remarks>
    public class SConstant : SElement
    {
    }
}
