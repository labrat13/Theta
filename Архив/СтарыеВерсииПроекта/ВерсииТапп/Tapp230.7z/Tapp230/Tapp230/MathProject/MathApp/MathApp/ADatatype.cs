﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    public enum ADatatype
    {
        /// <summary>
        /// Unknown datatype
        /// </summary>
        Unknown,
        /// <summary>
        /// Int32 datatype
        /// </summary>
        Integer,
        /// <summary>
        /// Double datatype
        /// </summary>
        Floating,
        /// <summary>
        /// String datatype
        /// </summary>
        String,
        /// <summary>
        /// Bool datatype
        /// </summary>
        Boolean,
    }
}
