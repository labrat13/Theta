﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    public class SLink : SShape
    {
    }
}
