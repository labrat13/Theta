﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// General class for element ierarchy
    /// </summary>
    public class AElement: AItem
    {
        /// <summary>
        /// Element datatype identifier
        /// </summary>
        private ADatatype m_Datatype;

        /// <summary>
        /// Element datatype identifier
        /// </summary>
        public ADatatype Datatype
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
