﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// Represent Function
    /// </summary>
    public class AFunction : AElement
    {
        /// <summary>
        /// List of arguments
        /// </summary>
        private List<AArgument> m_args;
        /// <summary>
        /// Result argument
        /// </summary>
        private AArgument m_result;

        /// <summary>
        /// List of arguments
        /// </summary>
        public System.Collections.Generic.List<MathApp.AArgument> Arguments
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /// <summary>
        /// Result argument
        /// </summary>
        public AArgument Result
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
