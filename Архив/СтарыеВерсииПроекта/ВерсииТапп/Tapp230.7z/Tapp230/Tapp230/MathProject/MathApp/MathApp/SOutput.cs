﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent print to console operation
    /// </summary>
    /// <remarks>Выводит на консоль строковую константу или переменную, ничего не возвращает.</remarks>
    public class SOutput : SElement
    {
    }
}
