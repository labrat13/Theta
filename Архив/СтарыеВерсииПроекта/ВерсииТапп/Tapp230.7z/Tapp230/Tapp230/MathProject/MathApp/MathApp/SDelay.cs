﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathApp
{
    /// <summary>
    /// represent delay execution operation
    /// </summary>
    /// <remarks>Принимает интервал времени в миллисекундах. Ничего не возвращает.</remarks>
    public class SDelay : SElement
    {
    }
}
