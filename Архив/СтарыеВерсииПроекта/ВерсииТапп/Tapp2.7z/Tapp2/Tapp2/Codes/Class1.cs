﻿using System;
using System.Collections.Generic;
using System.Text;
using Marta;
using Marta.Methods;

namespace Codes
{
    /// <summary>
    /// Static class for method body functions
    /// </summary>
    [SeImplement(ImplementationState.NotTested)]
    public static class Example
    {
        /// <summary>
        /// Example function for call method with kta as argument list
        /// </summary>
        /// <param name="me">Container</param>
        /// <param name="caller">Caller object or class</param>
        /// <param name="kta">Kta with arguments</param>
        /// <returns>Returns integer value 12345</returns>
        [SeImplement(ImplementationState.NotTested)]
        public static int testMethod1(MEngine me, MCell caller, MKTA kta)
        {
            return 12345;
        }
        /// <summary>
        /// Example function for call method with two arguments
        /// </summary>
        /// <param name="me">Container</param>
        /// <param name="caller">Caller object or class</param>
        /// <param name="arg1">Argument1</param>
        /// <param name="arg2">Argument2</param>
        /// <returns>Returns sum of arg1 and arg2</returns>
        [SeImplement(ImplementationState.NotTested)]
        public static uint testMethod2(MEngine me, MCell caller, uint arg1, uint arg2)
        {
            return arg1 + arg2;
        }
        /// <summary>
        /// Example function for call method without any arguments
        /// </summary>
        /// <param name="me">Container</param>
        /// <param name="caller">Caller object or class</param>
        /// <returns>Returns integer value 777</returns>
        [SeImplement(ImplementationState.NotTested)]
        public static int testMethod3(MEngine me, MCell caller)
        {
            return 777;
        }

    }
}
