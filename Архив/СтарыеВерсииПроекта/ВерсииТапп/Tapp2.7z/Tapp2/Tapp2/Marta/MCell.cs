﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using Marta.Methods;
using System.Windows.Forms;

namespace Marta
{
    /// <summary>
    /// Parent class for MObj and MClass, represent data cell type 
    /// </summary>
    public class MCell
    {
        #region Fields
        /// <summary>
        /// Cell ID
        /// </summary>
        protected MID m_id;
        /// <summary>
        /// Comment string
        /// </summary>
        /// <remarks>Do not use XML brackets and ~ chars in this text because its used by XML parsing.</remarks>
        protected String m_comment;
        /// <summary>
        /// Creation datetime
        /// </summary>
        /// <remarks>This is a timestamp of object creation.</remarks>
        private DateTime m_creaTime;
        /// <summary>
        /// Data of cell
        /// </summary>
        /// <remarks>Represent data object stored in this cell. Used in objects only.</remarks>
        private Object m_data;
        /// <summary>
        /// Type of cell data
        /// </summary>
        /// <remarks>Represent C#-type of data object stored in this cell.</remarks>
        protected System.Type m_dataType;
        /// <summary>
        /// Modification datetime
        /// </summary>
        /// <remarks>This is a timestamp of object modification. Currently not used.</remarks>
        protected DateTime m_modiTime;
        /// <summary>
        /// Cell name
        /// </summary>
        /// <remarks>Do not use XML brackets and ~ chars in this description because its used by XML parsing.</remarks>
        protected String m_name;
        /// <summary>
        /// Cell state
        /// </summary>
        /// <remarks>Represent cell state for automatic services. Currently not used.</remarks>
        protected MCellState m_state;
        /// <summary>
        /// Cell metainfo object
        /// </summary>
        /// <remarks>Represent cell metainfo for automatic services. Currently not used.</remarks>
        private Object m_meta;
        /// <summary>
        /// Read-only flag
        /// </summary>
        /// <remarks>True means this cell read-only.</remarks>
        private bool m_ReadOnly;
        /// <summary>
        /// Is current cell represent class?
        /// </summary>
        /// <remarks>True mean that current cell is class. This flag set inside constructor.</remarks>
        protected bool m_isClass;
        /// <summary>
        /// Parent container. 
        /// </summary>
        /// <remarks>For access to value you must use Parent properties.</remarks>
        protected Object m_parent;
        /// <summary>
        /// X up links list
        /// </summary>
        private List<MLink> m_Xup;
        /// <summary>
        /// X down links list
        /// </summary>
        private List<MLink> m_Xdn;
        /// <summary>
        /// Y up links list
        /// </summary>
        private List<MLink> m_Yup;
        /// <summary>
        /// Y down links list
        /// </summary>
        private List<MLink> m_Ydn;
        /// <summary>
        /// Z up links list
        /// </summary>
        private List<MLink> m_Zup;
        /// <summary>
        /// Z down links list
        /// </summary>
        private List<MLink> m_Zdn;
        /// <summary>
        /// Graph search flag
        /// </summary>
        /// <remarks>Graph search flag for searching in graph (visited, nested or same other). Internal use only.</remarks>
        private int m_Search;

        #endregion
        /// <summary>
        /// Default constructor, used by XML serializator
        /// </summary>
        public MCell()
        {
            m_creaTime = DateTime.Now;
            m_comment = null;
            m_data = null;
            m_dataType = typeof(Object);
            m_id = null;
            m_meta = null;
            m_modiTime = m_creaTime;
            m_name = null;
            m_ReadOnly = false;
            m_state = MCellState.Normal;
            m_Xdn = new List<MLink>();//create list for use in xml deserialize
            m_Xup = new List<MLink>();
            m_Ydn = new List<MLink>();
            m_Yup = new List<MLink>();
            m_Zdn = new List<MLink>();
            m_Zup = new List<MLink>();
            m_Search = 0;
        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="objId">ObjectID</param>
        /// <param name="name">Cell name</param>
        /// <param name="comment">Cell comment</param>
        /// <param name="cellData">Cell data object</param>
        /// <param name="dataType">Cell data type</param>
        internal MCell(MID objId, string name, String comment, Object cellData, Type dataType)
        {
            m_creaTime = DateTime.Now;
            m_comment = comment;
            m_data = cellData;
            m_dataType = dataType;
            m_parent = null;
            m_id = objId;
            m_meta = null;
            m_modiTime = m_creaTime;
            m_name = name;
            m_ReadOnly = false;
            m_parent = null;
            m_state = MCellState.Normal;
            m_Xdn = new List<MLink>();//create list for use in xml deserialize
            m_Xup = new List<MLink>();
            m_Ydn = new List<MLink>();
            m_Yup = new List<MLink>();
            m_Zdn = new List<MLink>();
            m_Zup = new List<MLink>();
            m_Search = 0;
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~MCell()
        {
            
        }

        #region Properties
        /// <summary>
        /// Cell ID
        /// </summary>
        /// <remarks>Represent semantic type id for this cell</remarks>
        public MID ID
        {
            get
            {
                return m_id;
            }
            set
            {
                m_id = value;
            }
        }

        /// <summary>
        /// Cell name
        /// </summary>
        /// <remarks>
        /// Name of object or class for semantic recogniton and debug.
        /// Do not use XML brackets and ~ because XML parsing errors occured.
        /// </remarks>
        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }
        /// <summary>
        /// Cell state
        /// </summary>
        /// <remarks>Represent cell state for automatic services. Currently not used.</remarks>
        public MCellState State
        {
            get
            {
                return m_state;
            }
            set
            {
                m_state = value;
            }
        }
        /// <summary>
        /// Type of cell data
        /// </summary>
        /// <remarks>Represent C#-type of data object stored in this cell.</remarks>
        [XmlIgnore]
        public Type DataType
        {
            get
            {
                return m_dataType;
            }
            set
            {
                m_dataType = value;
            }
        }

        /// <summary>
        /// Data type as string for XML serializing
        /// </summary>
        /// <remarks>Represent data type as string, because System.Type not serialized to XML correctly</remarks>
        public String DataTypeAsString
        {
            get { return m_dataType.ToString(); }
            set { m_dataType = Type.GetType(value, true, true); }
        }

        /// <summary>
        /// Data of cell
        /// </summary>
        /// <remarks>Represent data object stored in this cell. Used in objects only.</remarks>
        public Object Data
        {
            get
            {
                return m_data;
            }
            set
            {
                m_data = value;
            }
        }

        /// <summary>
        /// Comment string
        /// </summary>
        /// <remarks>
        /// Store textual cell description for cell role in this system. 
        /// Do not use XML brackets and ~ because XML parsing errors occured. 
        ///</remarks>
        public string Comment
        {
            get
            {
                return m_comment;
            }
            set
            {
                m_comment = value;
            }
        }

        /// <summary>
        /// Creation datetime
        /// </summary>
        /// <remarks>This is a timestamp of cell creation.</remarks>
        public DateTime CreationTime
        {
            get
            {
                return m_creaTime;
            }
            set
            {
                m_creaTime = value;
            }
        }

        /// <summary>
        /// Modification datetime
        /// </summary>
        /// <remarks>This is a timestamp of cell modification. Currently not used.</remarks>
        public DateTime ModifyTime
        {
            get
            {
                return m_modiTime;
            }
            set
            {
                m_modiTime = value;
            }
        }

        /// <summary>
        /// Cell metainfo object
        /// </summary>
        /// <remarks>Represent cell metainfo for automatic services. Currently not used.</remarks>
        public Object MetaInfo
        {
            get
            {
                return m_meta;
            }
            set
            {
                m_meta = value;
            }
        }

        /// <summary>
        /// Read-only flag
        /// </summary>
        /// <remarks>True means this cell read-only.</remarks>
        public bool ReadOnly
        {
            get
            {
                return m_ReadOnly;
            }
            set
            {
                m_ReadOnly = value;
            }
        }

        /// <summary>
        /// Is class? flag
        /// </summary>
        /// <remarks>Read-only. True means this cell represent semantic class</remarks>
        [XmlIgnore]
        public bool IsClass
        {
            get
            {
                return m_isClass;
            }
        }

        /// <summary>
        /// MEngine virtual object
        /// </summary>
        /// <remarks>For internal use only. Must be override in child classes</remarks>
        [XmlIgnore]
        public virtual MEngine Container
        {
            get { return (MEngine) m_parent; }
        }

        /// <summary>
        /// X up links list
        /// </summary>
        /// <remarks>Read-only access to Cell-Cell links list</remarks>
        public System.Collections.Generic.List<MLink> XupLinks
        {
            get
            {
                return m_Xup;
            }
        }

        /// <summary>
        /// X down links list
        /// </summary>
        /// <remarks>Read-only access to Cell-Cell links list</remarks>
        public System.Collections.Generic.List<MLink> XdnLinks
        {
            get
            {
                return m_Xdn;
            }
        }

        /// <summary>
        /// Y up links list
        /// </summary>
        /// <remarks>Read-only access to Cell-Cell links list</remarks>
        public System.Collections.Generic.List<MLink> YupLinks
        {
            get
            {
                return m_Yup;
            }
        }

        /// <summary>
        /// Y down links list
        /// </summary>
        /// <remarks>Read-only access to Cell-Cell links list</remarks>
        public System.Collections.Generic.List<MLink> YdnLinks
        {
            get
            {
                return m_Ydn;
            }
        }

        /// <summary>
        /// Z up links list
        /// </summary>
        /// <remarks>Read-only access to Cell-Cell links list</remarks>
        public System.Collections.Generic.List<MLink> ZupLinks
        {
            get
            {
                return m_Zup;
            }
        }

        /// <summary>
        /// Z down links list
        /// </summary>
        /// <remarks>Read-only access to Cell-Cell links list</remarks>
        public System.Collections.Generic.List<MLink> ZdnLinks
        {
            get
            {
                return m_Zdn;
            }
        }

        /// <summary>
        /// Graph search flag
        /// </summary>
        /// <remarks>Graph search flag for searching in graph (visited, nested, level or same other). Internal use only.</remarks>
        [XmlIgnore]
        internal int SearchFlag
        {
            get { return m_Search; }
            set { m_Search = value; }
        }

        #endregion

        /// <summary>
        /// Return string representation of object
        /// </summary>
        /// <remarks>Used for debugger and user views.</remarks>
        /// <returns>
        /// String description of this cell: ID name state
        /// 
        ///</returns>
        public override string ToString()
        {
            return String.Format("{0} {1} {2}", this.m_id.ToString(), m_name, m_state.ToString());
        }

        #region *** XML function (not used, for XML testing only)***
        /// <summary>
        /// save data to XML file
        /// </summary>
        /// <remarks>Not used, for XML testing only</remarks>
        /// <param name="filename">name of XML file</param>
        public void SaveToXML(string filename)
        {
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            writer.Serialize(file, this);
            file.Close();
        }

        /// <summary>
        /// load data from XML file
        /// </summary>
        /// <remarks>Not used, for XML testing only</remarks>
        /// <param name="filename">name of XML file</param>
        public static MCell LoadFromXML(string filename)
        {
            MCell li;
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(Type.GetType("MCell"));
            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            li = (MCell) reader.Deserialize(file);
            file.Close();
            return li;
        }
        #endregion


        #region *** Link function ***
        /// <summary>
        /// Get list of links for specified axis code
        /// </summary>
        /// <param name="a">Axis code</param>
        /// <returns>List of links</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal List<MLink> getAxisList(Axiss a)
        {
            List<MLink> res = null;
            switch (a)
            {
                case Axiss.Xdown:
                    res = m_Xdn;
                    break;
                case Axiss.Xup:
                    res = m_Xup;
                    break;
                case Axiss.Ydown:
                    res = m_Ydn;
                    break;
                case Axiss.Yup:
                    res = m_Yup;
                    break;
                case Axiss.Zdown:
                    res = m_Zdn;
                    break;
                case Axiss.Zup:
                    res = m_Zup;
                    break;
                default:
                    throw new SeArgumentException(SeArgumentException.axisErrMsg, (int)a);
                    
            }
            return res;
        }
        /// <summary>
        /// Get list of links for inversed axis code (For example, Xup axis inversed to Xdown)
        /// </summary>
        /// <param name="a">Axis code</param>
        /// <returns>List of links</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal List<MLink> getInverseAxisList(Axiss a)
        {
            List<MLink> res = null;
            switch (a)
            {
                case Axiss.Xup:
                    res = m_Xdn;
                    break;
                case Axiss.Xdown:
                    res = m_Xup;
                    break;
                case Axiss.Yup:
                    res = m_Ydn;
                    break;
                case Axiss.Ydown:
                    res = m_Yup;
                    break;
                case Axiss.Zup:
                    res = m_Zdn;
                    break;
                case Axiss.Zdown:
                    res = m_Zup;
                    break;
                default:
                    throw new SeArgumentException(SeArgumentException.axisErrMsg, (int)a);
                    //break;
            }
            return res;
        }
        /// <summary>
        /// Get inverted axis code (For example, Xup axis inversed to Xdown) 
        /// </summary>
        /// <param name="a">Axis code</param>
        /// <returns>Code of inversed axis</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        internal static Axiss inverseAxis(Axiss a)
        {
            switch (a)
            {
                case Axiss.Xdown:
                    return Axiss.Xup;
                    //break;
                case Axiss.Xup:
                    return Axiss.Xdown;
                   //break;
                case Axiss.Ydown:
                    return Axiss.Yup;
                    //break;
                case Axiss.Yup:
                    return Axiss.Ydown;
                    //break;
                case Axiss.Zdown:
                    return Axiss.Zup;
                    //break;
                case Axiss.Zup:
                    return Axiss.Zdown;
                    //break;
                default:
                    throw new SeArgumentException(SeArgumentException.axisErrMsg, (int)a);    
                
            }
        }

        /// <summary>
        /// NT-Get sorted list of halflinks to target object.
        /// Sort order: Restricted, Normal,  Undefined, Deleted.
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targetID">Target ID</param>
        /// <param name="withSort">True - list sorted by link state, false - skip sort, faster</param>
        /// <param name="Restricted">Include this link type</param>
        /// <param name="Normal">Include this link type</param>
        /// <param name="Undefined">Include this link type</param>
        /// <param name="Deleted">Include this link state</param>
        /// <returns>Returns sorted list of links to target class objects linked to current object (may have more than 1 link)</returns>
        protected internal List<MLink> L0GetLinksListToObj(List<MLink> axis, MID targetID, bool withSort, bool Restricted, bool Normal, bool Undefined, bool Deleted)
        {
            List<MLink> lin = new List<MLink>();
            foreach (MLink l in axis)
            {
                if (l.DestObjectID.isEqual(targetID))  //if link is matched
                {
                    //filter link by state and type
                    MLinkType s = l.eLinkType;//check link type
                    MLinkState st = l.eLinkState;//check link state
                    if (((st == MLinkState.Deleted) && Deleted) || ((s == MLinkType.Normal) && Normal) || ((s == MLinkType.Restricted) && Restricted) || ((s == MLinkType.Undefined) && Undefined))
                        lin.Add(l); //add to list
                }
            }
            //sort list in order: Restricted, Normal,  Undefined, Deleted
            if(withSort && (lin.Count > 1)) lin.Sort(MLink.SortByLinkType);//sort if two or more links
            //return link list
            return lin;
        }

        /// <summary>
        /// NT-Get sorted list of halflinks to any object of target class - NT
        /// Sort order: Restricted, Normal,  Undefined, Deleted
        /// </summary>
        /// <param name="axis">Axis list for work</param>
        /// <param name="targetID">ID of target class</param>
        /// <param name="withSort">True - list sorted by link state, false - skip sort, faster</param>
        /// <param name="Restricted">Include these links</param>
        /// <param name="Normal">Include these links</param>
        /// <param name="Deleted">Include these links</param>
        /// <param name="Undefined">Include these links</param>
        /// <returns>Returns list of links to target class objects linked to current object (may have more than 1 link)</returns>
        protected internal List<MLink> L0GetLinksListToAnyObj(List<MLink> axis, uint targetID, bool withSort, bool Restricted, bool Normal, bool Undefined, bool Deleted)
        {
            List<MLink> lin = new List<MLink>();
            foreach (MLink l in axis)
            {
                if (l.DestObjectID.ClassID == targetID)  //if link is matched
                {
                    //filter link by state and type
                    MLinkType s = l.eLinkType;//check link type
                    MLinkState st = l.eLinkState;//check link state
                    if (((st == MLinkState.Deleted) && Deleted) || ((s == MLinkType.Normal) && Normal) || ((s == MLinkType.Restricted) && Restricted) || ((s == MLinkType.Undefined) && Undefined))
                        lin.Add(l); //add to list
                }
            }
            //sort list in order: Restricted, Normal, Deleted, Undefined
            if (withSort && (lin.Count > 1)) lin.Sort(MLink.SortByLinkType);//sort if two or more links
            //return link list
            return lin;
        }

        /// <summary>
        /// NT-Get list of halflinks to any objects and classes, filtered and sorted by link type
        /// Sort order: Restricted, Normal,  Undefined, Deleted
        /// </summary>
        /// <param name="axis">Axis list for work</param>
        /// <param name="withSort">True - list sorted by link type, false - skip sort, faster</param>
        /// <param name="Restricted">Include these links</param>
        /// <param name="Normal">Include these links</param>
        /// <param name="Deleted">Include these links</param>
        /// <param name="Undefined">Include these links</param>
        /// <returns>Returns list of links to cells, linked to current cell</returns>
        protected internal List<MLink> L0GetAxisLinksListFiltered(List<MLink> axis, bool withSort, bool Restricted, bool Normal, bool Undefined, bool Deleted)
        {
            List<MLink> lin = new List<MLink>();
            foreach (MLink l in axis)
            {
                //filter link by state and type
                MLinkType s = l.eLinkType;//check link type
                MLinkState st = l.eLinkState;//check link state
                if (((st == MLinkState.Deleted) && Deleted) || ((s == MLinkType.Normal) && Normal) || ((s == MLinkType.Restricted) && Restricted) || ((s == MLinkType.Undefined) && Undefined))
                    lin.Add(l); //add to list
            }
            //sort list in order: Restricted, Normal, Deleted, Undefined
            if (withSort && (lin.Count > 1)) lin.Sort(MLink.SortByLinkType);//sort if two or more links
            //return link list
            return lin;
        }

        /// <summary>
        /// NT-Delete all halfLink's from current object or mark as deleted
        /// </summary>
        /// <param name="axis">Axis list for work</param>
        /// <param name="targetID">Target cell ID</param>
        /// <param name="remove">False if links only to mark as deleted, True - remove all link from list</param>
        protected internal void L0DeleteHLink(List<MLink> axis, MID targetID, bool remove)
        {
            //if remove = true, get all links else exclude Deleted 
            List<MLink> lar = L0GetLinksListToObj(axis, targetID, false, true, true, true, remove);
            if (remove)
                foreach (MLink l in lar) axis.Remove(l); //delete all
            else
                foreach (MLink l in lar) l.eLinkState = MLinkState.Deleted;//mark all as deleted
            return;
        }

        /// <summary>
        /// NT-Delete all halflinks to any objects of target class
        /// </summary>
        /// <param name="classId">Class Id for searching</param>
        /// <param name="axis">Axis for work</param>
        /// <param name="remove">False if links only to mark as deleted, True - remove all link from list</param>
        protected internal void L0DeleteHLinkAnyObj(List<MLink> axis, uint classId, bool remove)
        {
            //get sorted list of links to any object of specified class
            //if remove = true, get all links else exclude Deleted 
            List<MLink> lar = L0GetLinksListToAnyObj(axis, classId, true, true, true, true, remove);
            if (remove)
                foreach (MLink l in lar) axis.Remove(l); //delete all
            else
                foreach (MLink l in lar) l.eLinkState = MLinkState.Deleted;//mark all as deleted
            return;
        }

        /// <summary>
        /// NT-add to current object new halflink to target object - with check to existing links, without change class links - NT
        /// </summary>
        /// <param name="axis">Axis list for work</param>
        /// <param name="link">Link object</param>
        /// <exception cref="SeLinkAlreadyExistsException">One or more actual links already exists</exception>
        /// <exception cref="SeArgumentException">Link has invalid SrcId</exception>
        protected internal void L0AddHLink(List<MLink> axis, MLink link)
        {
            //check the link src object.It must be current object.
            if (!this.m_id.isEqual(link.SrcObjectID)) throw new SeArgumentException("Argument \"link\" has invalid SrcObjID !");
            //get Normal or Restricted links, not sorted
            List<MLink> lar = this.L0GetLinksListToObj(axis, link.DestObjectID, false, true, true, false, false);
            if (lar.Count == 0) axis.Add(link);   //if links not found, add new link to list
            else
            {
                //list has one or more link to this object. Throw Exception
                throw new SeLinkAlreadyExistsException(link.getCopy());   //"Object already has links here."
            }
        }

        /// <summary>
        /// NT-add to current object new, active halflink to target object - with check to existing links, without change template, without target ref
        /// </summary>
        /// <param name="axis">Axis list for work</param>
        /// <param name="trgId">Target cell Id for new link</param>
        /// <param name="typ">Type of new link: Restricted, Normal, Undefined</param>
        /// <exception cref="SeLinkAlreadyExistsException">One or more actual links already exists</exception>
        /// <exception cref="SeArgumentException">Link has invalid SrcId</exception>
        protected internal void L0AddHLink(List<MLink> axis, MID trgId, MLinkType typ)
        {
            //create link object
            MLink lin = new MLink(this.m_id, trgId, typ, MLinkState.Active, null);
            //add link
            L0AddHLink(axis, lin);
        }

        /// <summary>
        /// NT-Get active halflink to target object
        /// Return null if no links found; throw exception if links more than 1
        /// </summary>
        /// <param name="axis">Axis list for work</param>
        /// <param name="trgObjID">Target object ID</param>
        /// <returns>Link to target object or null if no links found</returns>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        protected internal MLink L0GetMainHLink(List<MLink> axis, MID trgObjID)
        {
            //get R or N links. Must be only one link in list
            List<MLink> lia = L0GetLinksListToObj(axis, trgObjID, false, true, true, false, false);//get links with N or R states. D and U states is equal to No links.
            if (lia.Count < 1) return (MLink)null; //if no links return Null
            else if (lia.Count > 1) throw new  SeTooManyLinksException(this);   //"Invalid base format. More than one active link exists."
            else return lia[0];
        }
        /// <summary>
        /// NT-Get type of halflink to target object
        /// </summary>
        /// <param name="axis">Axis list for work</param>
        /// <param name="trgID">Target object ID</param>
        /// <returns>Main type of links or MLinkType.NotFound if no links found</returns>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        protected internal MLinkType L0GetMainHLinkType(List<MLink> axis, MID trgID)
        {
            MLink li = L0GetMainHLink(axis, trgID);
            if (li == null) return MLinkType.NotFound;
            else return li.eLinkType;
        }

        /// <summary>
        /// NT-Delete link from two linked object without any checking or mark as deleted
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Target object</param>
        /// <param name="remove">True - remove link, False - mark link as deleted</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal void L0DeleteLinkNoCheck(Axiss axis, MCell targObj, bool remove)
        {
            //simple delete link from two linked objects
            this.L0DeleteHLink(this.getAxisList(axis), targObj.ID, remove);
            targObj.L0DeleteHLink(targObj.getInverseAxisList(axis), this.ID, remove);
        }

        /// <summary>
        /// NT-Create or replace link to target object without any checking 
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Target object</param>
        /// <param name="linkType">Link type</param>
        /// <param name="Replace">True - get existing link (slow) and replace link type. False - create new link</param>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal void L0AddLinkNocheck(Axiss axis, MCell targObj, MLinkType linkType, bool Replace)
        {
            if (Replace)
            {
                //get two links
                MLink ml = L0GetMainHLink(this.getAxisList(axis), targObj.ID);
                MLink mn = targObj.L0GetMainHLink(targObj.getInverseAxisList(axis), this.ID);
                if ((ml != null) && (mn != null)) //link exists - change link state only
                {
                    ml.eLinkType = linkType;
                    mn.eLinkType = linkType;
                    return;
                }
                else if (((ml == null) && (mn != null)) || ((ml != null) && (mn == null))) //if one of two halflinks exist only
                    throw new SeInvalidBaseException(SeInvalidBaseException.noHalfLinkMsg, this);
            }
             //link not exists - simple create full link to target object 
             MLink ul = new MLink(this.ID, targObj.ID, linkType, MLinkState.Active, targObj);
             List<MLink> li = this.getAxisList(axis);
             li.Add(ul);
             ul = new MLink(targObj.ID, this.ID, linkType, MLinkState.Active, this);
             li = targObj.getInverseAxisList(axis);
             li.Add(ul);
             return;
        }

        /// <summary>
        /// NT-Get link type between two cells.
        /// Returns MLinkType.NotFound if no links found; throw exception if more than one links found
        /// </summary>
        /// <param name="axis">Axis for work</param>
        ///<param name="dstCell">Dest cell</param>
        /// <returns>Main type of links or MLinkType.NotFound if no links found</returns>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal MLinkType L0GetLinkType(Axiss axis, MCell dstCell)
        {
            //get link types
            MLinkType s0 = this.L0GetMainHLinkType(getAxisList(axis), dstCell.ID);
            MLinkType s1 = dstCell.L0GetMainHLinkType(dstCell.getInverseAxisList(axis), this.ID);
            if (s0 != s1) throw new SeLinkStateMismatchException(); //"Неправильный формат базы! Состояния связей между связанными объектами не совпадают.");
            else return s0;
        }

        /// <summary>
        /// Change link type between two cells
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Linked cell</param>
        /// <param name="typ">New type of link</param>
        /// <exception cref="SeInvalidBaseException">Structure error! One halflink is absent</exception>
        /// <exception cref="SeLinkNotFoundException">Link not found</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        protected internal void L0changeLinkType(Axiss axis, MCell targObj, MLinkType typ)
        {
            //get two links
            MLink ml = L0GetMainHLink(this.getAxisList(axis), targObj.ID);
            MLink mn = targObj.L0GetMainHLink(targObj.getInverseAxisList(axis), this.ID);
            if ((ml != null) && (mn != null)) //link exists - change link state only
            {
                ml.eLinkType = typ;
                mn.eLinkType = typ;
                return;
            }
            else if ((ml == null) && (mn == null)) throw new SeLinkNotFoundException();
            else throw new SeInvalidBaseException(SeInvalidBaseException.noHalfLinkMsg, this);
        }

        /// <summary>
        /// NT-Change halflink type for any object of target class
        /// </summary>
        /// <param name="lim">List of link for axis</param>
        /// <param name="clsId">Target class Id</param>
        /// <param name="newType">New type of link</param>
        protected internal void L0ChangeHalfLinkType(List<MLink> lim, uint clsId, MLinkType newType)
        {
            foreach (MLink li in lim)
            {
                if ((li.DestObjectID.ClassID == clsId) && (li.eLinkState == MLinkState.Active)) li.eLinkType = newType;
            }
        }

        #endregion


        #region *** Other ***

        /// <summary>
        /// 150611 NT-Check two cells linked over hierarchy. Return number of levels on founded path, may be few pathes in graph! 
        /// </summary>
        /// <param name="axis">Axis from upper class to downer (typ. Ydn Xdn Zdn)</param>
        /// <param name="upCls">Upper cell in hierarchy, can be system class or object</param>
        /// <param name="dnCls">Downer cell in hierarchy, can be system class or object</param>
        /// <param name="leveLimit">Limit for level checking, 3 = max 3 levels walk</param>
        /// <returns>Returns number of levels between two cells on founded path, -1 if no link or if limit exceeded, 0 if src ID same as dst ID, 1 if cells linked immediately. It may be not minimal path!</returns>
        /// <remarks>
        /// Detour from below upwards, is optimised for trees, used recurse without SearchFlag field.
        /// It is used for check of reduction of datatypes by search and method execution.
        /// Does not lead search through system classes, but it is possible to use them as initial/final classes in search.
        /// To start from the bottom class. From the top will long search.
        ///</remarks>
        ///<exception cref="SeArgumentException">Invalid axis code</exception>
        ///<exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        public static Int32 intGetCellsHierarhyLevel(Axiss axis, MCell upCls, MCell dnCls, uint leveLimit)
        {
            if (upCls.ID.isEqual(dnCls.ID)) return 0;//src same as dest
            //1-проверить, что оба класса вообще имеют какие-либо связи в соответствующей оси. Если нет, вернуть -1. Для ускорения.
            //get normal halflinks
            if ((upCls.getAxisList(axis).Count == 0) || (dnCls.getInverseAxisList(axis).Count == 0)) return -1;//no links
            //2 проверить, нет ли непосредственной связи между классами - для ускорения поиска.
            MLinkType tt = upCls.L0GetLinkType(axis, dnCls);
            if (tt == MLinkType.Normal) return 1; //have direct link
            //3 запустить рекурсию снизу вверх для каждого связанного класса
            int res = getHierLevelRecurse(MCell.inverseAxis(axis), dnCls, upCls.ID, leveLimit, 0);
            return res;
        }
        /// <summary>
        /// 150611 NT-Helper function for intGetClassHierarhyLevel
        /// </summary>
        /// <param name="axis">Axis for search</param>
        /// <param name="cls">Current cell, can be system class or object</param>
        /// <param name="trgID">Target cell ID, can be system class or object</param>
        /// <param name="levLimit">Search depth limit</param>
        /// <param name="level">Current level</param>
        /// <returns>Returns -1 if nothing founded, level of founded cell if success</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        private static Int32 getHierLevelRecurse(Axiss axis, MCell cls, MID trgID, uint levLimit, int level)
        {
            //ограничить работу по лимиту глубины
            //if (level == levLimit) return -1;//not found anything

            Int32 result;
            int lev = level + 1;//level не передается через рекурсию почему-то
            //получить список ИД связанных классов с типом связи Normal, быстро.
            //искать в нем ид конечного класса
            //если  не найдено, получать каждый класс,включая системные, и запускать для него рекурсивно поиск.
            List<MLink> li = cls.getAxisList(axis);
            foreach (MLink lin in li)
            {
                if ((lin.eLinkType == MLinkType.Normal) && (lin.eLinkState == MLinkState.Active))
                    if (lin.DestObjectID.isEqual(trgID))
                    {
                        //Нашли. Чего делать-то?
                        return lev;
                    }
            }
            //если  не найдено, получать каждый класс и запускать для него рекурсивно поиск.
            //если класс системный, исключить его из поиска. Системные классы в существующей архитектуре не являются частью иерархии.
            //если лимит достигнут, не проводить поиск 
            if (levLimit > lev)
                foreach (MLink lin in li)
                {
                    if ((lin.eLinkType == MLinkType.Normal) && (lin.eLinkState == MLinkState.Active) && (lin.DestObjectID.isUserClassOrObject))
                    {
                        MCell c = cls.Container.getCell(lin.DestObjectID);//get cell from container
                        result = getHierLevelRecurse(axis, c, trgID, levLimit, lev);//call recurse 
                        if (result > 0) return result;//if found, break loop and return result
                    }
                }
            return -1; //nothing found
        }

        #endregion

        #region *** ExecuteMethod functions ***

        /// <summary>
        /// NT-Execute method by method number 
        /// </summary>
        /// <param name="num">Method number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="args">Argument array or null</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Need complex testing and refactoring code in kta using!</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(uint num, MIDType retType, bool linkedClass, Object[] args)
        {
            //1-получить метод из контейнера по номеру. Если null, выдать исключение SeMethodNotFound.
            MMethod m = this.Container.intGetMethod(num);
            if (m == null) throw new SeMethodNotFoundException(num);
            //2-если число аргументов в кта0 метода не равно числу аргументов вызова, выдать исключение вроде SeInvalidArgCount
            //    -для ускорения.
            if(m.checkArgsCount(args) == false) throw new SeMethodArgOrderInvalidException(m.KTA_0.KtaID);
            //3-если Linked=True и метод не связан с классом, выдать исключение SeMethodNotLinked или вроде того.
            //    -для поддержки привязанных методов
            if((linkedClass == true) && (!m.L1checkCmLinkExists(this.ID.ClassID))) 
                throw new SeMethodNotLinkedException(new McmLink(this.ID, m.KTA_0.KtaID)); //exception with ClassMethod link 
            //4-сформировать ктаХ из аргументов  MKTA.FillKtaArgs(...)
            MKTA kta = MKTA.intFillKtaArgs(this, retType, args);
            //5-проверить пригодность метода и найти подходящий кта. (???)
            List<MKTA> ktas = m.findUsefulKtas(kta);//Check kta and return list of useful ktas
            if (ktas.Count < 1) throw new SeMethodKtaNotFoundException(m.ID);//TODO: founded kta's not used, only count is used!
            //6 вызвать MMethod.Run(MEngine cont, MCell caller, MKTA ktaX);
            Object res = m.Run(this.Container, this, kta);
            return res;
        }
        /// <summary>
        /// NT-Execute method by method name 
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="args">Argument array or null</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Need complex testing and refactoring code in kta using!</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(string name,  MIDType retType, bool linkedClass, Object[] args)
        {
            //1-получить список методов из контейнера по имени. Если пустой, выдать исключение SeMethodNotFound.
            List<MMethod> lm = this.Container.intGetMethodsByName(name);
            if (lm.Count == 0) throw new SeMethodNotFoundException(name);
            //2-Из этого списка отобрать методы по критериям:
            //  -если число аргументов в кта0 метода равно числу аргументов вызова 
            //    -для ускорения.
            //  -если Linked=True и метод связан с классом
            //    -для поддержки привязанных методов
            // из отобранных методов сделать новый список. если он пустой, выдать исключение SeMethodNotFound.
            List<MMethod> lmm = new List<MMethod>();
            foreach (MMethod mm in lm)
            {
                if (mm.checkArgsCount(args) == false) continue;
                if ((linkedClass == true) && (mm.L1checkCmLinkExists(this.ID.ClassID)== false)) continue;
                //add method to list
                lmm.Add(mm);
            }
            if (lmm.Count == 0) throw new SeMethodNotFoundException(name);
            //список lm больше не нужен, выгрузить из памяти.
            //3-сформировать ктаХ из аргументов 
            MKTA kta = MKTA.intFillKtaArgs(this, retType, args);
            //5-Для каждого метода в списке проверить пригодность метода и найти подходящий кта. (???)
            //    -получим список кта, из которых нужно отобрать один пригодный, от которого нужен только номер метода.
            List<MKTA> ktas = new List<MKTA>();
            List<MKTA> tmp;
            foreach (MMethod mmm in lmm)
            {
                //get list of filtered kta for this usecase 
                tmp = mmm.findUsefulKtas(kta);
                //add kta's to final list 
                if(tmp.Count > 0) ktas.AddRange(tmp);
            }
            if (ktas.Count == 0) throw new SeMethodKtaNotFoundException(name); //не удалось найти подходящий кта
            //6-выбрать лучший кта из этого списка - по вызывающему классу, по числу вызовов, по оценке качества.
            //    -вернуть номер метода выбранного кта.
            //TODO: как выбрать лучший кта из общего списка? Выбрать автоматически или запросить пользователя? Пока неясно.
            MKTA bestKta = findBestKta(ktas, null);
            //7-получить выбранный метод из lmm списка или из контейнера. Из списка быстрее.
            //но если в списке кта метода могут присутствовать кта других методов, то lmm список может не содержать выбранного метода.
            //поэтому код здесь зависит от этой фичи.
            //MMethod met = this.Container.intGetMethod(bestKta.KtaID.MethodID); //переделать на получение из локального списка lmm
            MMethod met = null;
            foreach (MMethod mt in lmm)
            {
                if (mt.ID == bestKta.KtaID.MethodID)
                {
                    met = mt;
                    break;
                }
            }
            if (met == null) throw new SeMethodNotFoundException(name);
            //8-вызвать MMethod.Run(MEngine cont, MCell caller, MKTA ktaX);
            Object res = met.Run(this.Container, this, kta);
            return res;
            //конец
        }

        /// <summary>
        /// NT-Find better kta from list or prompt user for select
        /// </summary>
        /// <param name="ktas">List of ktas for select</param>
        /// <param name="dlgUser">User dialog (with fixed semantic) for manual select kta or null if automatic select only</param>
        /// <returns>Selected kta</returns>
        /// <remarks>Need complex testing and refactoring code in kta using!</remarks>
        private MKTA findBestKta(List<MKTA> ktas, Form dlgUser)
        {
            if (dlgUser != null)
            {
                //construct and show dialog with available kta's. User can select one of them.
                Form dlg = new Form();
                //add parameters: ktas, this
                //return selected kta
            }
            //TODO: now simple return first kta in list - for debug only
            return ktas[0];
        }
        /// <summary>
        /// NT-Execute method by kta number 
        /// </summary>
        /// <param name="ktaid">Method kta number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="args">Argument array</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Need complex testing and refactoring code in kta using!</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(MKtaID ktaid, MIDType retType, bool linkedClass, Object[] args)
        {
            //1-получить метод из контейнера по номеру. Если null, выдать исключение SeMethodNotFound.
            MMethod m = this.Container.intGetMethod(ktaid.MethodID);
            if (m == null) throw new SeMethodNotFoundException(ktaid.MethodID);
            //2-если число аргументов в кта0 метода не равно числу аргументов вызова, выдать исключение вроде SeInvalidArgCount
            //    -для ускорения.
            if (m.checkArgsCount(args) == false) throw new SeMethodArgOrderInvalidException(m.KTA_0.KtaID);
            //3-если Linked=True и метод не связан с классом, выдать исключение SeMethodNotLinked или вроде того.
            //    -для поддержки привязанных методов
            if ((linkedClass == true) && (!m.L1checkCmLinkExists(this.ID.ClassID)))
                throw new SeMethodNotLinkedException(new McmLink(this.ID, m.KTA_0.KtaID)); //exception with ClassMethod link 
            //4-сформировать ктаХ из аргументов  MKTA.FillKtaArgs(...)
            MKTA kta = MKTA.intFillKtaArgs(this, retType, args);
            //5-получить указанный кта из метода по номеру кта. 
            //  если кта существует, переписать в ктаХ значения некоторых полей из него. (каких именно полей - потом ясно будет)
            //  иначе проверить пригодность метода и найти подходящий кта. (???)
            MKTA ktat = m.intGetKta(ktaid);
            if (ktat != null)
            {
                //TODO: make fields copy here...

            }
            else
            {
                List<MKTA> ktas = m.findUsefulKtas(kta);//Check kta and return list of useful ktas
                if (ktas.Count < 1) throw new SeMethodKtaNotFoundException(m.ID);//TODO: founded kta's not used, only count is used!
            }
            //6 вызвать MMethod.Run(MEngine cont, MCell caller, MKTA ktaX);
            Object res = m.Run(this.Container, this, kta);
            return res;
        }

        /// <summary>
        /// NR-Execute method by method number with hierarchy
        /// </summary>
        /// <param name="num">Method number</param>
        /// <param name="axis">Hierarchy axis</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="args">Argument array</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Not implemented! Need complex testing and refactoring code in kta using!</remarks>
        public Object ExecuteMethodHierarchy(uint num, Axiss axis, MIDType retType, bool linkedClass, Object[] args)
        {
            //1-получить метод из контейнера по номеру. Если null, выдать исключение SeMethodNotFound.
            //MMethod m = this.Container.intGetMethod(num);
            //if (m == null) throw new SeMethodNotFoundException(num);
            //2-рекурсивно пройти по оси axis связей метод-метод и составить список методов, удовлетворяющих условиям:
            //  (уточнить...)
            //  -число аргументов в кта0 метода равно числу аргументов вызова
            //  -если Linked=True и метод связан с классом.
            //    -для поддержки привязанных методов
            //  -если возвращаемый методом тип соответствует retType (??? тут как-то надо использовать иерархию данных, но как и где?)
            //3?   
            //4-сформировать ктаХ из аргументов  MKTA.FillKtaArgs(...)
            //5-Для каждого метода в списке проверить пригодность метода и найти подходящий кта. (??? тут как-то надо использовать иерархию данных, но как и где?)
            //    -получим список кта, из которых нужно отобрать один пригодный, от которого нужен только номер метода.
            //6-выбрать лучший кта из этого списка - по вызывающему классу, по числу вызовов, по оценке качества.
            //    -вернуть номер метода выбранного кта.
            //7-получить выбранный метод из списка или из контейнера. Из списка быстрее.
            //8-вызвать MMethod.Run(MEngine cont, MCell caller, MKTA ktaX);

            throw new NotImplementedException();
        }
        /// <summary>
        /// NR-Execute method by method name with hierarchy
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="axis">Hierarchy axis</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="args">Argument array</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Not implemented! Need complex testing and refactoring code in kta using!</remarks>
        public Object ExecuteMethodHierarchy(string name, Axiss axis, MIDType retType, bool linkedClass, Object[] args)
        {
            //1-получить список методов из контейнера по имени. Если null, выдать исключение SeMethodNotFound.
            //2-рекурсивно пройти по оси axis связей метод-метод и составить список методов, удовлетворяющих условиям:
            //  (уточнить...)
            //  -число аргументов в кта0 метода равно числу аргументов вызова
            //  -если Linked=True и метод связан с классом.
            //    -для поддержки привязанных методов
            //  -если возвращаемый методом тип соответствует retType (??? тут как-то надо использовать иерархию данных, но как и где?)
            //3?   
            //4-сформировать ктаХ из аргументов  MKTA.FillKtaArgs(...)
            //5-Для каждого метода в списке проверить пригодность метода и найти подходящий кта. (??? тут как-то надо использовать иерархию данных, но как и где?)
            //    -получим список кта, из которых нужно отобрать один пригодный, от которого нужен только номер метода.
            //6-выбрать лучший кта из этого списка - по вызывающему классу, по числу вызовов, по оценке качества.
            //    -вернуть номер метода выбранного кта.
            //7-получить выбранный метод из списка или из контейнера. Из списка быстрее.
            //8-вызвать MMethod.Run(MEngine cont, MCell caller, MKTA ktaX);
            throw new NotImplementedException();
        }

        #region     ExecuteMethod wrappers

        /// <summary>
        /// NT-Execute method by method number without any arguments 
        /// </summary>
        /// <param name="num">Method number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(uint num, MIDType retType, bool linkedClass)
        {
            return ExecuteMethod(num, retType, linkedClass, null);
        }
        /// <summary>
        /// NT-Execute method by method number with one argument
        /// </summary>
        /// <param name="num">Method number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="arg0">Method Argument</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(uint num, MIDType retType, bool linkedClass, Object arg0)
        {
            Object[] ob = new Object[] {arg0};
            return ExecuteMethod(num, retType, linkedClass, ob);
        }
        /// <summary>
        /// NT-Execute method by method number with two arguments
        /// </summary>
        /// <param name="num">Method number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="arg0">Method argument</param>
        /// <param name="arg1">Method argument</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(uint num, MIDType retType, bool linkedClass, Object arg0, Object arg1)
        {
            Object[] ob = new Object[] {arg0, arg1};
            return ExecuteMethod(num, retType, linkedClass, ob);
        }
        /// <summary>
        /// NT-Execute method by method number with three arguments
        /// </summary>
        /// <param name="num">Method number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="arg0">Method argument</param>
        /// <param name="arg1">Method argument</param>
        /// <param name="arg2">Method argument</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(uint num, MIDType retType, bool linkedClass, Object arg0, Object arg1, Object arg2)
        {
            Object[] ob = new Object[] { arg0, arg1, arg2 };
            return ExecuteMethod(num, retType, linkedClass, ob);
        }
        //*******************************************************************************
        /// <summary>
        /// NT-Execute method by method name without any arguments
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(string name, MIDType retType, bool linkedClass)
        {
            return ExecuteMethod(name, retType, linkedClass, null);
        }
        /// <summary>
        /// NT-Execute method by method name with one argument
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <param name="arg0">Method argument</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(string name, MIDType retType, bool linkedClass, Object arg0)
        {
            return ExecuteMethod(name, retType, linkedClass, new Object[] { arg0 });
        }
        /// <summary>
        /// NT-Execute method by method name with two argument
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <param name="arg0">Method argument</param>
        /// <param name="arg1">Method argument</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(string name, MIDType retType, bool linkedClass, Object arg0, Object arg1)
        {
            return ExecuteMethod(name, retType, linkedClass, new Object[] { arg0, arg1 });
        }
        /// <summary>
        /// NT-Execute method by method name with two argument
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <param name="arg0">Method argument</param>
        /// <param name="arg1">Method argument</param>
        /// <param name="arg2">Method argument</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(string name, MIDType retType, bool linkedClass, Object arg0, Object arg1, Object arg2)
        {
            return ExecuteMethod(name, retType, linkedClass, new Object[] { arg0, arg1, arg2 });
        }
        //*******************************************************************************
        /// <summary>
        /// NT-Execute method by kta number 
        /// </summary>
        /// <param name="ktaid">Method kta number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(MKtaID ktaid, MIDType retType, bool linkedClass)
        {
            return ExecuteMethod(ktaid, retType, linkedClass, null);
        }
        /// <summary>
        /// NT-Execute method by kta number 
        /// </summary>
        /// <param name="ktaid">Method kta number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <param name="arg0">Method argument</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(MKtaID ktaid, MIDType retType, bool linkedClass, Object arg0)
        {
            return ExecuteMethod(ktaid, retType, linkedClass, new Object[] { arg0 });
        }
        /// <summary>
        /// NT-Execute method by kta number 
        /// </summary>
        /// <param name="ktaid">Method kta number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <param name="arg0">Method argument</param>
        /// <param name="arg1">Method argument</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(MKtaID ktaid, MIDType retType, bool linkedClass, Object arg0, Object arg1)
        {
            return ExecuteMethod(ktaid, retType, linkedClass, new Object[] { arg0, arg1 });
        }
        /// <summary>
        /// NT-Execute method by kta number 
        /// </summary>
        /// <param name="ktaid">Method kta number</param>
        /// <param name="retType">Type and semantic type of return value</param>
        /// <param name="linkedClass">True - execute if method linked to caller class. False - execute anyway</param>
        /// <param name="arg0">Method argument</param>
        /// <param name="arg1">Method argument</param>
        /// <param name="arg2">Method argument</param>
        /// <returns>Returns value returned by method code</returns>
        /// <remarks>Function wrapper</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        /// <exception cref="SeMethodNotLinkedException">Method not linked to class</exception>
        /// <exception cref="SeMethodKtaNotFoundException">Kta not found</exception>
        public Object ExecuteMethod(MKtaID ktaid, MIDType retType, bool linkedClass, Object arg0, Object arg1, Object arg2)
        {
            return ExecuteMethod(ktaid, retType, linkedClass, new Object[] { arg0, arg1, arg2 });
        }


        #endregion

        #endregion

    }
}
