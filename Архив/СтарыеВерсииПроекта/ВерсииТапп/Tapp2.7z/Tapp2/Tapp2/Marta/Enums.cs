﻿
namespace Marta
{
    /// <summary>
    /// Defines link states: Active or Deleted
    /// </summary>
    public enum MLinkState
    {
        /// <summary>
        /// Link is active
        /// </summary>
        Active = 0,
        /// <summary>
        /// Link is deleted - link non-actual and must be deleted physically by Optimizer service
        /// </summary>
        Deleted = 1,
    }

    /// <summary>
    /// Defines link types: Undefined, Normal, Restricted
    /// </summary>
    public enum MLinkType
    {
        /// <summary>
        /// Restricted link - prohibite link between classes or objects
        /// </summary>
        /// <remarks>For objects - prohibite link between specified objects, for templates (classes) - prohibite link between any objects of these classes</remarks>
        Restricted = 3,

        /// <summary>
        /// Normal link 
        /// </summary>
        Normal = 2,

        /// <summary>
        /// Undefined link - for automate data serving.
        /// </summary>
        /// <remarks>
        /// Means that link is broken and Optimizer should find destination or warn the User. 
        /// </remarks>
        Undefined = 1,
        /// <summary>
        /// Link not found. Internal. For link search result only.
        /// </summary>
        NotFound = 0,
    }

    /// <summary>
    /// Defines object or class state: Normal, Deleted, Undefined
    /// </summary>
    public enum MCellState
    {
        /// <summary>
        /// Normal state
        /// </summary>
        Normal = 0,
        /// <summary>
        /// Ready to delete
        /// </summary>
        /// <remarks>
        /// Class or object marked by this state should be deleted by automatic optimizer
        /// </remarks>
        Deleted,
        /// <summary>
        /// Not used now, reserved
        /// </summary>
        Restricted,
        /// <summary>
        /// Undefined state of class or object - this means that User or Optimizer attention needs.
        /// </summary>
        Undefined,
        /// <summary>
        /// Not used now, reserved
        /// </summary>
        Unknown,
        /// <summary>
        /// Not used now, reserved
        /// </summary>
        Nothing
    }

    /// <summary>
    /// Define system object names for semantic data identification
    /// </summary>
    /// <remarks></remarks>
    public enum SystemObjectNames
    {
        /// <summary>
        /// Class ID 
        /// </summary>
        Main = 0,
        /// <summary>
        /// Unknown object
        /// </summary>
        Unknown = 1,
        /// <summary>
        /// Undefined object
        /// </summary>
        Undefined = 2,
        /// <summary>
        /// Nothing object
        /// </summary>
        Nothing = 3,
        /// <summary>
        /// Unused system object
        /// </summary>
        /// <remarks>
        /// This ID is fictive and used to specify that current argument has not semantic data type (not MClass MObj datatype).
        /// You cannot use this object.
        /// </remarks>
        Unused = 255,
    }
    /// <summary>
    /// Define system class names for semantic data identification
    /// </summary>
    public enum SystemClassNames
    {
        /// <summary>
        /// Start class of database view
        /// </summary>
        World = 0,
        /// <summary>
        /// Class "Unknown"
        /// </summary>
        Unknown = 1,
        /// <summary>
        /// Class "Undefined"
        /// </summary>
        Undefined = 2,
        /// <summary>
        /// Class "Nothing"
        /// </summary>
        Nothing = 3,
        /// <summary>
        /// Unused system class
        /// </summary>
        /// <remarks>
        /// This ID is fictive and used to specify that current argument has not semantic data type (not MClass MObj datatype).
        /// You cannot use this class.
        /// </remarks>
        Unused = 255,
    }


    /// <summary>
    /// Defines axis of links: X, Y, Z
    /// </summary>
    public enum Axiss
    {
        /// <summary>
        /// Aggregation Up axis (X+)
        /// </summary>
        Xup = 0,

        /// <summary>
        /// Aggregation Down axis (X-)
        /// </summary>
        Xdown = 1,

        /// <summary>
        /// Abstraction Up axis (Y+)
        /// </summary>
        Yup = 2,

        /// <summary>
        /// Abstraction Down axis (Y-)
        /// </summary>
        Ydown = 3,

        /// <summary>
        /// Reserved Up axis (Z+)
        /// </summary>
        Zup = 4,

        /// <summary>
        /// Reserved Down axis (Z-)
        /// </summary>
        Zdown = 5,
    }

}