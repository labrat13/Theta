using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Marta
{
    /// <summary>
    /// Class represent semantic data object 
    /// </summary>
    public class MObj : MCell
    {
        /// <summary>
        /// Default constructor for XML. Do not use this constructor outside Marta!
        /// </summary>
        public MObj()
        {
            m_isClass = false; //current cell represent object
        }
        /// <summary>
        /// Params constructor. Do not use this constructor outside Marta!
        /// </summary>
        /// <param name="objId">Object ID</param>
        /// <param name="name">Object name</param>
        /// <param name="comment">Object comment</param>
        /// <param name="cellData">Object data</param>
        /// <param name="dataType">Datatype of data</param>
        internal MObj(MID objId, string name, String comment, Object cellData, Type dataType)
            : base(objId, name, comment, cellData, dataType)
        {

            m_isClass = false; //current cell represent object
        }

        /// <summary>
        /// Get reference to parent class
        /// </summary>
        [XmlIgnore]
        public MClass Parent
        {
            get
            {
                return (MClass)m_parent;
            }
        }

        /// <summary>
        /// Get reference to container
        /// </summary>
        [XmlIgnore]
        public override MEngine Container
        {
            get { return (MEngine)((MClass)m_parent).Parent; }
        }

        /// <summary>
        /// Set backrefs to parent class
        /// </summary>
        /// <param name="clsref">Reference to class</param>
        internal void intSetBackRefs(MClass clsref)
        {
            m_parent = clsref;
        }

        /// <summary>
        /// Return string representation of object
        /// </summary>
        /// <returns>Return short string description of object for debugger</returns>
        public override string ToString()
        {
            return String.Format("{0} {1} {2}", this.m_id.ToString(), getQualifiedName(), this.m_state.ToString());
        }
        /// <summary>
        /// Get full qualified object name - Class::Object
        /// </summary>
        /// <returns>Full qualified object name</returns>
        public String getQualifiedName()
        {
            return String.Format("{0}::{1}", this.Parent.Name, this.m_name);
        }

        /// <summary>
        /// NT-Remove current user object from object list
        /// </summary>
        /// <param name="markOnly">True - mark as deleted, False - remove object</param>
        /// <exception cref="SeInvalidUseSystemObjectException">Current object is system object</exception>
        public void Delete(bool markOnly)
        {
            if (!this.ID.isUserObject) throw new SeInvalidUseSystemObjectException(this); //current object is system object
            //add some specific code here... 
            if (markOnly) this.State = MCellState.Deleted;
            else this.Parent.Objects.Remove(this);
        }

        #region Method functions
        // Not specific method functions placed to MCell class
        #endregion

        #region Public Link functions
       /// <summary>
        /// NT-Create Link to target object with specified linktype
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Target object</param>
        /// <param name="newType">Link type</param>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeArgumentException">Target class same as current class</exception>
        /// <exception cref="SeRestrictedLinkOnlyException"></exception>
        /// <exception cref="SeLinkAlreadyExistsException"></exception>
        /// <exception cref="SeLinkNotFoundException">Link not exists</exception>
        public void createLink(Axiss axis, MObj targObj, MLinkType newType)
        {
            //check - source object and target object is same object
            if(this.ID.isEqual(targObj.ID)) throw new SeArgumentException(SeArgumentException.srcSameTrgMsg, this); // "Target class same as current class");
            //get link states from classes.
            //if actual links not exists, return error "Links between classes not exists". If links >1 - "Invalid database format" 
            //if between templates link states not equal, return error "Invalid database format"
           //if between templates link states  = Restricted, and new state != Resctricted, return error "Links between objects restricted/prohibited"
            if (intCheckClassLinkType(axis, targObj, newType) == false)
                throw new SeRestrictedLinkOnlyException(this);//"����� ����� ����� �������� ���������! ������ ������� ����� ������� ���� ����� ���������.");
            //���� ����� ����� ��������� ��� ����������, ������ ����������.
            //TODO: ��� ����� ��������, �� ���� ������ ��� �����.
            MLinkType mlt = this.L0GetLinkType(axis, targObj);
            if (mlt != MLinkType.NotFound) throw new SeLinkAlreadyExistsException();
            //delete links between two objects... ���� ������� ����� � �������� ������������(���� ��� ����), �� �� ������� ��������� �������.
            this.L0DeleteLinkNoCheck(axis, targObj.Parent.getUndefinedObj(), true);//�������� ������ Undefined ���� ������, ������� ����� (���� ��� ����)
            targObj.L0DeleteLinkNoCheck(MCell.inverseAxis(axis), this.Parent.getUndefinedObj(), true); // 
            //create new link between 2 objects
            this.L0AddLinkNocheck(axis, targObj, newType, false);
        } 

        /// <summary>
        /// NT-Delete link between two objects and restore Undefined link
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Target object</param>
        /// <exception cref="SeInvalidUseClassException">Invalid use class template as object</exception>
        /// <exception cref="SeLinkStateMismatchException">Link states mismatch between linked objects</exception>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeArgumentException">Target class same as current class</exception>
        /// <exception cref="SeLinkNotFoundException">If one of two halflinks exist only</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeInvalidUseClassException"></exception>
        public void deleteLink(Axiss axis, MObj targObj)
        {
            //check - source object and target object is same object
            if(this.ID.isEqual(targObj.ID) ) throw new SeArgumentException(SeArgumentException.srcSameTrgMsg, this); //"Target class same as current class");
            //get type of link between classes
            MLinkType st = this.Parent.L0GetLinkType(axis, targObj.Parent);
            //delete link 
            this.L0DeleteLinkNoCheck(axis, targObj, true);
            //restore undefined links with class link type
            this.intRestoreUndefinedLink(axis, targObj, st);
            targObj.intRestoreUndefinedLink(MCell.inverseAxis(axis), this, st);
        }
        /// <summary>
        /// NT-Get link state between linked objects.
        /// </summary>
        /// <param name="axis">Axis</param>
        /// <param name="targObj">Target object</param>
        /// <returns>Main type of links or MLinkType.NotFound if no links found</returns>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        public MLinkType getLinkType(Axiss axis, MObj targObj)
        {
            return this.L0GetLinkType(axis, targObj);
        }

        /// <summary>
        /// NT-Change link type
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Target object</param>
        /// <param name="typ">New type for link</param>
        /// <exception cref="SeInvalidBaseException">Structure error! One halflink is absent</exception>
        /// <exception cref="SeLinkNotFoundException">Link not found</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Target object same as current object</exception>
        /// <exception cref="SeRestrictedLinkOnlyException"></exception>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        public void changeLinkType(Axiss axis, MObj targObj, Marta.MLinkType typ)
        {
            //check - source object and target object is same object
            if (this.ID.isEqual(targObj.ID)) throw new SeArgumentException(SeArgumentException.srcSameTrgMsg, this); // "Target object same as current object");
            //1-check class link for Restricted type
            //get link states from classes.
            //if actual links not exists, return error "Links between classes not exists". If links >1 - "Invalid database format" 
            //if between templates link states not equal, return error "Invalid database format"
            //if between templates link states  = Restricted, and new state != Resctricted, return error "Links between objects restricted/prohibited"
            if (intCheckClassLinkType(axis, targObj, typ) == false)
                throw new SeRestrictedLinkOnlyException(this);//"����� ����� ����� �������� ���������! ������ ������� ����� ������� ���� ����� ���������."
            //   - �������� ����� ����� ���������.
            //- ���� ������ ������ 1, ����� � �������  ������������ ������ ���� ������   
            //- ���� ������ ���, ����� � ������� ��� ����� ����� ���������
            //- ������ �������� ���� ����� ����� ���������. �� ��������� �������� �� �����. ����� �������� ��������� ����� � �������� ���, 
            //   ����� ������� � ������� ������.
            this.L0changeLinkType(axis, targObj, typ);
        }


        #endregion

        #region Internal Link functions

        /// <summary>
        /// NT-Check templates link and linkstate for two objects. Return true if all OK. Return false if new linkstate is invalid.
        /// Throw SeLinkNotFoundException exception if link not exists.
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Target object</param>
        /// <param name="newType">New link type</param>
        /// <returns>True - new link type is allowed, false - disallowed</returns>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeLinkNotFoundException">Link not exists</exception>
        private bool intCheckClassLinkType(Axiss axis, MObj targObj, MLinkType newType)
        {
            //�������� ��������� ����� �������
            MLinkType st0 = this.Parent.L0GetLinkType(axis, targObj.Parent);
            //check class link exists
            if (st0 == MLinkType.NotFound) throw new SeLinkNotFoundException(this);//if link not exists
            //if class link state = Restricted, object link state cannot be other than
            else if ((st0 == MLinkType.Restricted) && (newType != MLinkType.Restricted)) return false;
            else return true;
        }

        /// <summary>
        /// NT-Restore undefined link to target object after link deleted
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targObj">Target object</param>
        /// <param name="st">Link type from class link</param>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeInvalidUseClassException"></exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        private void intRestoreUndefinedLink(Axiss axis, MObj targObj, MLinkType st)
        {
            //if current object is user object, restore link to undefined object
            //if current object is Undefined object, target object is user object, restore link to user object
            //else do nothing
            bool WithPlaceHolders = false;
            
            if (this.ID.isUserObject)
            {
                    //���������: ���� this ����� ����� � ����� �������� targObj ������, ����� � Undefined �� ���������.
                    //������ �� ������� �� ��� ��������: � placeholders ��� ��� ������. 
                    //bool � �������� �����. ����� ������ ����� ������������, ����� ������� �����.               
                if (WithPlaceHolders == false)
                {
                    List<MLink> li = this.L0GetLinksListToAnyObj(this.getAxisList(axis), targObj.ID.ClassID, false, true, true, false, false);
                    if (li.Count == 0)
                        this.intAddLinkNocheck(axis, targObj.ID.getID_Undefined(), st, false);//no replace
                }
                else this.intAddLinkNocheck(axis, targObj.ID.getID_Undefined(), st, false);//no replace
            }
            else if ((this.ID.IsUndefinedObject) && (targObj.ID.isUserObject))
            {
                this.L0AddLinkNocheck(axis, targObj, st, false);
            }
            return;
        }


        /// <summary>
        /// NT-Create or replace link to target object without any checking
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="mID">Target object ID</param>
        /// <param name="linkType">Link type</param>
        /// <param name="Replace">True - replace link type if link exists (slow). False - create link (fast)</param>
        /// <remarks>Specific to MObj only</remarks>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        private void intAddLinkNocheck(Axiss axis, MID mID, MLinkType linkType, bool Replace)
        {
            MObj ob = this.Parent.Parent.getObject(mID); //get object by ID
            this.L0AddLinkNocheck(axis, ob, linkType, Replace);//add link or replace if exists
        }

        /// <summary>
        /// NT-Change halflink type for any object of target class
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="clsId">Target class Id</param>
        /// <param name="newType">New link type</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal void L1ChangeHalfLinkType(Axiss axis, uint clsId, MLinkType newType)
        {
            this.L0ChangeHalfLinkType(this.getAxisList(axis), clsId, newType);
        }

        /// <summary>
        /// NT-Delete all halflinks to any objects of target class
        /// </summary>
        /// <param name="classId">class Id for searching</param>
        /// <param name="axis">Axis for work</param>
        /// <param name="remove">False if link mark as deleted, True - remove link from list</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal void L1DeleteHLinkAnyObj(Axiss axis, uint classId, bool remove)
        {
            this.L0DeleteHLinkAnyObj(this.getAxisList(axis), classId, remove);
        }




        #endregion




    }
}
