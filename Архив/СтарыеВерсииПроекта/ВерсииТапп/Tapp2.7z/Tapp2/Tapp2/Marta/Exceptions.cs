﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Marta
{
    /// <summary>
    /// General Base Exception class
    /// </summary>
    public class SeBaseException :Exception
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeBaseException()
            : base("Database work error.")
        {
        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeBaseException(string message):base(message)
        {
        }

        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeBaseException(string message, Exception inner)
            : base(message, inner)
        {
        }
        /// <summary>
        /// Param constructor with msg and obj
        /// </summary>
        /// <param name="msg">Message text</param>
        /// <param name="obj">Broken object</param>
        protected SeBaseException(String msg, Object obj):base (String.Format("{0}\n\n Broken object: {1} [{2}]", msg, obj.GetType().FullName, obj.ToString()))
        {
            //this.Data.Add("exData", obj); ошибка - передаваемый аргумент не является сериализуемым
            BrokenObject = obj;
        }
        /// <summary>
        /// Broken object
        /// </summary>
        private Object obj;

        /// <summary>
        /// Broken object thrown exception
        /// </summary>
        public Object BrokenObject
        {
            get { return obj; }
            set { obj = value; }
        }
    }
//***************************************************************
    /// <summary>
    /// General Code exception class
    /// </summary>
    public class SeCodeException :SeBaseException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeCodeException()
            : base("Error in database operation.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeCodeException(string message): base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeCodeException(string message, Exception inner) :base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with message and obj
        /// </summary>
        /// <param name="msg">Message text</param>
        /// <param name="obj">Broken object</param>
        protected SeCodeException(String msg, Object obj)
            : base(msg, obj)
        {
        }
        
    }


    /// <summary>
    /// General Data exception class
    /// </summary>
    public class SeDataException : SeBaseException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeDataException()
            : base("Invalid data.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeDataException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeDataException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with message and obj
        /// </summary>
        /// <param name="msg">Message text</param>
        /// <param name="obj">Broken object</param>
        protected SeDataException(String msg, Object obj)
            : base(msg, obj)
        {
        }
        
    }
    /// <summary>
    /// General Link exception class
    /// </summary>
    public class SeLinkException : SeBaseException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkException()
            : base("Invalid link.")
        {
        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeLinkException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkException(string message, Exception inner)
            : base(message, inner)
        {

        }

        /// <summary>
        /// Constructor with message and obj
        /// </summary>
        /// <param name="msg">Message text</param>
        /// <param name="obj">Broken object</param>
        protected SeLinkException(String msg, Object obj)
            : base(msg, obj)
        {
        }

    }
    //***************************************************************
    #region *** Code Exceptions ***

   

    /// <summary>
    /// Invalid use template as object exception class
    /// </summary>
    public class SeInvalidUseClassException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidUseClassException()
            : base("Invalid use Class as Object.")
        {
        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidUseClassException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidUseClassException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken obj</param>
        public SeInvalidUseClassException(Object obj)
            : base("Invalid use Class as Object.", obj)
        {
        }

    }
    /// <summary>
    ///  Invalid use System object exception class
    /// </summary>
    public class SeInvalidUseSystemObjectException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidUseSystemObjectException():base("This operation allowed for User objects only. Current object is not User object.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidUseSystemObjectException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidUseSystemObjectException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeInvalidUseSystemObjectException(Object obj)
            : base("This operation allowed for User objects only. Current object is not User object.", obj)
        {
        }
    }
    /// <summary>
    ///  Invalid use User object exception class
    /// </summary>
    public class SeInvalidUseUserObjectException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidUseUserObjectException()
            : base("Object is not system object.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidUseUserObjectException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidUseUserObjectException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeInvalidUseUserObjectException(Object obj)
            : base("Object is not system object.", obj)
        {
        }
    }

    /// <summary>
    ///  Error creating database object exception class
    /// </summary>
    public class SeErrorCreateObjectException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeErrorCreateObjectException()
            : base("Can't create object (technical).")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeErrorCreateObjectException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeErrorCreateObjectException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeErrorCreateObjectException(Object obj)
            : base("Can't create object (technical).", obj)
        {
        }
    }
    /// <summary>
    /// Invalid argument exception class
    /// </summary>
    public class SeArgumentException : SeCodeException
    {
        /// <summary>
        /// Invalid link axis code specified
        /// </summary>
        public static string axisErrMsg = "Invalid axis code";
        /// <summary>
        /// Source object same as target object
        /// </summary>
        public static string srcSameTrgMsg = "Source object same as target object";
        
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeArgumentException():base("Invalid argument of function in metodology context.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeArgumentException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeArgumentException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with msg and broken object
        /// </summary>
        /// <param name="msg">Message text</param>
        /// <param name="obj">Broken object</param>
        public SeArgumentException(string msg, Object obj)
            : base(msg, obj)
        {
        }
    }

    /// <summary>
    ///  Operation aborted by User exception class
    /// </summary>
    public class SeAbortedByUserException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeAbortedByUserException()
            : base("Operation aborted by User.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeAbortedByUserException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeAbortedByUserException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeAbortedByUserException(Object obj)
            : base("Operation aborted by User.", obj)
        {
        }
    }


    #region MethodExceptions

    /// <summary>
    /// General method exception class
    /// </summary>
    public class SeMethodException : SeCodeException
    {
        /// <summary>
        /// Return type not match method implementation
        /// </summary>
        public static string retTypeNotMatchMsg = "Return type not match method implementation";
        
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodException()
            : base("Error in database operation.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeMethodException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeMethodException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with message and obj
        /// </summary>
        /// <param name="msg">Message text</param>
        /// <param name="obj">Broken object</param>
        protected SeMethodException(String msg, Object obj)
            : base(msg, obj)
        {
        }

    }

    /// <summary>
    /// Method not found exception
    /// </summary>
    public class SeMethodNotFoundException : SeMethodException
    {
        const string msg = "Specified method not found";
        /// <summary>
        /// Constructor with method number
        /// </summary>
        /// <param name="methodNum">Method number</param>
        public SeMethodNotFoundException(uint methodNum)
            : base(msg, methodNum)
        {

        }
        /// <summary>
        /// Constructor with method name
        /// </summary>
        /// <param name="methodName">Method name</param>
        public SeMethodNotFoundException(string methodName)
            : base(msg, methodName)
        {
        }
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodNotFoundException()
            : base(msg)
        {

        }
    }
    /// <summary>
    /// Method not linked to class exception
    /// </summary>
    public class SeMethodNotLinkedException : SeMethodException
    {
        const string msg = "Specified method not linked to class";
        /// <summary>
        /// Constructor with broken method ktaid
        /// </summary>
        /// <param name="kta">Broken method ID</param>
        public SeMethodNotLinkedException(Methods.MKtaID kta)
            : base(msg, kta)
        {

        }
        /// <summary>
        /// Constructor with broken method number
        /// </summary>
        /// <param name="methodId">Broken method ID</param>
        public SeMethodNotLinkedException(uint methodId)
            : base(msg, methodId)
        {

        }
        /// <summary>
        /// Constructor with broken link
        /// </summary>
        /// <param name="cmLink">Broken link</param>
        public SeMethodNotLinkedException(Methods.McmLink cmLink)
            : base(msg, cmLink)
        {

        }
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodNotLinkedException()
            : base(msg)
        {

        }
    }
    /// <summary>
    /// Cannot find appropriate kta exception
    /// </summary>
    public class SeMethodKtaNotFoundException : SeMethodException
    {
        const string msg = "Cannot find appropriate KTA for specified method";
        /// <summary>
        /// Constructor with broken method number
        /// </summary>
        /// <param name="methodId">Broken method num</param>
        public SeMethodKtaNotFoundException(uint methodId)
            : base(msg, methodId)
        {
        }
        /// <summary>
        /// Constructor with broken method name
        /// </summary>
        /// <param name="methodName">Broken method name</param>
        public SeMethodKtaNotFoundException(string methodName)
            : base(msg, methodName)
        {
        }
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodKtaNotFoundException()
            : base(msg)
        {
        }
    }
    /// <summary>
    /// Method argument invalid CLR type
    /// </summary>
    public class SeMethodArgTypeInvalidException : SeMethodException
    {
        const string msg = "One of method arguments has invalid CLR type";
        /// <summary>
        /// Constructor with broken method ktaid
        /// </summary>
        /// <param name="kta">Method kta for broken argument</param>
        public SeMethodArgTypeInvalidException(Methods.MKtaID kta)
            : base(msg, kta)
        {
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodArgTypeInvalidException()
            : base(msg)
        {
        }
    }
    /// <summary>
    /// Method argument invalid value
    /// </summary>
    public class SeMethodArgValueInvalidException : SeMethodException
    {
        const string msg = "One of method arguments has incorrect value";
        /// <summary>
        /// Constructor with broken method ktaid
        /// </summary>
        /// <param name="kta">Method kta for broken argument</param>
        public SeMethodArgValueInvalidException(Methods.MKtaID kta)
            : base(msg, kta)
        {
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodArgValueInvalidException()
            : base(msg)
        {
        }
    }
    /// <summary>
    /// Method argument invalid order or quantity
    /// </summary>
    public class SeMethodArgOrderInvalidException : SeMethodException
    {
        const string msg = "Method arguments has invalid order or quantity";
        /// <summary>
        /// Constructor with broken method kta
        /// </summary>
        /// <param name="kta">Method kta for broken argument</param>
        public SeMethodArgOrderInvalidException(Methods.MKtaID kta)
            : base(msg, kta)
        {
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodArgOrderInvalidException()
            : base(msg)
        {
        }
    }
    /// <summary>
    /// Method argument invalid semantic type
    /// </summary>
    public class SeMethodArgSemTypeInvalidException : SeMethodException
    {
        const string msg = "One of method arguments has invalid semantic type";
        /// <summary>
        /// Constructor with broken method ktaid
        /// </summary>
        /// <param name="kta">Method kta for broken argument</param>
        public SeMethodArgSemTypeInvalidException(Methods.MKtaID kta)
            : base(msg, kta)
        {
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodArgSemTypeInvalidException()
            : base(msg)
        {
        }
    }

    #region SeMethodImplementationException
    /// <summary>
    /// Method implementation general exception
    /// </summary>
    public class SeMethodImplementationException : SeMethodException
    {
        const string msg = "Method implementation error";
        /// <summary>
        /// Constructor with broken method ktaid
        /// </summary>
        /// <param name="meth">Method kta</param>
        public SeMethodImplementationException(Methods.MKtaID meth)
            : base(msg, meth)
        {
        }
        /// <summary>
        /// Constructor with msg
        /// </summary>
        public SeMethodImplementationException(string message)
            : base(message)
        {
        }
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodImplementationException()
            : base(msg)
        {
        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeMethodImplementationException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with message and obj
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="obj">Broken object</param>
        public SeMethodImplementationException(String message, Object obj)
            : base(message, obj)
        {
        }

    }

    /// <summary>
    /// Method implementation argument exception
    /// </summary>
    /// <remarks>Throw for any errors with arguments and return values in implementation call stage.</remarks>
    public class SeMethodImplementationArgumentException : SeMethodImplementationException
    {
        static string msg = "Method implementation argument invalid.";

        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodImplementationArgumentException()
            : base(msg)
        {
        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeMethodImplementationArgumentException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with message and obj
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="obj">Broken object</param>
        public SeMethodImplementationArgumentException(String message, Object obj)
            : base(message, obj)
        {
        }

    }

    /// <summary>
    /// Method implementation assembly, class or function not found exception
    /// </summary>
    public class SeMethodImplementationNotFoundException : SeMethodImplementationException
    {
        /// <summary>
        /// Default message string
        /// </summary>
        private static string msg = "Method implementation code not found.";
        /// <summary>
        /// Method implementation assembly not found
        /// </summary>
        public static string assemblyNFmsg = "Method implementation assembly not found";
        /// <summary>
        /// Method implementation class not found
        /// </summary>
        public static string classNFmsg = "Method implementation class not found";
        /// <summary>
        /// Method implementation function not found
        /// </summary>
        public static string functionNFmsg = "Method implementation function not found";

        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMethodImplementationNotFoundException()
            : base(msg)
        {
        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeMethodImplementationNotFoundException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with message and obj
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="obj">Broken object</param>
        public SeMethodImplementationNotFoundException(String message, Object obj)
            : base(message, obj)
        {
        }

    }

    #endregion

    #endregion

    #endregion

    #region *** Data Exceptions ***

    /// <summary>
    ///  Object not found exception class
    /// </summary>
    public class SeObjectNotFoundException : SeDataException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeObjectNotFoundException()
            : base("Object or class not found in database.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeObjectNotFoundException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeObjectNotFoundException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeObjectNotFoundException(Object obj)
            : base("Object or class not found in database.", obj)
        {
        }
    }
    /// <summary>
    /// Base need rollback operation exception class
    /// </summary>
    public class SeRollbackBaseException : SeDataException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeRollbackBaseException()
            : base("Error in operation. Rollback required.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeRollbackBaseException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeRollbackBaseException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeRollbackBaseException(Object obj)
            : base("Error in operation. Rollback required.", obj)
        {
        }
    }
    /// <summary>
    /// Invalid database state exception class
    /// </summary>
    public class SeInvalidBaseException : SeDataException
    {
        /// <summary>
        /// Invalid base structure. Only one halflink exists
        /// </summary>
        public static string noHalfLinkMsg = "Invalid base structure. Only one halflink exists."; 
        
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidBaseException():base("Unrecoverable error occured.  Last snapshot of database must be loaded.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidBaseException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidBaseException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeInvalidBaseException(Object obj)
            : base("Unrecoverable error occured.  Last snapshot of database must be loaded.", obj)
        {
        }
        /// <summary>
        /// Constructor with msg and object
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="obj">Broken object</param>
        public SeInvalidBaseException(string message, Object obj)
            : base(message, obj)
        {
        }
    }
    /// <summary>
    /// Mismatched data types exception class
    /// </summary>
    public class SeDataTypeMismatchException : SeDataException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeDataTypeMismatchException()
            : base("Source and destination datatype mismatch.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        public SeDataTypeMismatchException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeDataTypeMismatchException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">Broken object</param>
        public SeDataTypeMismatchException(Object obj)
            : base("Source and destination datatype mismatch.", obj)
        {
        }
    }

    #endregion

    #region *** Link Exceptions ***
    /// <summary>
    ///  Source object already has link to other object  - exception class
    /// </summary>
    public class SeSourceAlreadyUsedException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeSourceAlreadyUsedException():base("Cannot create link between objects because source object already has any links to objects of target class. Object can't have more than one link to objects of target class.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeSourceAlreadyUsedException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeSourceAlreadyUsedException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with link
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeSourceAlreadyUsedException(Object link)
            : base("Cannot create link between objects because source object already has any links to objects of target class. Object can't have more than one link to objects of target class.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and link
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeSourceAlreadyUsedException(string message, Object brokenLink)
            : base(message, brokenLink)
        {

        }

    }
    /// <summary>
    ///  Destination object already has link to other object  - exception class
    /// </summary>
    public class SeDestAlreadyUsedException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeDestAlreadyUsedException()
            : base("Can't create link between objects because target object already has link to another object of source class.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeDestAlreadyUsedException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeDestAlreadyUsedException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with link
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeDestAlreadyUsedException(Object link)
            : base("Can't create link between objects because target object already has link to another object of source class.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and link
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeDestAlreadyUsedException(string message, MLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Link between two objects/classes already exists - exception class
    /// </summary>
    public class SeLinkAlreadyExistsException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkAlreadyExistsException()
            : base("Link already exists and cannot be created.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeLinkAlreadyExistsException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg ad ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkAlreadyExistsException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with link
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeLinkAlreadyExistsException(Object link)
            : base("Link already exists and cannot be created.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and link
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeLinkAlreadyExistsException(string message, MLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Between two objects/classes more than one link exists - exception class
    /// </summary>
    public class SeTooManyLinksException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeTooManyLinksException():base("More than one actual link found between linked objects.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeTooManyLinksException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeTooManyLinksException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with link
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeTooManyLinksException(Object link)
            : base("More than one actual link found between linked objects.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and linky
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeTooManyLinksException(string message, MLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Link between two objects not found - exception class
    /// </summary>
    public class SeLinkNotFoundException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkNotFoundException()
            : base("Link not found.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeLinkNotFoundException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkNotFoundException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with link
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeLinkNotFoundException(Object link)
            : base("Link not found.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and link
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeLinkNotFoundException(string message, MLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Can't create link between objects. Need link between two classes first - exception class
    /// </summary>
    public class SeNeedClassesLinkException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeNeedClassesLinkException()
            : base("Can't create link between objects because classes not linked.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeNeedClassesLinkException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeNeedClassesLinkException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with link
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeNeedClassesLinkException(Object link)
            : base("Can't create link between objects because classes not linked.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and link
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeNeedClassesLinkException(string message, MLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    /// Can't create link. Restricted link only might be created - exception class
    /// </summary>
    public class SeRestrictedLinkOnlyException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeRestrictedLinkOnlyException()
            : base("Link between classes is Restricted. Link between objects can't have different state.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeRestrictedLinkOnlyException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeRestrictedLinkOnlyException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with link
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeRestrictedLinkOnlyException(Object link)
            : base("Link between classes is Restricted. Link between objects can't have different state.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and obj
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="broken">Broken object</param>
        private SeRestrictedLinkOnlyException(string message, Object broken)
            : base(message, broken)
        {

        }
    }
    /// <summary>
    /// Link states mismatch - exception class
    /// </summary>
    public class SeLinkStateMismatchException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkStateMismatchException():base("Link states mismatch.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeLinkStateMismatchException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkStateMismatchException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with obj
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeLinkStateMismatchException(Object link)
            : base("Link states mismatch.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and obj
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeLinkStateMismatchException(string message, MLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    /// Mutual link cannot be created - exception class
    /// </summary>
    public class SeMutualLinkErrorException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMutualLinkErrorException()
            : base("Mutual link cannot be created.")
        {

        }
        /// <summary>
        /// Param constructor with msg
        /// </summary>
        /// <param name="message">Message text</param>
        private SeMutualLinkErrorException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// Param constructor with msg and ex
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeMutualLinkErrorException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with obj
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeMutualLinkErrorException(Object link)
            : base("Mutual link cannot be created.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and obj
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeMutualLinkErrorException(string message, MLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }


    #endregion



}
