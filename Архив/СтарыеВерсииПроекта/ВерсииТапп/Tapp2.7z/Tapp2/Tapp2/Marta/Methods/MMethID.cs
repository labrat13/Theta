using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Marta.Methods
{
    /// <summary>
    /// Class represent Kta identificator
    /// </summary>
    public class MKtaID
    {
        #region Fields
        /// <summary>
        /// Method num
        /// </summary>
        private uint m_MethodID;
        /// <summary>
        /// Kta id
        /// </summary>
        private uint m_ktaID;
        #endregion
        /// <summary>
        /// Default constructor, XML use
        /// </summary>
        public MKtaID()
        {
            m_ktaID = 0;
            m_MethodID = 0;
        }

        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="metId">Method num</param>
        /// <param name="ktaId">KTA ID</param>
        public MKtaID(uint metId, uint ktaId)
        {
            m_ktaID = ktaId;
            m_MethodID = metId;
        }
        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="copy">Copy object</param>
        public MKtaID(MKtaID copy)
        {
            this.m_ktaID = copy.m_ktaID;
            m_MethodID = copy.m_MethodID;
        }

        #region Properties
        /// <summary>
        /// Method ID
        /// </summary>
        [XmlIgnore]
        public uint MethodID
        {
            get
            {
                return m_MethodID;
            }
            set
            {
                m_MethodID = value;
            }
        }

        /// <summary>
        /// KTA ID
        /// </summary>
        [XmlIgnore]
        public uint KtaID
        {
            get
            {
                return m_ktaID;
            }
            set
            {
                m_ktaID = value;
            }
        }

        /// <summary>
        /// Get or set String representation of ID's
        /// </summary>
        public string IDstr
        {
            get
            {
                return this.ToString();
            }
            set
            {
                string[] sar = value.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                m_MethodID = UInt32.Parse(sar[0]);
                m_ktaID = UInt32.Parse(sar[1]);
            }
        }
        #endregion

        /// <summary>
        /// Get copy of current KTA ID
        /// </summary>
        public Methods.MKtaID getCopy()
        {
            return new MKtaID(this.m_MethodID, m_ktaID);
        }

        /// <summary>
        /// Return true if two KTA ID equal
        /// </summary>
        public bool isEqual(MKtaID ktaid)
        {
            return ((m_MethodID == ktaid.m_MethodID) && (m_ktaID == ktaid.m_ktaID));
        }

        /// <summary>
        /// Return string representation of KTA ID
        /// </summary>
        override public string ToString()
        {
            return String.Format("{0}:{1}", m_MethodID, m_ktaID);
        }
    }
}
