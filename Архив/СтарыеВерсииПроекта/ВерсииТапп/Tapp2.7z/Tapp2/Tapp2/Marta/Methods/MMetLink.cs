using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Marta.Methods
{
    /// <summary>
    /// Class represent link between methods
    /// </summary>
    public class MMetLink
    {
        #region Fields
        /// <summary>
        /// Source method
        /// </summary>
        private MKtaID m_srcId;
        /// <summary>
        /// Dest method
        /// </summary>
        private MKtaID m_dstId;
        #endregion
        /// <summary>
        /// NT-default constructor for XML
        /// </summary>
        public MMetLink()
        {
            m_dstId = new MKtaID();
            m_srcId = new MKtaID();
        }

        /// <summary>
        /// NT-params constructor
        /// </summary>
        /// <param name="src">Source method ID</param>
        /// <param name="dst">Dest method ID</param>
        public MMetLink(MKtaID src, MKtaID dst)
        {
            m_srcId = new MKtaID(src);
            m_dstId = new MKtaID(dst);
        }

        /// <summary>
        /// NT-Copy constructor
        /// </summary>
        /// <param name="copy">Link for copy</param>
        public MMetLink(MMetLink copy)
        {
            m_srcId = new MKtaID(copy.m_srcId);
            m_dstId = new MKtaID(copy.m_dstId);
        }
        #region Properties
        /// <summary>
        /// Source method ID
        /// </summary>
        [XmlIgnore]
        public MKtaID sourceID
        {
            get
            {
                return m_srcId;
            }
            set
            {
                m_srcId = value;
            }
        }

        /// <summary>
        /// Dest method ID
        /// </summary>
        [XmlIgnore]
        public MKtaID destID
        {
            get
            {
                return m_dstId;
            }
            set
            {
                m_dstId = value;
            }
        }

        /// <summary>
        /// Link as text string for XML serializing and best readability
        /// </summary>
        public String LinkStr
        {
            get { return this.ToString(); }
            set { parseStrValue(value); }
        }

        #endregion


        /// <summary>
        /// NT-return string representation of link
        /// </summary>
        override public string ToString()
        {
            return String.Format("{0} {1}", m_srcId.ToString(), m_dstId.ToString());
        }

        /// <summary>
        /// Parse string representation of link
        /// </summary>
        /// <param name="str">String representation of link</param>
        private void parseStrValue(String str)
        {
            //parse string    256:0 258:0
            String[] strs = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            this.m_srcId.IDstr = strs[0];
            this.m_dstId.IDstr = strs[1];
        }
        /// <summary>
        /// NT-Get copy of current link
        /// </summary>
        /// <returns></returns>
        internal MMetLink getCopy()
        {
            return new MMetLink(this.m_srcId, this.m_dstId);
        }
    }
}
