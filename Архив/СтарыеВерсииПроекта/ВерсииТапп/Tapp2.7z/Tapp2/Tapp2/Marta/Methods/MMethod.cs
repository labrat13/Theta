using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Marta.Methods
{
    /// <summary>
    /// Class represent database action in form script or Csharp code.
    /// </summary>
    public class MMethod
    {

        #region Fields
        /// <summary>
        /// Primary kta for method
        /// </summary>
        private MKTA m_kta0;
        /// <summary>
        /// List of linked classes
        /// </summary>
        private List<McmLink> m_classLinkList;
        /// <summary>
        /// List of kta
        /// </summary>
        private List<MKTA> m_KtaList;
        /// <summary>
        /// Method name
        /// </summary>
        private string m_name;
        /// <summary>
        /// Method description
        /// </summary>
        private string m_description;
        /// <summary>
        /// Path to method body
        /// </summary>
        private string m_codePath;
        /// <summary>
        /// Method id
        /// </summary>
        private uint m_id;
        /// <summary>
        /// Script text if method is script. Empty otherwise. 
        /// </summary>
        /// <remarks>
        /// If codePath and Script fields both empty, this method is abstract.
        /// </remarks>
        private string m_Script;
        /// <summary>
        /// Link list Xup
        /// </summary>
        private List<MMetLink> m_XupList;
        /// <summary>
        /// Link list Xdown
        /// </summary>
        private List<MMetLink> m_XdnList;
        /// <summary>
        /// Link list Yup
        /// </summary>
        private List<MMetLink> m_YupList;
        /// <summary>
        /// Link list Ydown
        /// </summary>
        private List<MMetLink> m_YdnList;
        /// <summary>
        /// Link list Zup
        /// </summary>
        private List<MMetLink> m_ZupList;
        /// <summary>
        /// Link list Zdown
        /// </summary>
        private List<MMetLink> m_ZdnList;
        /// <summary>
        /// Flag for graph searching
        /// </summary>
        private int m_Search;
#endregion

        /// <summary>
        /// Default constructor, used by XML
        /// </summary>
        public MMethod()
        {
            m_classLinkList = new List<McmLink>();
            m_codePath = String.Empty;
            m_Script = String.Empty;
            m_description = String.Empty;
            m_id = 0;
            m_kta0 = new MKTA();
            m_KtaList = new List<MKTA>();
            m_name = String.Empty;
            m_XdnList = new List<MMetLink>();
            m_XupList = new List<MMetLink>();
            m_YdnList = new List<MMetLink>();
            m_YupList = new List<MMetLink>();
            m_ZdnList = new List<MMetLink>();
            m_ZupList = new List<MMetLink>();
            m_Search = 0;
        }

        /// <summary>
        /// Parameters constructor
        /// </summary>
        /// <param name="metId">Method id</param>
        /// <param name="name">Method name</param>
        /// <param name="descr">Method description</param>
        public MMethod(uint metId, String name, String descr )
        {
            m_classLinkList = new List<McmLink>();
            m_codePath = String.Empty;
            m_Script = String.Empty;
            m_description = descr;
            m_id = metId;
            m_kta0 = new MKTA(metId, 0);
            m_KtaList = new List<MKTA>();
            m_name = name;
            m_XdnList = new List<MMetLink>();
            m_XupList = new List<MMetLink>();
            m_YdnList = new List<MMetLink>();
            m_YupList = new List<MMetLink>();
            m_ZdnList = new List<MMetLink>();
            m_ZupList = new List<MMetLink>();
            m_Search = 0;
        }

        /// <summary>
        /// Parameters constructor with kta0
        /// </summary>
        /// <param name="metId">Method id</param>
        /// <param name="name">Method name</param>
        /// <param name="descr">Method description</param>
        /// <param name="Kta0">Kta filled with arguments for method</param>
        public MMethod(uint metId, String name, String descr, MKTA Kta0)
        {
            m_classLinkList = new List<McmLink>();
            m_codePath = String.Empty;
            m_Script = String.Empty;
            m_description = descr;
            m_id = metId;
            m_kta0 = Kta0;
            m_kta0.ClassID = MID.UnusedId;  //for kta0 no classes can be specified
            m_kta0.KtaID.MethodID = metId;  //method id
            m_kta0.KtaID.KtaID = 0;         //kta0 id
            m_kta0.Multi = 0;               //kta multiplicity, for kta0 ignored
            m_kta0.Quality = 0;             //kta quality initial value
            m_KtaList = new List<MKTA>();
            m_name = name;
            m_XdnList = new List<MMetLink>();
            m_XupList = new List<MMetLink>();
            m_YdnList = new List<MMetLink>();
            m_YupList = new List<MMetLink>();
            m_ZdnList = new List<MMetLink>();
            m_ZupList = new List<MMetLink>();
            m_Search = 0;
        }

        #region Properties

        /// <summary>
        /// Method ID
        /// </summary>
        public uint ID
        {
            get
            {
                return m_id;
            }
            set
            {
                m_id = value;
            }
        }
        /// <summary>
        /// Method name text
        /// </summary>
        /// <remarks>Do not use XML brackets.</remarks>
        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }
        /// <summary>
        /// Method description text
        /// </summary>
        /// <remarks>Do not use XML brackets.</remarks>
        public string Description
        {
            get
            {
                return m_description;
            }
            set
            {
                m_description = value;
            }
        }
        /// <summary>
        /// Primary KTA for method
        /// </summary>
        /// <remarks> This kta must have ID (method_num:0)</remarks>
        public MKTA KTA_0
        {
            get
            {
                return m_kta0;
            }
            set
            {
                m_kta0 = value;
            }
        }
        /// <summary>
        /// Path for method code
        /// </summary>
        /// <remarks>For example: assembly.class.static_function.</remarks>
        public string CodePath
        {
            get
            {
                return m_codePath;
            }
            set
            {
                m_codePath = value;
            }
        }
        /// <summary>
        /// Script text if method is script. Empty otherwise.
        /// </summary>
        public string Script
        {
            get {return m_Script; }
            set {m_Script = value;}
        }
        /// <summary>
        /// List of kta
        /// </summary>
        public List<MKTA> KtaList
        {
            get
            {
                return m_KtaList;
            }
        }
        /// <summary>
        /// List of links to classes
        /// </summary>
        public List<McmLink> classList
        {
            get
            {
                return m_classLinkList;
            }
        }
        /// <summary>
        /// List of links to methods
        /// </summary>
        public List<MMetLink> XupList
        {
            get
            {
                return m_XupList;
            }
        }
        /// <summary>
        /// List of links to methods
        /// </summary>
        public List<MMetLink> XdnList
        {
            get
            {
                return m_XdnList;
            }
        }
        /// <summary>
        /// List of links to methods
        /// </summary>
        public List<MMetLink> YupList
        {
            get
            {
                return m_YupList;
            }
        }
        /// <summary>
        /// List of links to methods
        /// </summary>
        public List<MMetLink> YdnList
        {
            get
            {
                return m_YdnList;
            }
        }
        /// <summary>
        /// List of links to methods
        /// </summary>
        public List<MMetLink> ZupList
        {
            get
            {
                return m_ZupList;
            }
        }
        /// <summary>
        /// List of links to methods
        /// </summary>
        public List<MMetLink> ZdnList
        {
            get
            {
                return m_ZdnList;
            }
        }

        /// <summary>
        /// Flag for graph search. Not saved in XML.
        /// </summary>
        [XmlIgnore] 
        public int SearchFlag
        {
            get { return m_Search; }
            set { m_Search = value; }
        }
        #endregion

        #region Simple Run functions
        /// <summary>
        /// NT-Simple execute method, without any checking, searching, etc.
        /// </summary>
        /// <param name="cont">Container object or null</param>
        /// <param name="caller">Caller object or null</param>
        /// <param name="args">Argument array or null</param>
        /// <returns>Returns value from method</returns>
        /// <remarks>User must think before call</remarks>
        /// <exception cref="SeMethodArgOrderInvalidException">Method arguments has missing types or order.</exception>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        public Object ExecuteSimple(MEngine cont, MCell caller, Object[] args)
        {
            MKTA kta = simpleFillKta(caller, args);
            if(!simpleCheck(kta)) throw new SeMethodArgOrderInvalidException(this.KTA_0.KtaID);
            Object res = this.Run(cont, caller, kta);
            return res;
        }
        /// <summary>
        /// NT-Simple kta checking
        /// </summary>
        /// <param name="args">Kta for checking</param>
        /// <remarks>
        /// This function performs check by Kta0 arg count,  arg types.
        /// If kta0 arg type is Object, arg type checking ignored 
        ///</remarks>
        ///<returns>Return true if succesfull, false otherwise</returns>
        private bool simpleCheck(MKTA args)
        {
            //check kta0 for arg count
            if (this.m_kta0.argList.Count != args.argList.Count) return false; //return empty
            //check C# types - for quick return. Semantic types check later
            //result type not check in simple
            Type t; 
            //object can be any type, all other must be matched
            //if ((t != typeof(Object)) && (t != args.Result.argType)) return false; //return empty
            for (int ii = 0; ii < args.argList.Count; ii++)
            {
                t = m_kta0.argList[ii].argType;
                if ((t != typeof(Object)) && (t != args.Result.argType)) return false; //return empty
            }
            return true;
        }

        /// <summary>
        /// NT-Simple fill kta without specifying result type and caller if caller is null
        /// </summary>
        /// <param name="caller">Caller object or null</param>
        /// <param name="args">Args array or null</param>
        /// <returns>Filled kta</returns>
        /// <remarks>Result type and semantic type take from kta0. User must think before call.</remarks>
        private MKTA simpleFillKta(MCell caller, Object[] args)
        {
            MKTA kta = new MKTA();
            if (caller != null)
            {
                kta.ClassID.ClassID = caller.ID.ClassID; //class id of caller
                kta.ClassID.ObjID = caller.ID.ObjID;
            }
            else kta.ClassID = MID.UnusedId;

            //add arguments only. Container and caller must be added automatically before code invoke
            //if args.count = 0 then no other arguments
            //if method return nothing, res can be any type.
            //(����� ���������� ����� ����, �� ��� ���������� � ������������ ��� ����� � ����?)

            //result already created, fill it
            kta.Result.argType = this.KTA_0.Result.argType; //simple copy result type, user must think before call
            kta.Result.ClassId = this.KTA_0.Result.ClassId;
            kta.Result.Description = "";
            kta.Result.Value = null;
            kta.Result.Name = "Result";
            //fill all other args if not null
            if (args != null)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    kta.argList.Add(new MArg("Arg", "", args[i]));
                }
            }
            return kta;
        }

        #endregion

        #region Run functions


        /// <summary>
        /// NT-Execute method code 
        /// </summary>
        /// <returns>Return Object value returned by method code</returns>
        /// <param name="cntr">Container object or null</param>
        /// <param name="caller">Caller object or null</param>
        /// <param name="kta">Kta with arguments</param>
        /// <remarks>If container or caller references is null, do not use it in method code.</remarks>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        internal object Run(MEngine cntr, MCell caller, MKTA kta)
        {
            //1-��������� ��� � ������������ ������-������� ����� ����� ������.
            kta.KtaID.MethodID = this.ID;
            //2-������ ���������� � ������� MMethod.Invoke(...). ��������� ����������.
            //���� ��� ����������. ������ �����.
            Object res = Invoke(cntr, caller, kta);
            //3-������� �������� ������ ������ � �������� ��� � ����.
            //���� ���������
            //4-�������� ���� � ������ ��� ������
            this.AddNewKta(kta);
            //5-��������������� ������ ��� ������, ���� �� ���������� �������.
            this.ResortKta();
            return res;
        }

        /// <summary>
        /// NT-Invoke method body. 
        /// </summary>
        /// <returns>Return Object value returned by invoked function</returns>
        /// <param name="cntr">Container object or null</param>
        /// <param name="caller">Caller object or null</param>
        /// <param name="kta">Kta with arguments</param>
        /// <exception cref="SeMethodException">Result type mismatch for method declaration and method implementation</exception>
        /// <exception cref="SeMethodImplementationArgumentException">Argument count or types mismatched in implementation</exception>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        private object Invoke(MEngine cntr, MCell caller, MKTA kta)
        {
            MethodInfo m = this.getMethodInfo(); //load assembly and get MethodInfo object.
            //260910 - check method attributes and show warning 
            checkMethodAttributes(m);
            //check return type
            if ((kta.Result.argType != m.ReturnType)) throw new SeMethodException(SeMethodException.retTypeNotMatchMsg);// "Result type mismatch for method declaration and method implementation");
            //get argument list. function arg list contains 2 default arguments, call arg list - not.
            ParameterInfo[] pia = m.GetParameters();
            //check args count
            bool argFlag = false;
            if (pia.Length == 3)
                if (pia[2].ParameterType == typeof(MKTA)) argFlag = true;//MKTA detected.
            if(!argFlag && !((pia.Length >= 2) && (kta.argList.Count == (pia.Length - 2))))// and 
                    throw new SeMethodImplementationArgumentException("Argument numbers mismatched in implementation", this); // 
            
            //check arg list
            if ((pia[0].ParameterType != typeof(MEngine)) || (pia[1].ParameterType != typeof(MCell)))
                throw new SeMethodImplementationArgumentException("Argument type invalid in implementation", this); //
            
            //make arguments array
            List<Object> li = new List<object>(pia.Length);
            li.Add(cntr);//container object
            li.Add(caller);  //caller object            
            //check 3 arg is kta, then no more args after
            //add user arguments if not use MKTA
            if (pia.Length > 2) //if more than 2 args in code
            {
                 if (pia[2].ParameterType != typeof(MKTA))
                {
                    for (int i = 0; i < kta.argList.Count; i++)
                    {
                        if ((pia[i + 2].ParameterType != typeof(Object)) && (pia[i + 2].ParameterType != kta.argList[i].argType))
                            throw new SeMethodImplementationArgumentException("Argument type invalid in implementation", this); //
                        else li.Add(kta.argList[i].Value);
                    }
                }
                else li.Add(kta); //add kta to arglist
            }

            //invoke method
            Object resval = m.Invoke(null, li.ToArray());
            //return result value
            return resval;
        }

        #endregion


        #region *** KTAList ***
        /// <summary>
        /// NT-Add new kta to list of kta with new ktaId 
        /// </summary>
        internal void AddNewKta(MKTA kta)
        {
            //multiple kta in list allowed, simple insert this kta to list
            //��������� ������ ���������� ���� �� ���, ������ �������� ������������ ��� ������������� ���������� �� ������.
            //����������� ������ ������ ���� ��������� ������ ��������. 
            kta.KtaID.KtaID = getFreeKtaId();//method num not changed
            m_KtaList.Add(kta);
        }

        /// <summary>
        /// NT-Get kta by kta id
        /// </summary>
        /// <param name="ktaid">Kta number</param>
        /// <returns>Kta or null if kta not found</returns>
        internal MKTA intGetKta(MKtaID ktaid)
        {
            MKTA res = null;
            foreach (MKTA kt in this.KtaList)
            {
                if (kt.KtaID.isEqual(ktaid))
                {
                    res = kt;
                    break;
                }
            }
            return res;
        }

        /// <summary>
        /// NT-Get free Id for new kta
        /// </summary>
        /// <returns>Max of existing kta id + 1</returns>
        private uint getFreeKtaId()
        {
            uint id = 0;
            foreach (MKTA t in m_KtaList)
                if (t.KtaID.KtaID > id) id = t.KtaID.KtaID;
            return id + 1;
        }

        /// <summary>
        /// NR-Optimize list of KTA. Now skipped.
        /// </summary>
        internal void ResortKta()
        {
            //now skipped 
        }

        /// <summary>
        /// NR-get list of appropriates kta for this set of arguments
        /// </summary>
        /// <param name="args">New kta as set of arguments</param>
        /// <remarks>
        /// Now this function return filtered method.ktaList by args count and C#-types.
        /// It is wrong! This function must select appropriates kta for current args and caller class.
        /// But it after full test.
        /// Semantic type check ClassId but not check ObjectID. Semantic types for kta0(that is, for method overall) not checked!
        ///</remarks>
        ///<exception cref="SeMethodArgOrderInvalidException">Method arguments has invalid order or type</exception>
        internal List<Methods.MKTA> findUsefulKtas(MKTA args)
        {
            List<MKTA> lim = new List<MKTA>();
            //check kta0 for arg count
            if (m_kta0.argList.Count != args.argList.Count) return lim; //return empty
            //check C# types - for quick return. Semantic types check later
            Type t = m_kta0.Result.argType;
            //object can be any type, all other must be matched
            if ((t != typeof(Object)) && (t != args.Result.argType)) return lim; //return empty
            for (int ii = 0; ii < args.argList.Count; ii++)
            {
                t = m_kta0.argList[ii].argType;
                if ((t != typeof(Object)) && (t != args.Result.argType)) return lim; //return empty
            }

            //check all kta in list
            foreach (MKTA kt in this.m_KtaList)
            {
                //check args count - slower
                if (kt.argList.Count != args.argList.Count) throw new SeMethodArgOrderInvalidException(kt.KtaID);
                bool flag = true; //check semantic args flag
                //check return type
                t = kt.Result.argType;
                if ((t != typeof(Object)) && (t != args.Result.argType)) continue; //return empty
                if ((t == typeof(MClass)) || (t == typeof(MObj)))//TODO: can replace to Type.BaseType call
                    if (kt.Result.ClassId.ClassID != args.Result.ClassId.ClassID) flag = false; 
                //check args type if result type match
                if (flag == true)
                {
                    for (int q = 0; q < args.argList.Count; q++)
                    {
                        t = kt.argList[q].argType;
                        if ((t != typeof(Object)) && (t != args.argList[q].argType)) throw new SeMethodArgOrderInvalidException(kt.KtaID); //invalid format: args in current kta mismatch to args in kta0
                        //check semantic types - for full equal
                        if ((t == typeof(MClass)) || (t == typeof(MObj)))//TODO: can replace to Type.BaseType call
                            if (kt.argList[q].ClassId.ClassID != args.argList[q].ClassId.ClassID) flag = false;
                    }
                }
                //if check is success add kta to list
                if(flag == true) lim.Add(kt);

            }
            //if nothing found, check semantic types for kta0 and add kta0 t list and return
            if (lim.Count == 0)
            {
                //check semantic types in abstract hierarchy...
                // now skipped. TODO: make this checking. 
                lim.Add(m_kta0);
            }
            return lim;
        }


        #endregion

        #region *** Method-Method Link ***
        /// <summary>
        /// Get list of links for specified axis code
        /// </summary>
        /// <param name="a">Axis code</param>
        /// <returns>List of links</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        internal List<MMetLink> getAxisList(Axiss a)
        {
            List<MMetLink> res = null;
            switch (a)
            {
                case Axiss.Xdown:
                    res = m_XdnList;
                    break;
                case Axiss.Xup:
                    res = m_XupList;
                    break;
                case Axiss.Ydown:
                    res = m_YdnList;
                    break;
                case Axiss.Yup:
                    res = m_YupList;
                    break;
                case Axiss.Zdown:
                    res = m_ZdnList;
                    break;
                case Axiss.Zup:
                    res = m_ZupList;
                    break;
                default:
                    throw new SeArgumentException(SeArgumentException.axisErrMsg, (int)a);

            }
            return res;
        }
        /// <summary>
        /// Get list of links for inversed axis code (Up inversed to Down)
        /// </summary>
        /// <param name="a">Axis code</param>
        /// <returns>List of links</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        internal List<MMetLink> getInverseAxisList(Axiss a)
        {
            List<MMetLink> res = null;
            switch (a)
            {
                case Axiss.Xup:
                    res = m_XdnList;
                    break;
                case Axiss.Xdown:
                    res = m_XupList;
                    break;
                case Axiss.Yup:
                    res = m_YdnList;
                    break;
                case Axiss.Ydown:
                    res = m_YupList;
                    break;
                case Axiss.Zup:
                    res = m_ZdnList;
                    break;
                case Axiss.Zdown:
                    res = m_ZupList;
                    break;
                default:
                    throw new SeArgumentException(SeArgumentException.axisErrMsg, (int)a);
                //break;
            }
            return res;
        }
        /// <summary>
        /// Get inverted axis code (For example, up inversed to down) 
        /// </summary>
        /// <param name="a">Axis code</param>
        /// <returns>List of links</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        internal static Axiss inverseAxis(Axiss a)
        {
            switch (a)
            {
                case Axiss.Xdown:
                    return Axiss.Xup;
                //break;
                case Axiss.Xup:
                    return Axiss.Xdown;
                //break;
                case Axiss.Ydown:
                    return Axiss.Yup;
                //break;
                case Axiss.Yup:
                    return Axiss.Ydown;
                //break;
                case Axiss.Zdown:
                    return Axiss.Zup;
                //break;
                case Axiss.Zup:
                    return Axiss.Zdown;
                //break;
                default:
                    throw new SeArgumentException(SeArgumentException.axisErrMsg, (int)a);
                //break;
            }
        }

        /// <summary>
        /// Create link between two methods
        /// </summary>
        /// <param name="a">Axis</param>
        /// <param name="targ">Target method</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeArgumentException">Target method same as current method</exception>
        /// <exception cref="SeLinkAlreadyExistsException">Link between Methods already exists</exception>
        /// <exception cref="SeMutualLinkErrorException">Opposite link between methods exists</exception>
        public void createLink(Axiss a, MMethod targ)
        {
            //check the target same as current method
            if (this.ID == targ.ID) throw new SeArgumentException(SeArgumentException.srcSameTrgMsg, this); // "Target method same as current method");
            //check link exists
            List<MMetLink> li = getLinkListToAnyKta(a, targ);
            if (li.Count > 0) throw new SeLinkAlreadyExistsException(new MMetLink(this.KTA_0.KtaID, targ.KTA_0.KtaID)); //"Link between Methods already exists");
            //check mutual link exists
            li = getLinkListToAnyKta(MMethod.inverseAxis(a), targ);
            if(li.Count > 0) throw new SeMutualLinkErrorException(new MMetLink(this.KTA_0.KtaID, targ.KTA_0.KtaID)); // ("Another link between methods exists");
            //create link
            L2createLink(a, targ);
        }

        /// <summary>
        /// Create link between methods without checking
        /// </summary>
        /// <param name="a">Axis</param>
        /// <param name="targ">Target method</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        private void L2createLink(Axiss a, MMethod targ)
        {
            this.L1createHLink(getAxisList(a), targ.ID);
            targ.L1createHLink(targ.getInverseAxisList(a), this.ID);
        }

        /// <summary>
        /// Create halflink and insert to list
        /// </summary>
        /// <param name="li">Axis list</param>
        /// <param name="metId">Target method Id</param>
        private void L1createHLink(List<MMetLink> li, uint metId)
        {
            //create link 
            MMetLink m = new MMetLink();
            m.destID.KtaID = 0;
            m.destID.MethodID = metId;
            m.sourceID.KtaID = 0;
            m.sourceID.MethodID = this.ID;
            //add link to list
            li.Add(m);
        }

        /// <summary>
        /// Get list of halflinks to any Kta of target method. Check link structure.
        /// </summary>
        /// <param name="a">Axis </param>
        /// <param name="targ">Target method</param>
        /// <returns>List of links to kta</returns>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeInvalidBaseException">Structure error! One of halflinks is absent.</exception>
        public List<MMetLink> getLinkListToAnyKta(Axiss a, MMethod targ)
        {
            List<MMetLink> li = targ.getHLinkListToAnyKta(targ.getInverseAxisList(a), this.ID);
            int n1 = li.Count;
            li = this.getHLinkListToAnyKta(getAxisList(a), targ.ID);
            int n2 = li.Count;
            //���� ����� ���������� �������, ������ ��������� - ���-�� ���� �� ���������� �����������
            if (n1 != n2) throw new SeInvalidBaseException(SeInvalidBaseException.noHalfLinkMsg, this);
            return li;
        }


        /// <summary>
        /// Delete link between two methods
        /// </summary>
        /// <param name="a">Axis for work</param>
        /// <param name="targ">Target method</param>
        /// <exception cref="SeArgumentException">Target method same as current method</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        public void deleteLink(Axiss a, MMethod targ)
        {
            //check the target same as current method
            if (this.ID == targ.ID) throw new SeArgumentException(SeArgumentException.srcSameTrgMsg, this); //"Target method same as current method");
            //delete link to specified kta - ��������: ����� ������� - ����� ��� �������. ��� ������������ ��� � ���� ��������?
            //���� ���� ��������� ������ � ������� ���, ��� ������� ������?
            
            //���� ��������� ������ �������� ���� ������ ����� �������� ��� ����� ���
            this.L2deleteLinkAnyKta(a, targ);
        }

        /// <summary>
        /// Delete link to any kta of target method
        /// </summary>
        /// <param name="a">Axis list</param>
        /// <param name="targ">Target method</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        internal void L2deleteLinkAnyKta(Axiss a, MMethod targ)
        {
            this.L1deleteHLinkAnyKta(getAxisList(a), targ.ID);
            targ.L1deleteHLinkAnyKta(targ.getInverseAxisList(a), this.ID);
        }

        /// <summary>
        /// Delete halflinks to any kta of target method
        /// </summary>
        /// <param name="list">Axis list</param>
        /// <param name="methodNum">Target method num</param>
        private void L1deleteHLinkAnyKta(List<MMetLink> list, uint methodNum)
        {
            //create list for deleted links
            List<MMetLink> lm = getHLinkListToAnyKta(list, methodNum);
            //remove links from list
            foreach (MMetLink m in lm)    list.Remove(m);
        }

        /// <summary>
        /// Get list of links to any kta of target method
        /// </summary>
        /// <param name="list">Axis list</param>
        /// <param name="methodNum">Target method num</param>
        /// <returns>List of links</returns>
        private List<MMetLink> getHLinkListToAnyKta(List<MMetLink> list, uint methodNum)
        {
            List<MMetLink> lm = new List<MMetLink>();
            foreach (MMetLink m in list)
                if (m.destID.MethodID == methodNum) lm.Add(m);
            return lm;
        }
        #endregion

        #region *** Class-Method link ***
        /// <summary>
        /// NT-Create class-method halflink
        /// </summary>
        /// <param name="clsId">Class id</param>
        /// <exception cref="SeLinkAlreadyExistsException">ClassMethod link already exists</exception>
        internal void L1addCmHLink(MID clsId)
        {
            //create hlink and add to list
            //throw exception if link already exists
            McmLink li = new McmLink(clsId, new MKtaID(this.ID, 0));
            L1addCmHLink(li); //call overloaded function
        }
        /// <summary>
        /// NT-Create class-method halflink
        /// </summary>
        /// <param name="link">New link, add to list without copying</param>
        /// <exception cref="SeLinkAlreadyExistsException">ClassMethod link already exists</exception>
        internal void L1addCmHLink(McmLink link)
        {
            //throw exception if link already exists
            McmLink li = L1getCmLink(link.MethodID.KtaID, link.ClassID.ClassID);
            if (li != null) throw new SeLinkAlreadyExistsException(link); // "ClassMethod link already exists!");
            //add link to list 
            else this.classList.Add(link);
            return;
        }
        /// <summary>
        /// NT-Delete class-method halflink
        /// </summary>
        ///<param name="ktaid">Kta for link</param>
        /// <param name="clsId">Class for link</param>
        ///<param name="checkExists">True - check existing and throw exception if not exists. False - skip checking</param>
        ///<exception cref="SeLinkNotFoundException">ClassMethod links not exists</exception>
        internal void L1deleteCmHLink(uint ktaid, uint clsId, bool checkExists)
        {
            McmLink lin = L1getCmLink(ktaid, clsId);
            if (checkExists && (lin == null)) throw new SeLinkNotFoundException(); //"ClassMethod links not exists");
            //delete link
            if (lin != null) this.classList.Remove(lin);
            return;
        }

        /// <summary>
        /// NT-Delete class-method halflink by class ID
        /// </summary>
        /// <param name="clsId">Class id</param>
        /// <param name="checkExists">True - check existing and throw exception if not exists. False - skip checking</param>
        /// <exception cref="SeLinkNotFoundException">ClassMethod links not exists</exception>
        internal void L1deleteCmHLinksByClassId(MID clsId, bool checkExists)
        {
            //delete all halflinks with matched class id - deletes all hlinks to any objects of class
            //get list of hlinks
            List<McmLink> lis = L1getCmLinksList(clsId.ClassID);
            //check exists
            if (checkExists && (lis.Count == 0)) throw new SeLinkNotFoundException(); //"ClassMethod links not exists");
            //delete links
            foreach (McmLink li in lis) this.classList.Remove(li);
            return;
        }        
        /// <summary>
        /// NR-Create link between class and method
        /// </summary>
        /// <param name="targCls">Target class</param>
        /// <exception cref="SeLinkAlreadyExistsException">ClassMethod link already exists</exception>
        public void addClassMethodLink(MClass targCls)
        {
            //check link exists
            if(this.L1checkCmLinkExists(targCls.ID.ClassID)) throw new SeLinkAlreadyExistsException(new McmLink(targCls.ID, this.KTA_0.KtaID)); //"ClassMethod link already exists!");
            //add halflink method-class
            this.L1addCmHLink(new McmLink(targCls.ID.getCopy(), this.KTA_0.KtaID.getCopy()));
            //add back halflink
            targCls.L1addCmHLink(new McmLink(targCls.ID.getCopy(), this.KTA_0.KtaID.getCopy()));
            return;
        }
        /// <summary>
        /// NR-Delete link between class and method
        /// </summary>
        /// <param name="targCls">Target class</param>
        ///  <exception cref="SeLinkNotFoundException">ClassMethod links not exists</exception>
        public void deleteClassMethodLink(MClass targCls)
        {
            //delete link to method with check link exists
            L1deleteCmHLinksByClassId(targCls.ID, true);
            //delete back link
            targCls.L1deleteCmHLinksByMethodId(this.ID, true);
        }
        /// <summary>
        /// NT-Get list of any links to specified class
        /// </summary>
        /// <param name="clsId">Class Id</param>
        /// <returns>List of link</returns>
        internal List<McmLink> L1getCmLinksList(uint clsId)
        {
            List<McmLink> lis = new List<McmLink>();
            //add links to specified class to list
            foreach(McmLink li in this.classList)
            {
                if(li.ClassID.ClassID == clsId)    lis.Add(li);
            }
            //return list
            return lis;
        }
        /// <summary>
        /// NT-Return true if any links to specified class exists, false otherwise.
        /// </summary>
        /// <param name="clsId">Class id</param>
        /// <returns>True or false</returns>
        internal bool L1checkCmLinkExists(uint clsId)
        {
            foreach (McmLink li in this.classList)
            {
                if (li.ClassID.ClassID == clsId) return true;
            }
            return false;
        }
        /// <summary>
        /// NT-Return first existing link between kta and specified class or null if link not exists
        /// </summary>
        /// <param name="ktaid">Number of kta of method</param>
        /// <param name="clsId">Linked class id</param>
        /// <returns>Link or null</returns>
        internal McmLink L1getCmLink(uint ktaid, uint clsId)
        {
            McmLink link = null;
            //return first matched link or null
            foreach(McmLink li in this.classList)
                if ((li.ClassID.ClassID == clsId) && (li.MethodID.KtaID == ktaid))
                {
                    link = li;
                    break;
                }
            return link;
        }

        #endregion

        #region *** Stuff ***

        /// <summary>
        /// NT-return string representation of object
        /// </summary>
        override public string ToString()
        {
            //see MethodElement old code for example
            return String.Format("{0}_{1}", m_name, m_id);
        }

        /// <summary>
        /// NT-Return true if method is abstract (without code or script)
        /// </summary>
        /// <returns>True or false</returns>
        public bool IsAbstract()
        {
            return ((String.IsNullOrEmpty(this.m_codePath)) && (String.IsNullOrEmpty(this.m_Script)));
        }
        /// <summary>
        /// NT-Return true if method is code
        /// </summary>
        /// <returns>True or false</returns>
        public bool IsCode()
        {
            return !String.IsNullOrEmpty(this.m_codePath);
        }
        /// <summary>
        /// NT-Return true if method is script
        /// </summary>
        /// <returns>True or false</returns>
        public bool IsScript()
        {
            return !String.IsNullOrEmpty(this.m_Script);
        }

        /// <summary>
        /// NT-Get method path elements - assembly[0], class[1], methodName[2]
        /// </summary>
        /// <returns>Array of string with 3 elements</returns>
        public String[] getMethodPathElements()
        {
            return MMethod.SplitFuncPath(this.CodePath);
        }
        /// <summary>
        /// NT-Parse path string to 3 elements - assembly[0], class[1], methodName[2]
        /// </summary>
        /// <param name="path">Function path string</param>
        /// <returns>Array of string with 3 elements</returns>
        public static String[] SplitFuncPath(String path)
        {
            return path.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
        }

        /// <summary>
        /// NT-Get assembly file path for assembly loading
        /// </summary>
        /// <param name="assemblyName">aAssembly name without extension</param>
        /// <returns>Full assembly file path</returns>
        public static string getAssemblyFilePath(string assemblyName)
        {
            String asmPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            asmPath = Path.ChangeExtension(Path.Combine(asmPath, assemblyName), ".dll");
            return asmPath;
        }
        /// <summary>
        /// NT-Get assembly name without extension
        /// </summary>
        /// <param name="assemblyPath">Full path of assembly dll</param>
        /// <returns>Assembly name without extension</returns>
        public static string getAssemblyShortName(string assemblyPath)
        {
            return Path.GetFileNameWithoutExtension(assemblyPath);
        }

        /// <summary>
        /// NT-Get implementation function name
        /// </summary>
        /// <returns>Implementation function name "name_id"</returns>
        public String getFunctionName()
        {
            return String.Format("{0}_{1}", this.m_name, this.m_id);
        }
        /// <summary>
        /// NT-Set method path - combine assembly, implementation class name, current method name and method ID
        /// </summary>
        /// <param name="AssemblyName">Assembly dll file name without extension</param>
        /// <param name="ClassName">Class name</param>
        public void setCodePath(String AssemblyName, string ClassName)
        {
            this.m_codePath = String.Format("{0}.{1}.{2}", AssemblyName, ClassName, getFunctionName());
        }

        /// <summary>
        /// NT-Load assembly and get MethodInfo of method implementation function
        /// </summary>
        /// <returns>MethodInfo object represent method code</returns>
        /// <exception cref="SeMethodImplementationNotFoundException">Assembly, class or function for method implementation not found</exception>
        internal MethodInfo getMethodInfo()
        {
            //get assembly, class, function names
            String[] names = getMethodPathElements();
            //get assembly pathname
            String asmPath = getAssemblyFilePath(names[0]);
            //load assembly
            Assembly aa = Assembly.LoadFile(asmPath);
            if (aa == null) throw new SeMethodImplementationNotFoundException(SeMethodImplementationNotFoundException.assemblyNFmsg, this);
            Type tt = aa.GetType(String.Format("{0}.{1}", names[0], names[1]));
            if (tt == null) throw new SeMethodImplementationNotFoundException(SeMethodImplementationNotFoundException.classNFmsg, this); //
            MethodInfo m = tt.GetMethod(names[2]);
            if (m == null) throw new SeMethodImplementationNotFoundException(SeMethodImplementationNotFoundException.functionNFmsg, this); //
            return m;
        }
        /// <summary>
        /// NT-Get state of method implementation function
        /// </summary>
        /// <returns>One of implementation state values</returns>
        public ImplementationState getStateOfImplement()
        {
            ImplementationState ist = ImplementationState.NotRealized;
            try
            {
                MethodInfo mi = getMethodInfo();
                Object[] oo = mi.GetCustomAttributes(typeof(SeImplementAttribute), false);
                if (oo.Length > 0) ist = ((SeImplementAttribute)oo[0]).ElementValue;
            }
            catch (Exception)
            {
                //any exceptions cause method not valid
            }
            return ist;
        }

        /// <summary>
        /// NT-check SeImplementation method attribute 
        /// </summary>
        /// <param name="m">MethodInfo object</param>
        /// <exception cref="SeAbortedByUserException">Operation aborted by User</exception>
        internal static void checkMethodAttributes(MethodInfo m)
        {
            Object[] oo = m.GetCustomAttributes(typeof(SeImplementAttribute), false);
            string text;
            if (oo.Length > 0)
            {
                //show warning message if method not ready
                ImplementationState ss = ((SeImplementAttribute)oo[0]).ElementValue;
                if (ss == ImplementationState.Ready) return; //exit if method state normal 
                else
                {
                    text = String.Format("Method \"{0}\" marked \"{1}\".\r\nMethod may destroy database integrity.\r\nRun anyway?", m.Name, ss);
                }
            }
            else
            {
                text = String.Format("Method \"{0}\" has not SeImplement Attribute.\r\nMethod may destroy database integrity.\r\nRun anyway?", m.Name);
            }
            //show Yes/No message
            DialogResult dr = MessageBox.Show(text, "Method execution warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.No) throw new SeAbortedByUserException(m.Name);  //(SeCodeException"Method not ready, operation aborted by user");
        }

        /// <summary>
        /// NT-Check count of arguments between args array and kta0 of method. Args array may be null, thus not trivial checking
        /// </summary>
        /// <param name="args">Array of arguments for method</param>
        /// <returns>Return true if array of arguments has valid count, false otherwise</returns>
        internal bool checkArgsCount(Object[] args)
        {
            bool res = true;
            if (args == null)
            {
                if (this.KTA_0.argList.Count > 0) res = false;
            }
            else if ((this.KTA_0.argList.Count != args.Length)) res = false;
            return res;
        }


        #endregion
    }
}
