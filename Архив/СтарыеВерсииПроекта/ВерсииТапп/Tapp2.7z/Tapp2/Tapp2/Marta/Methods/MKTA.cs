using System;
using System.Collections.Generic;
using System.Text;

namespace Marta.Methods
{
    /// <summary>
    /// Class represent KTA for method
    /// </summary>
    public class MKTA
    {
        #region Fields
        /// <summary>
        /// KTA id
        /// </summary>
        private MKtaID m_KtaID;
        /// <summary>
        /// Method result
        /// </summary>
        private MArg m_result;
        /// <summary>
        /// List of arguments
        /// </summary>
        private List<MArg> m_argList;
        /// <summary>
        /// Class id
        /// </summary>
        private MID m_classId;
        /// <summary>
        /// Method quality
        /// </summary>
        private int m_Quality;
        /// <summary>
        /// KTA multiplicity
        /// </summary>
        private uint m_Multi;

        #endregion
        /// <summary>
        /// Default constructor for xml
        /// </summary>
        public MKTA()
        {
            m_argList = new List<MArg>();
            m_KtaID = new MKtaID();
            m_result = new MArg();
            m_classId = MID.UnusedId;
        }

        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="copy">MKTA object for copying</param>
        internal MKTA(MKTA copy)
        {
            //copy argument list
            m_argList = new List<MArg>();
            foreach(MArg ma in copy.m_argList)  m_argList.Add(ma.getCopy());
            //add copy of all other fields
            m_classId = copy.m_classId.getCopy();
            m_KtaID = copy.m_KtaID.getCopy();
            m_result = copy.m_result.getCopy();
            //TODO: if some fields be added, add code here

        }
        /// <summary>
        /// Params constructor
        /// </summary>
        /// <param name="methId">Method id</param>
        /// <param name="ktaId">KTA id, must be 0 for kta0</param>
        public MKTA(uint methId, uint ktaId)
        {
            m_argList = new List<MArg>();
            m_KtaID = new MKtaID(methId, ktaId);
            m_result = new MArg();
            m_classId = MID.UnusedId;
        }

        #region Properties
        /// <summary>
        /// Kta ID
        /// </summary>
        public MKtaID KtaID
        {
            get
            {
                return m_KtaID;
            }
            set
            {
                m_KtaID = value;
            }
        }
        /// <summary>
        /// Quality of this method (-0+)
        /// </summary>
        public int Quality 
        {
            get
            {
                return m_Quality;
            }
            set
            {
                m_Quality = value;
            }
        }
        /// <summary>
        /// Count of grouped kta
        /// </summary>
        /// <remarks>
        /// If more than one equal kta exists, these kta must be grouped into one kta, called Grouped kta.
        /// Initial value (for non-grouped kta) is 0. 
        /// </remarks>
        public uint Multi
        {
            get
            {
                return m_Multi;
            }
            set
            {
                m_Multi = value;
            }
        }

        /// <summary>
        /// Id of class who use this KTA
        /// </summary>
        public MID ClassID
        {
            get
            {
                return m_classId;
            }
            set
            {
                m_classId = value;
            }
        }
        /// <summary>
        /// Result argument
        /// </summary>
        public MArg Result
        {
            get
            {
                return m_result;
            }
            set
            {
                //TODO: ������������ ������ �� �����
                m_result = value; //now use reference
            }
        }
        /// <summary>
        /// List of arguments
        /// </summary>
        public List<MArg> argList
        {
            get
            {
                return m_argList;
            }

        }
        #endregion

        /// <summary>
        /// NT-Get copy of current kta
        /// </summary>
        public MKTA getCopy()
        {
            return new MKTA(this);
        }

        /// <summary>
        /// NT-Return string representation of kta
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("{0} {1} {2}args",  m_KtaID, m_classId.ToString(), m_argList.Count);
        }

        /// <summary>
        /// NR-return true if current kta match with other kta
        /// </summary>
        /// <param name="kta">compared kta</param>
        /// <exception cref="NotImplementedException">Function not implemented</exception>
        /// <remarks>Function not implemented</remarks>
        public bool isEqualKta(MKTA kta)
        {
            //TODO: � ����������� �� ���������� ���� ������ ��������. ���� ������, ��� ������
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// 130511 NR-Make kta from arguments
        /// </summary>
        /// <param name="caller">Caller class or object</param>
        /// <param name="res">Result value and type</param>
        /// <param name="args">Argument array or null</param>
        /// <returns>Filled kta without kta id</returns>
        internal static MKTA intFillKtaArgs(MCell caller, MIDType res, Object[] args)
        {
            MKTA kta = new MKTA();
            kta.ClassID.ClassID = caller.ID.ClassID; //class id of caller
            kta.ClassID.ObjID = caller.ID.ObjID;
            //add arguments only. Container and caller must be added automatically before code invoke
            //if args.count = 0 then no other arguments
            //if method return nothing, res can be any type.
            //(����� ���������� ����� ����, �� ��� ���������� � ������������ ��� ����� � ����?)
            
            //result already created, fill it
            kta.Result.makeArgType(res);//value of result will be null!
            kta.Result.Name = "Result";
            //fill all other args if not null
            if(args != null)
                for (int i = 0; i < args.Length; i++)
                {
                    kta.argList.Add(new MArg("Arg", "", args[i])); 
                }
            return kta;
        }
    }
}
