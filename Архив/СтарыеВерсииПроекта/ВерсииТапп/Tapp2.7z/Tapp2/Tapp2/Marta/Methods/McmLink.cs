using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Marta.Methods
{
    /// <summary>
    /// Class represent link between class and method
    /// </summary>
    public class McmLink
    {
#region Fields
        /// <summary>
        /// class or object ID
        /// </summary>
        private MID m_classId;
        /// <summary>
        /// Method and KTA id
        /// </summary>
        private MKtaID m_methodID;
#endregion
        /// <summary>
        /// NT-default constructor for XML
        /// </summary>
        public McmLink()
        {
            m_classId = new MID();
            m_methodID = new MKtaID();
        }

        /// <summary>
        /// NT-params constructor
        /// </summary>
        /// <param name="clsId">Class or object ID</param>
        /// <param name="metId">Method and KTA id</param>
        public McmLink(MID clsId, MKtaID metId)
        {
            m_classId = new MID(clsId);
            m_methodID = new MKtaID(metId);
        }

        #region Properties
        /// <summary>
        /// Class or object ID
        /// </summary>
        [XmlIgnore]
        public MID ClassID
        {
            get
            {
                return m_classId;
            }
            set
            {
                m_classId = value;
            }
        }

        /// <summary>
        /// Method and KTA id
        /// </summary>
        [XmlIgnore]
        public MKtaID MethodID
        {
            get
            {
                return m_methodID;
            }
            set
            {
                m_methodID = value;
            }
        }

        /// <summary>
        /// Link as text string for XML serializing and best readability
        /// </summary>
        public String LinkStr
        {
            get { return this.ToString(); }
            set { parseStrValue(value); }
        }
        #endregion
        /// <summary>
        /// Return string representation of link
        /// </summary>
        override public string ToString()
        {
            return String.Format("{0} {1}", m_classId.ToString(), m_methodID.ToString());
        }
        /// <summary>
        /// Parse string representation of link
        /// </summary>
        /// <param name="str">String representation of link</param>
        private void parseStrValue(String str)
        {
            //parse string    256:0 258:0
            String[] strs = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            this.m_classId.IDstr = strs[0];
            this.m_methodID.IDstr = strs[1];
        }
    }
}
