using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Marta.Methods
{
    /// <summary>
    /// Dialog for manual select Method KTA in some cases
    /// </summary>
    /// <remarks> 
    /// This must be external dialog, but after test only.
    /// Now undone.
    /// </remarks>
    public partial class SelectKtaDlg : Form
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SelectKtaDlg()
        {
            InitializeComponent();
        }

    }
}