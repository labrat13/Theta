using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Marta.Methods
{
    /// <summary>
    /// Contains type of C# data and type of semantic data
    /// </summary>
    /// <remarks>
    /// Used for specification of return type in method call.
    /// Currently loading/saving XML not supported.
    /// </remarks>
    public class MIDType
    {
        /// <summary>
        /// ID of semantic type
        /// </summary>
        private MID _mid;
        /// <summary>
        /// CS type of object
        /// </summary>
        private Type _cstype;
        /// <summary>
        /// Default constructor, for XML use
        /// </summary>
        public MIDType()
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="id">Object ID for copy</param>
        /// <param name="t">Object CS type</param>
        public MIDType(MID id, Type t)
        {
            _mid = id.getCopy();
            _cstype = t;
        }
        /// <summary>
        /// Param constructor for arguments
        /// </summary>
        /// <param name="obj">C# object or semantic object</param>
        public MIDType(Object obj)
        {
            if(MIDType.isSemanticDataTypeObj(obj))
                _mid = ((MCell)obj).ID.getCopy();
            else _mid = MID.UnusedId;
            _cstype = obj.GetType();
        }
        /// <summary>
        /// Param constructor without MID
        /// </summary>
        /// <param name="t">Object C# type</param>
        public MIDType(Type t)
        {
            _mid = MID.UnusedId;
            _cstype = t;
        }

        
        /// <summary>
        /// ID of semantic type
        /// </summary>
        /// <remarks>Setter function make copy of origin MID</remarks>
        public MID ID
        {
            get { return _mid; }
            set { _mid = value.getCopy(); }
        }

        /// <summary>
        /// C# type of object
        /// </summary>
        [XmlIgnore]
        public Type csType
        {
            get { return _cstype; }
            set { _cstype = value; }
        }

        /// <summary>
        /// Return string representation of object
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("{0} {1}", _mid, _cstype);
        }

        /// <summary>
        /// Return true if argument is semantic data type MCell MClass MObj, false otherwise
        /// </summary>
        /// <param name="obj">Semantic object</param>
        /// <returns>True or false</returns>
        public static bool isSemanticDataTypeObj(Object obj)
        {
            Type t = obj.GetType();
            return ((t == typeof(MCell)) || (t == typeof(MObj)) || (t == typeof(MClass)));
        }
        /// <summary>
        /// Return true if argument is type of semantic data type MCell MClass MObj, false otherwise
        /// </summary>
        /// <param name="t">Semantic object type</param>
        /// <returns>True or false</returns>
        public static bool isSemanticDataType(Type t)
        {
            return ((t == typeof(MCell)) || (t == typeof(MObj)) || (t == typeof(MClass)));
        }

    }
}
