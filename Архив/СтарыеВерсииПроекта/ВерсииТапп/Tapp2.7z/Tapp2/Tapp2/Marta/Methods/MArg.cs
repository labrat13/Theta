using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;

namespace Marta.Methods
{
    /// <summary>
    /// Class represent argument for method
    /// </summary>
    public class MArg
    {
        /// <summary>
        /// Argument description
        /// </summary>
        private String _Description;
        /// <summary>
        /// Argument name
        /// </summary>
        private String _Name;
        /// <summary>
        /// Argument value or reference
        /// </summary>
        private Object _Value;
        /// <summary>
        /// Argument type 
        /// </summary>
        private Type _Type;
        /// <summary>
        /// Class id of argument if argument is a semantic object
        /// </summary>
        private MID _ClassId;

        #region Properties
        /// <summary>
        /// Argument C#-type
        /// </summary>
        [XmlIgnore]
        public Type argType
        {
            get { return _Type; }
            set { _Type = value; }
        }

        /// <summary>
        /// Class id of argument if argument is a semantic object. UndefinedID otherwise.
        /// </summary>
        [XmlIgnore]
        public MID ClassId
        {
            get
            {
                return _ClassId;
            }
            set
            {
                _ClassId = new MID(value);//make copy
            }
        }

        /// <summary>
        /// Argument description. Do not use XML brackets and ~ chars in this description because its used by XML parsing
        /// </summary>
        /// <remarks>Do not use XML brackets and ~ chars in this description because its used by XML parsing</remarks>
        [XmlIgnore]
        public String Description
        {
            get
            {
                return _Description;
            }
            set
            {
                _Description = value;
            }
        }

        /// <summary>
        /// Argument name. Do not use XML brackets and ~ chars in this description because its used by XML parsing
        /// </summary>
        /// <remarks>Do not use XML brackets and ~ chars in this description because its used by XML parsing</remarks>
        [XmlIgnore]
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }

        /// <summary>
        /// Get argument typename
        /// </summary>
        [XmlIgnore]
        public string TypeName
        {
            get
            {
                return _Type.FullName;
            }
        }
        /// <summary>
        /// Argument value or reference. 
        /// </summary>
        [XmlIgnore]
        public Object Value
        {
            get
            {
                return _Value;
            }
            set
            {
                _Value = value;
            }
        }
        /// <summary>
        /// Argument as text string for XML serializing and best readability
        /// </summary>
        public String ArgStr
        {
            get { return this.ToString(); }
            set { parseStrValue(value); }
        }
        #endregion


        /// <summary>
        /// Default constructor for XML
        /// </summary>
        public MArg()
        {
            _Description = "";
            _Name = "";
            _Value = null;
            _Type = typeof(Object);
            _ClassId = new MID();
        }



        /// <summary>
        /// NT-params constructor
        /// </summary>
        /// <param name="name">Argument name</param>
        /// <param name="description">Argument description</param>
        /// <param name="valueType">Argument value type</param>
        /// <param name="classID">ID of Argument semantic object or null</param>
        public MArg(String name, String description, Type valueType, MID classID)
        {
            _Name = name;
            argType = valueType;
            _Description = description;
            _Value = null;   //don't use value of argument now
            if (classID == null) _ClassId = MID.UnusedId;
            else  _ClassId = new MID(classID);
        }
        /// <summary>
        /// NT-params constructor
        /// </summary>
        /// <param name="name">Argument name</param>
        /// <param name="description">Argument description</param>
        /// <param name="valueType">Argument value type</param>
        /// <param name="val">Argument value</param>
        /// <param name="classID">ID of Argument semantic object or null</param>
        public MArg(String name, String description, Type valueType, Object val, MID classID)
        {
            _Name = name;
            argType = valueType;
            _Description = description;
            _Value = val;
            if (classID == null) _ClassId = MID.UnusedId;
            else _ClassId = new MID(classID);
        }
        /// <summary>
        /// NT-params constructor
        /// </summary>
        /// <param name="name">Argument name</param>
        /// <param name="description">Argument description</param>
        /// <param name="val">Argument value</param>
        public MArg(String name, String description, Object val)
        {
            _Name = name;
            _Description = description;
            this.makeArg(val);
        }
        /// <summary>
        /// Get string representation of argument
        /// </summary>
        /// <returns>String representation of argument</returns>
        public override string ToString()
        {
            //prepare strings - replace empty strings to "-" for correct XML parsing
            if (String.IsNullOrEmpty(this._Description)) this._Description = "-";
            if (String.IsNullOrEmpty(this._Name)) this._Name = "-";
            //serialize value
            String valstr = String.Empty;
            if(this._Value == null) valstr = "null";
            else if(MIDType.isSemanticDataType(_Type)) valstr = _Value.ToString();
            else if (_Type == typeof(String))
            {
                if (String.IsNullOrEmpty((String)_Value)) valstr = "-";//for parser
                else
                {
                    //replace all ">< from string to prevent parsing errors - one function
                    //���� ������� ��������-������ � ���, ���� ����� ��������. 
                    //������ ��� ����� �� ������������ ��� ����������, ���� �� ����� ��������� ��. 
                }
            }
            else valstr = _Value.ToString();
            //serialize
            String s = String.Format("\"{0}\" \"{1}\" \"{2}\" \"{3}\" \"{4}\"", this.TypeName, this._Name, this._Description, _ClassId.ToString(), valstr);
            return s;
        }

        /// <summary>
        /// Parse string representation of argument
        /// </summary>
        /// <param name="str">String representation of argument</param>
        private void parseStrValue(String str)
        {
            //parse string    
            String[] strs = str.Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);
            //get values
            this._Type = Type.GetType(strs[0]);
            this._Name = strs[2];
            this._Description = strs[4];
            this._ClassId.IDstr = strs[6];
            //parse value
            string strval = strs[8];
            if (String.Equals(strval, "null", StringComparison.Ordinal)) _Value = null;
            else if ((_Type == typeof(String)) /*&& (String.Equals(strval, "-", StringComparison.Ordinal))*/ ) _Value = String.Empty; //skip string values
            else _Value = MArg.convertData(strval, _Type);//convert all types to value or to null.
        }

        /// <summary>
        /// Return true if type is allowed for data type
        /// </summary>
        /// <param name="t">Type of argument</param>
        /// <returns>Return true if specified C#-type is allowed for using in arguments. Return false otherwise.</returns>
        /// <remarks>Mainly this function prevent XML serialization errors of using of specified type.</remarks>
        public static bool isAllowedArgType(Type t)
        {
            return ((t == typeof(String)) || (t == typeof(Int32)) || (t == typeof(Int64)) || (t == typeof(Double)) || (t == typeof(DateTime)) ||
                (t == typeof(TimeSpan)) || (t == typeof(Object)) || (t == typeof(MClass)) || (t == typeof(MCell)) || (t == typeof(MObj)) || 
                (t == typeof(List<Object>)) || (t == typeof(UInt32)) || (t == typeof(UInt64)));
        }


        /// <summary>
        /// Convert data from string to specified C#-type. Return null if convert invalid type. 
        /// </summary>
        /// <param name="p">Value string</param>
        /// <param name="t">Value type</param>
        /// <returns>Value or null</returns>
        public static Object convertData(String p, Type t)
        {
            Object resval;
            if((t == typeof(Int32)) || (t == typeof(Int64)) || (t == typeof(Double)) || (t == typeof(DateTime)) ||
                (t == typeof(TimeSpan)) || (t == typeof(UInt32)) || (t == typeof(UInt64)))
            {
                resval = (Object)TypeDescriptor.GetConverter(t).ConvertFromString(p);
            }
            else resval = null;
            
            return resval;
        }
        /// <summary>
        /// Get copy of current argument
        /// </summary>
        /// <returns>Copy of current argument</returns>
        public MArg getCopy()
        {
            MArg a = new MArg(this._Name, _Description, _Type, _ClassId);
            a._Value = this._Value;
            return a;
        }

        /// <summary>
        /// NT-Fill argument type, value, classId
        /// </summary>
        /// <param name="val">Argument value</param>
        public void makeArg(Object val)
        {
            _Value = val;
            _Type = val.GetType();
            if (MIDType.isSemanticDataType(_Type))//MCell MObj MClass
                _ClassId = ((MCell)val).ID;
            else _ClassId = MID.UnusedId;
        }

        /// <summary>
        /// NT-Fill argument type and classId
        /// </summary>
        /// <param name="val">Argument value</param>
        public void makeArgType(MIDType val)
        {
            _Type = val.csType;
            _ClassId = val.ID;
        }

    }
}
