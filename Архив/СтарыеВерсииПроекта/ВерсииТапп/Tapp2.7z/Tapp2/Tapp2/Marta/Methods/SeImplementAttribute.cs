using System;
using System.Collections.Generic;
using System.Text;

namespace Marta.Methods
{
    /// <summary>
    /// Element type mark as code realization stage
    /// </summary>
    public enum ImplementationState
    {
        /// <summary>
        /// Method realization in progress
        /// </summary>
        NotRealized = 0,
        /// <summary>
        /// Method, class, assembly is realized, but not tested
        /// </summary>
        NotTested,
        /// <summary>
        /// Method, class, assembly is full tested and ready to use
        /// </summary>
        Ready,
    }

    /// <summary>
    /// Mark element (assembly, class, method) as a method implementation element with specify an implementation stage
    /// </summary>
    /// <remarks>
    /// This attribute marks assemblies, classes and functions as usable in method execution process.
    /// If assembly, class, function has this attribute, user can use assembly, class and method as method code.
    /// Thus, in GUI user can view, select and assign to methods only valid functions.
    /// </remarks>
    public class SeImplementAttribute : Attribute
    {
        /// <summary>
        /// State of code: Not realized, Not tested, Ready
        /// </summary>
        /// <remarks>
        /// This code state mark method code for Programmer and User.
        /// Programmer must mark function as need.
        /// When User launch code which not mark as Ready, warning box displayed.
        /// </remarks>
        private ImplementationState elem;

        /// <summary>
        /// Params constructor
        /// </summary>
        /// <param name="ie">Code state value: NR, NT, RE</param>
        public SeImplementAttribute(ImplementationState ie)
        {
            elem = ie;
        }
        /// <summary>
        /// Implementation element type
        /// </summary>
        public ImplementationState ElementValue
        {
            get { return elem; }
            set { elem = value; }
        }


    }
}
