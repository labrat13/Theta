using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using Marta.Methods;


namespace Marta
{
    /// <summary>
    /// Represent data abstraction
    /// </summary>
    public class MClass : MCell
    {
        /// <summary>
        /// Objects list
        /// </summary>
        private List<MObj> m_objList;
        /// <summary>
        /// List of links to methods used by this class
        /// </summary>
        private List<Marta.Methods.McmLink> m_methodList;

        
        /// <summary>
        /// Default constructor. For XML loading
        /// </summary>
        public MClass()
        {
            m_isClass = true; //current cell represent class
            m_objList = new List<MObj>(); //create objects list
            m_methodList = new List<Marta.Methods.McmLink>(); //create methods list
            //TODO: add method list creation here...
        }
        /// <summary>
        /// Create new class (no load from XML)
        /// </summary>
        /// <param name="clsID">Class ID</param>
        /// <param name="clsName">Class name</param>
        /// <param name="dataType">Class data type, must be valid System.Type or Custom type with serialization to String support</param>
        /// <param name="comment">Class comment text</param>
        /// <remarks>No links created. BackReference to MEngine is set to null.</remarks>
        internal MClass(uint clsID, string clsName, Type dataType, string comment)
        {
            m_isClass = true; //current cell represent class
            m_objList = new List<MObj>(); //create objects list
            m_methodList = new List<Marta.Methods.McmLink>(); //create methods list
            //setup class fields
            this.m_id = new MID(clsID, (uint)SystemObjectNames.Main);
            this.m_name = clsName;
            this.m_comment = comment;
            this.m_dataType = dataType;
            //create 3 system objects
            MObj ob = new MObj(new MID(clsID, (uint)SystemObjectNames.Unknown), "Unknown", "system object Unknown", null, dataType);
            this.m_objList.Add(ob);
            ob = new MObj(new MID(clsID, (uint)SystemObjectNames.Undefined), "Undefined", "system object Undefined", null, dataType);
            this.m_objList.Add(ob);
            ob = new MObj(new MID(clsID, (uint)SystemObjectNames.Nothing), "Nothing", "system object Nothing", null, dataType);
            this.m_objList.Add(ob);
        }

        #region Properties

        /// <summary>
        /// Get reference to MEngine container
        /// </summary>
        /// <remarks>Old version access to container. Infrastructure. Do not remove.</remarks>
        [XmlIgnore]
        public MEngine Parent
        {
            get
            {
                return (MEngine)m_parent;
            }
        }

        /// <summary>
        /// Get reference to MEngine container
        /// </summary>
        /// <remarks>New version access to container</remarks>
        [XmlIgnore]
        public override MEngine Container
        {
            get { return (MEngine)m_parent; }
        }

        /// <summary>
        /// Get list of classes
        /// </summary>
        public List<MObj> Objects
        {
            get
            {
                return m_objList;
            }
        }

        /// <summary>
        /// Get list of links to  methods used by this class
        /// </summary>
        /// <remarks> This property used by XML</remarks>
        public List<Marta.Methods.McmLink> MethodLinkList
        {
            get
            {
                return m_methodList;
            }
        }
        
        #endregion


        /// <summary>
        /// NT-Remove user class from classes list or mark as deleted
        /// </summary>
        /// <remarks>If class not exists in list, silent</remarks>
        /// <param name="markOnly">True - mark as deleted, False - remove object</param>
        /// <exception cref="SeInvalidUseSystemObjectException">System class cannot be deleted!</exception>
        public void Delete(bool markOnly)
        {
            if (!this.ID.isUserClass) throw new SeInvalidUseSystemObjectException("System class cannot be deleted!");
            //add some specific code here... 
            if (markOnly) this.State = MCellState.Deleted;
            else this.Parent.Classes.Remove(this);
        }


        /// <summary>
        /// Set back reference to parent container
        /// </summary>
        /// <param name="cont">Parent container address</param>
        /// <remarks>Used by container for setup Parent references. Internal use only.</remarks>
        internal void intSetBackRefs(MEngine cont)
        {
            m_parent = cont;
            //set backrefs in objects
            foreach (MObj m in m_objList)
                m.intSetBackRefs(this);
        }

        #region Objects
        /// <summary>
        /// NT-Get object from object list with all checkings  
        /// Return object or throw SeObjectNotFoundException if object not exists or has been deleted
        /// </summary>
        /// <param name="objId">Object ID</param>
        /// <returns>Object or throw SeObjectNotFoundException if object not exists or has been deleted</returns>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeObjectNotFoundException">Thrown if object not found</exception>
        /// <exception cref="SeInvalidUseClassException">Thrown if ID is class</exception>
        public MObj GetObject(MID objId)
        {
            //validate classId
            if (this.ID.ClassID != objId.ClassID) throw new SeArgumentException("Invalid ClassID of object");
            //search
            MObj obj = intGetObject(objId);
            if ((obj == null) || (obj.State == MCellState.Deleted)) throw new SeObjectNotFoundException(objId);//object not found
            else return obj;
        }

        /// <summary>
        /// NT-Return any object from objects list. 
        /// Return NULL if object not found.
        /// Throw exception if MID is class ID
        /// </summary>
        /// <param name="objId">Object ID</param>
        /// <returns>Return object or NULL if not found</returns>
        /// <exception cref="SeInvalidUseClassException">Thrown if ID is class ID</exception>
        internal MObj intGetObject(MID objId)
        {
            MObj obj = null;
            //objectId cannot be a class Id (0)
            objId.IsMainObjectThrowException();
            //search
            foreach (MObj ob in this.Objects)
            {
                if (ob.ID.isEqual(objId))
                {
                    obj = ob;
                    break;
                }
            }
            return obj;
        }
        /// <summary>
        /// NT-Get Undefined object of current class. Throw SeInvalidBaseException if object not found.
        /// </summary>
        /// <returns>System object Undefined</returns>
        /// <exception cref="SeInvalidBaseException">If object not found in class</exception>
        internal MObj getUndefinedObj()
        {
            foreach (MObj ob in this.Objects)
                if (ob.ID.ObjID == (uint)SystemObjectNames.Undefined) return ob;
            //if not found
            throw new SeInvalidBaseException("Database format Invalid: obj Undefined is not found", this);
        }

        /// <summary>
        /// Get free ID for creating new user object
        /// </summary>
        /// <returns>Free ID for new user object</returns>
        /// <remarks>Free number calculate as (max from existing)+1, but more than 255. </remarks>
        private MID getFreeObjectId()
        {
            uint max = 0;
            uint tmp = 0;
            //get max of ObjID
            foreach (MObj mo in this.Objects)
            {
                tmp = mo.ID.ObjID;//cashing
                if (tmp > max) max = tmp;
            }
            //if max not in user space, change it
            if (max < 255) max = 255;
            //return next number
            max++;
            return new MID(this.ID.ClassID, max);
        }

        /// <summary>
        /// NT-Create new user object, add it to list of objects
        /// </summary>
        /// <param name="Name">Object name</param>
        /// <param name="Comment">Object comment</param>
        /// <param name="ObjData">Object data</param>
        /// <param name="state">Object state</param>
        /// <param name="ReadOnly">Object read-only flag</param>
        /// <returns>Created object</returns>
        /// <remarks>
        /// Links are copied from template 1 by 1, but target object replaced to Undefined object.
        /// This function creates object in User object space (ID > 255). Don't use for system object creating.
        /// </remarks>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Datatype of new object not match datatype of class</exception>
        /// <exception cref="SeLinkNotFoundException">If one of two halflinks exist only</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        public MObj createObject(string Name, String Comment, Object ObjData, MCellState state, bool ReadOnly)
        {
            //check match of datatypes of template and object
            if (!Type.Equals(ObjData.GetType(), this.DataType))
                throw new SeArgumentException("The type of the data of created objects does not correspond to type of the data of a class", this);
            //create new object
            MObj obj = new MObj(getFreeObjectId(), Name, Comment, ObjData, ObjData.GetType());
            obj.State = state;
            obj.ReadOnly = ReadOnly;
            //copy links from template, replace target object to Undefined
            copyClassLinksToObj(Axiss.Xdown, obj);
            copyClassLinksToObj(Axiss.Xup, obj);
            copyClassLinksToObj(Axiss.Ydown, obj);
            copyClassLinksToObj(Axiss.Yup, obj);
            copyClassLinksToObj(Axiss.Zdown, obj);
            copyClassLinksToObj(Axiss.Zup, obj);
            //set backrefs 
            obj.intSetBackRefs(this);
            //add to class objects list
            this.Objects.Add(obj);
            //something...
            return obj;
        }

        /// <summary>
        /// NT-Copy class links to object, replace target obj to Undefined obj.
        /// Helper for createObject function
        /// </summary>
        /// <param name="axis">Link axis for work</param>
        /// <param name="obj">New object</param>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        private void copyClassLinksToObj(Axiss axis, MObj obj)
        {
            List<MLink> lis = this.getAxisList(axis);//get list for specified link axis
            MID lid; MObj ob;
            foreach (MLink li in lis)
            {
                //copy active links with target to Undefined object
                if (li.eLinkState == MLinkState.Active)
                {
                    lid = li.DestObjectID.getID_Undefined(); //make id of undefined object of target class
                    ob = this.Parent.getObject(lid); //get target object from MEngine
                    obj.L0AddLinkNocheck(axis, ob, li.eLinkType, false); //create links
                }
            }
        }

        /// <summary>
        /// NT-Create new object (state=Normal, ReadOnly=false) and put to object list. Short version.
        /// </summary>
        /// <param name="Name">Object name</param>
        /// <param name="Comment">Object comment</param>
        /// <param name="ObjData">Object data</param>
        /// <returns>Created object</returns>
        ///<remarks>This function creates object in User object space (ID > 255). Don't use for system object creating.</remarks>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Datatype of new object not match datatype of class</exception>
        /// <exception cref="SeInvalidUseClassException">??? Where?</exception>
        /// <exception cref="SeDataTypeMismatchException">Datatype of object not match datatype of class</exception>
        /// <exception cref="SeLinkNotFoundException">If one of two halflinks exist only</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception> 
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        public MObj createObject(string Name, String Comment, Object ObjData)
        {
            return createObject(Name, Comment, ObjData, MCellState.Normal, false);
        }

        /// <summary>
        /// NT-Remove user object from objects list or mark as deleted
        /// </summary>
        /// <param name="objId">Object ID</param>
        /// <param name="markAsDeleted">True - mark as deleted, False - remove object</param>
        /// <exception cref="SeInvalidUseClassException">Thrown if ID is class ID</exception>
        /// <exception cref="SeInvalidUseSystemObjectException">Current object is system object</exception>
        public void deleteObject(MID objId, bool markAsDeleted)
        {
            MObj ob = this.intGetObject(objId);
            ob.Delete(markAsDeleted);
        }

        /// <summary>
        /// Clear search flag for any objects in class, not for class.
        /// </summary>
        /// <remarks>Internal use only</remarks>
        internal void clearSearchFlagObjs()
        {
            foreach (MObj m in this.Objects)
            {
                m.SearchFlag = 0;
            }
        }

        #endregion

        #region Links

        /// <summary>
        /// NT-Get type of link between classes
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targCls">Target class</param>
        /// <returns>Main type of links or MLinkType.NotFound if no links found</returns>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        public MLinkType getLinkType(Axiss axis, MClass targCls)
        {
            return this.L0GetLinkType(axis, targCls);
        }


        /// <summary>
        /// NT-Create link to target class
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targCls">Target class</param>
        /// <param name="typ">Link type of new link</param>
        /// <exception cref="SeLinkStateMismatchException">Link states mismatch between linked objects</exception>
        /// <exception cref="SeLinkAlreadyExistsException">Link already exists</exception>
        /// <exception cref="SeMutualLinkErrorException">Another link already exists</exception>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException"></exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeArgumentException">Target class same as current class</exception>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        public void createLink(Axiss axis, MClass targCls, MLinkType typ)
        {
            //check - source object and target object is same object
            if (this.ID.isEqual(targCls.ID)) throw new SeArgumentException(SeArgumentException.srcSameTrgMsg, this);//"Target class same as current class");
            //check link exists and link state
            //get states of links between classes
            MLinkType st0 = this.L0GetLinkType(axis, targCls);
            if (st0 != MLinkType.NotFound) throw new SeLinkAlreadyExistsException(this);    //"Link already exists!"
            //check another link exists for preventing from mutual links
            MLinkType st1 = this.L0GetLinkType(MCell.inverseAxis(axis), targCls);
            if (st1 != MLinkType.NotFound) throw new SeMutualLinkErrorException(this);  //"Another link already exists!" 
            //create link
            this.intL2CreateLink(axis, targCls, typ);//layer 1 used
            //check uplinks and delete uplink to World class
            this.CheckWorldLink(axis);
            targCls.CheckWorldLink(MCell.inverseAxis(axis));
        }

        /// <summary>
        /// NT-Create link to target class with Normal type.
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targCls">Target class</param>
        /// <exception cref="SeLinkStateMismatchException">Link states mismatch between linked objects</exception>
        /// <exception cref="SeLinkAlreadyExistsException">Link already exists</exception>
        /// <exception cref="SeMutualLinkErrorException">Another link already exists</exception>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException"></exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeArgumentException">Target class same as current class</exception>
        /// <exception cref="SeLinkStateMismatchException">Link states not matched</exception>
        /// <exception cref="SeLinkNotFoundException">If one of two halflinks exist only</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        public void createLink(Axiss axis, MClass targCls)
        {
            createLink(axis, targCls, MLinkType.Normal);
        }

        /// <summary>
        /// NT-Create link between classes and next, between user objects and Undefined obj. No check performed.
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targCls">Target class for linking</param>
        /// <param name="typ">Link type</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        internal void intL2CreateLink(Axiss axis, MClass targCls, MLinkType typ)
        {
            //add links between classes.
            this.L0AddLinkNocheck(axis, targCls, typ, false);
            //get Udefined obj of target class
            MObj und = targCls.getUndefinedObj();
            //link all user objects to undefined obj of target class
            foreach (MObj ob in this.Objects)
            {
                if (ob.ID.isUserObject)
                    ob.L0AddLinkNocheck(axis, und, typ, false);
            }
            //those for target class
            axis = MCell.inverseAxis(axis);//inverse axis for links back from target objs
            und = this.getUndefinedObj();
            //link all target user objs to current undefined
            foreach (MObj ok in targCls.Objects)
                if (ok.ID.isUserObject) ok.L0AddLinkNocheck(axis, und, typ, false);
        }

        /// <summary>
        /// NT-Check class for uplinks and add or remove link to World - need fast detection
        /// </summary>
        /// <param name="axis">Axis for work. Any Down axises will be skipped</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeObjectNotFoundException">Class not found</exception>
        private void CheckWorldLink(Axiss axis)
        {
            //if current class is System class, or axis is any down, skip checking without any msgs
            if ((!this.ID.isUserClass) || (axis == Axiss.Xdown) || (axis == Axiss.Ydown) || (axis == Axiss.Zdown)) return;
            //check uplinks: if upclasses = 0,  no world link - add world link
            //if upclasses (without World and other system classes) > 0, remove World link
            bool hasUserClasses = false;
            bool hasWorld = false;
            //find any user classes
            List<MLink> ul = this.getAxisList(axis);//get list of links
            foreach (MLink li in ul)
            {
                if ((li.eLinkState == MLinkState.Active) && (li.eLinkType == MLinkType.Normal))
                {
                    if (li.DestObjectID.isUserClass)
                    {
                        hasUserClasses = true;
                        break;
                    }
                    else if (li.DestObjectID.IsWorldClass) hasWorld = true;//optimization - presearch for world
                }
            }
            if (hasUserClasses)
            {
                //if any user class exists, delete link to world
                MClass mcl = this.Parent.getClass((uint)SystemClassNames.World);
                this.L2DeleteLinksAnyObj(axis, mcl);
            }
            else //no user classes 
            {
                //find World link - main search (because previous search break in middle)
                if (hasWorld == false) //presearch fail
                    foreach (MLink lin in ul)
                        if ((lin.DestObjectID.IsWorldClass) && (lin.eLinkType == MLinkType.Normal) && (lin.eLinkState == MLinkState.Active))
                        {
                            hasWorld = true;
                            break;
                        }
                //if world link not detected, create it
                if (hasWorld == false)
                {
                    MClass mc = this.Parent.getClass((uint)SystemClassNames.World);
                    this.intL2CreateLink(axis, mc, MLinkType.Normal); //TODO: change call to appropriate functions
                }
            }//end else
        }

        /// <summary>
        /// NT-Change type of link between classes
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targCls">Target class</param>
        /// <param name="typ">New link type</param>
        /// <exception cref="SeInvalidBaseException">Structure error! One halflink is absent</exception>
        /// <exception cref="SeLinkNotFoundException">Link not found</exception>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        public void changeLinkType(Axiss axis, MClass targCls, MLinkType typ)
        {
            //TODO: ������� �������� ����������� ���������������.
            //1-change link type for class
            this.L0changeLinkType(axis, targCls, typ);
            //2-change link type for all objects. If any exception throwed, rollback must do
            this.L1ChangeHalfLinksType(axis, targCls.ID.ClassID, typ);
            targCls.L1ChangeHalfLinksType(MCell.inverseAxis(axis), this.ID.ClassID, typ);
        }
        /// <summary>
        /// Change type of halflinks to any object of target class, for all objects of current class
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="clsId">Target class num</param>
        /// <param name="typ">New type of link</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal void L1ChangeHalfLinksType(Axiss axis, uint clsId, MLinkType typ)
        {
            foreach (MObj ob in this.Objects)
                ob.L1ChangeHalfLinkType(axis, clsId, typ);
        }


        /// <summary>
        ///NT Delete link to target class
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targCls">Linked class</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        /// <exception cref="SeTooManyLinksException">Invalid base format. More than one link exists.</exception>
        /// <exception cref="SeInvalidBaseException">Invalid structure! One halflink is absent</exception>
        /// <exception cref="SeObjectNotFoundException">Class not found</exception>
        public void deleteLink(Axiss axis, MClass targCls)
        {
            if (this.ID.isEqual(targCls.ID)) throw new SeArgumentException(SeArgumentException.srcSameTrgMsg, this);
            this.L2DeleteLinksAnyObj(axis, targCls);
            //check for upclasses and link to world
            this.CheckWorldLink(axis);
            targCls.CheckWorldLink(MCell.inverseAxis(axis));
        }

        /// <summary>
        /// Delete links betwen classes
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targCls">Target class</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal void L2DeleteLinksAnyObj(Axiss axis, MClass targCls)
        {
            //delete link between classes
            this.L0DeleteLinkNoCheck(axis, targCls, true);
            //remove links from objects
            this.L1DeleteHalfLinksAnyObj(axis, targCls.ID.ClassID);
            targCls.L1DeleteHalfLinksAnyObj(MCell.inverseAxis(axis), this.ID.ClassID);
        }

        /// <summary>
        /// Delete all links to target class from all objects of current class
        /// </summary>
        /// <param name="axis">Axis for work</param>
        /// <param name="targClsId">Target class num</param>
        /// <exception cref="SeArgumentException">Invalid axis code</exception>
        protected internal void L1DeleteHalfLinksAnyObj(Axiss axis, uint targClsId)
        {
            foreach (MObj ob in this.Objects) ob.L1DeleteHLinkAnyObj(axis, targClsId, true);
        }
#endregion

        #region Methods
        
        ///<summary>
        /// NT-Return KtaId for linked method or null if method not found
        /// </summary>
        /// <param name="methodNum">Method num</param>
        internal Methods.MKtaID getLinkedMethodKtaId(uint methodNum)
        {
            MKtaID res = null;
            //���������� ��� �����, ���������� ������ ���������� ����� � ������ ������� ������
            foreach (Methods.McmLink li in this.m_methodList)
            {
                if (li.MethodID.MethodID == methodNum) res = li.MethodID;
            }
            return res;
        }
        
        ///<summary>
        /// NT-Get list of methods linked to class, by method name
        /// </summary>
        /// <param name="name">Method name</param>
        internal List<Methods.MMethod> getLinkedMethodsByName(string name)
        {
            //�������� ������� ���������� - ������ �������. ����� �����-����� �� ������� ������ ����� �� ����������
            return this.Parent.intGetClassLinkedMethodsByName(this.ID.ClassID, name);
        }



        #endregion


        #region *** Class-Method link ***

        /// <summary>
        /// NT-Create class-method halflink
        /// </summary>
        /// <param name="targId">Method and kta id</param>
        /// <exception cref="SeLinkAlreadyExistsException"></exception>
        internal void L1addCmHLink(MKtaID targId)
        {
            //create hlink and add to list
            //throw exception if link already exists
            McmLink li = new McmLink(this.ID, targId);
            //call overloaded function
            L1addCmHLink(li);
            return;
        }
        /// <summary>
        /// NT-Create class-method halflink
        /// </summary>
        ///<param name="link">New link, add to list without copying</param>
        ///<exception cref="SeLinkAlreadyExistsException"></exception>
        internal void L1addCmHLink(McmLink link)
        {
            //throw exception if link already exists
            McmLink li = L1getCmLink(link.MethodID);
            if (li != null) throw new SeLinkAlreadyExistsException(link);
            //add link to list 
            else this.MethodLinkList.Add(link);
            return;
        }
        /// <summary>
        /// NT-Delete class-method halflink
        /// </summary>
        /// <param name="targId">Method id</param>
        /// <param name="checkExists">True - check existing and throw exception if not exists. False - skip checking</param>
        /// <exception cref="SeLinkNotFoundException"></exception>
        internal void L1deleteCmHLink(MKtaID targId, bool checkExists)
        {
            McmLink lin = L1getCmLink(targId);
            if (checkExists && (lin == null)) throw new SeLinkNotFoundException(); //"ClassMethod links not exists");
            //delete link
            if (lin != null) this.MethodLinkList.Remove(lin);
            return;
        }
        /// <summary>
        /// NT-Delete class-method halflink by method num
        /// </summary>
        /// <param name="metId">Method num</param>
        /// <param name="checkExists">True - check existing and throw exception if not exists. False - skip checking</param>
        /// <exception cref="SeLinkNotFoundException">ClassMethod links not exists</exception>
        internal void L1deleteCmHLinksByMethodId(uint metId, bool checkExists)
        {
            //delete all halflinks with matched method id - deletes all hlinks to any kta of method
            //get list of hlinks
            List<McmLink> lis = L1getCmLinksList(metId);
            //check exists
            if (checkExists && (lis.Count == 0)) throw new SeLinkNotFoundException(); //"ClassMethod links not exists");
            //delete links
            foreach (McmLink li in lis) this.MethodLinkList.Remove(li);
            return;
        }
        /// <summary>
        /// NT-Create default link between class and method
        /// </summary>
        /// <param name="targMet">Target method</param>
        /// <exception cref="SeLinkAlreadyExistsException">ClassMethod link already exists</exception>
        public void addClassMethodLink(MMethod targMet)
        {
            //check link exists
            if (this.L1checkCmLinkExists(targMet.ID)) throw new SeLinkAlreadyExistsException(); //"ClassMethod link already exists!");
            //add halflink class-method
            this.L1addCmHLink(new MKtaID(targMet.ID, 0));
            //add back halflink
            targMet.L1addCmHLink(this.ID);
            return;
        }
        /// <summary>
        /// NT-Delete all links between class and method
        /// </summary>
        /// <param name="targMet">Target method</param>
        /// <exception cref="SeLinkNotFoundException">ClassMethod links not exists</exception>
        public void deleteClassMethodLink(MMethod targMet)
        {
            //delete link to method with check link exists
            L1deleteCmHLinksByMethodId(targMet.ID, true);
            //delete back link
            targMet.L1deleteCmHLinksByClassId(this.ID, true);
        }
        /// <summary>
        /// NT-Get list of link to specified method
        /// </summary>
        /// <param name="methId">Method num</param>
        /// <returns>List of links</returns>
        internal List<McmLink> L1getCmLinksList(uint methId)
        {
            List<McmLink> lis = new List<McmLink>();
            //add links to specified method to list
            foreach (McmLink li in this.MethodLinkList)
            {
                if (li.MethodID.MethodID == methId) lis.Add(li);
            }
            //return list
            return lis;
        }
        /// <summary>
        /// NT-Return true if any links to specified method exists, false otherwise.
        /// </summary>
        /// <param name="methId">Method num</param>
        /// <returns>True or false</returns>
        internal bool L1checkCmLinkExists(uint methId)
        {
            foreach (McmLink li in this.MethodLinkList)
            {
                if (li.MethodID.MethodID == methId) return true;
            }
            return false;
        }
        /// <summary>
        /// NT-Get link to specified method and kta or null if link not exists
        /// </summary>
        /// <param name="ktaId">Method kta id</param>
        /// <returns>Link or null if link not exists</returns>
        internal McmLink L1getCmLink(MKtaID ktaId)
        {
            McmLink lin = null;
            foreach (McmLink li in this.MethodLinkList)
            {
                if (li.MethodID.isEqual(ktaId))
                {
                    lin = li;
                    break;
                }
            }
            return lin;
        }
        #endregion



    }
}
