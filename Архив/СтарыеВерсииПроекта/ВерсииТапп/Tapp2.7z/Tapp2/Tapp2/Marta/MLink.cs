﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;

namespace Marta
{
    /// <summary>
    /// Class represent link between classes or objects
    /// </summary>
    public class MLink
    {
        #region Fields
        /// <summary>
        /// Source ID
        /// </summary>
        private MID idFrom;
        /// <summary>
        /// Target ID
        /// </summary>
        private MID idTo;
        /// <summary>
        /// Link type 
        /// </summary>
        private MLinkType linkType;
        /// <summary>
        /// Reference to target object (for fast access to target)
        /// </summary>
        private MCell TargetObj;
        /// <summary>
        /// Link state
        /// </summary>
        private MLinkState linkState;
        #endregion
        /// <summary>
        /// Default constructor, used for XML
        /// </summary>
        public MLink()
        {
            idFrom = new MID();
            idTo = new MID();
            linkType = MLinkType.Normal;
            TargetObj = null;
            linkState = MLinkState.Active;
        }
        /// <summary>
        /// Parameter constructor
        /// </summary>
        /// <param name="objFrom">Source object</param>
        /// <param name="objTo">Target object</param>
        /// <param name="linktype">Link type</param>
        /// <param name="linkstate">Link state: Active or Deleted</param>
        /// <param name="objref">Reference to target or null</param>
        public MLink(MID objFrom, MID objTo, MLinkType linktype, MLinkState linkstate, MCell objref)
        {
            idFrom = new MID(objFrom);
            idTo = new MID(objTo);
            linkType = linktype;
            TargetObj = objref;
            linkState = linkstate;
        }
        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="copy">Link to copy</param>
        public MLink(MLink copy)
        {
            idFrom = new MID(copy.SrcObjectID);
            idTo = new MID(copy.DestObjectID);
            linkType = copy.eLinkType;
            linkState = copy.eLinkState;
            TargetObj = null;
        }
        #region Properties
        /// <summary>
        /// Source object ID
        /// </summary>
        [XmlIgnore]
        public MID SrcObjectID
        {
            get { return idFrom; }
            set { idFrom = value; }
        }
        /// <summary>
        /// Destination object ID
        /// </summary>
        [XmlIgnore]
        public MID DestObjectID
        {
            get { return idTo; }
            set { idTo = value; }
        }
        /// <summary>
        /// Link type: Normal, Restricted, Undefined
        /// </summary>
        [XmlIgnore]
        public MLinkType eLinkType
        {
            get { return linkType; }
            set { linkType = value; }
        }
        /// <summary>
        /// Link state: Active or Deleted
        /// </summary>
        /// <remarks>
        /// Active state means that link used for navigation.
        /// Deleted state means that link not valid and must be deleted by Optimizer service.
        /// </remarks>
        [XmlIgnore]
        public MLinkState eLinkState
        {
            get { return linkState; }
            set { linkState = value; }
        }
        /// <summary>
        /// Reference to target object or null
        /// </summary>
        /// <remarks>
        /// This reference not used in XML serialization. 
        /// This field is for fast access to linked target, but now typically null. 
        /// This field may be intensive be used in next versions of engine. </remarks>
        [XmlIgnore]
        public MCell TargetObject
        {
            get { return TargetObj; }
            set { TargetObj = value; }
        }

        /// <summary>
        /// String representation of link for XML serializing and best readability
        /// </summary>
        public String LinkAsText
        {
            get { return this.ToString(); }
            set { parseStrValue(value); }
        }
        #endregion

        /// <summary>
        /// Return string representation of link
        /// </summary>
        /// <returns>String representation of link</returns>
        public override string ToString()
        {
            return String.Format("{0} {1} {2} {3}", this.idFrom.ToString(), this.linkState.ToString(), this.linkType.ToString(), this.idTo.ToString()); 
        }

        /// <summary>
        /// NU-Create link to Unknown object from current link
        /// </summary>
        /// <returns>New link</returns>
        /// <remarks>Not used now</remarks>
        public MLink createUnknownTargetLink()
        {
            MLink li = new MLink();
            li.idFrom = new MID(idFrom); //main object
            li.idTo = idTo.getID_Unknown();//target object - "неизвестно"
            li.linkState = linkState;
            li.linkType = linkType;
            li.TargetObj = null;
            return li;
        }

        /// <summary>
        /// NU-Create link to Undefined object from current link
        /// </summary>
        /// <returns>New link</returns>
        public MLink createUndefinedTargetLink()
        {
            MLink li = new MLink();
            li.idFrom = new MID(idFrom); //main object
            li.idTo = idTo.getID_Undefined();//target object - "Undefined"
            li.linkState = linkState;
            li.linkType = linkType;
            li.TargetObj = null;
            return li;
        }

        /// <summary>
        /// Is Link's equals?
        /// </summary>
        /// <param name="link">Link to compare</param>
        /// <param name="withStateAndType">True - check ID and link state, false - check ID's only</param>
        /// <returns>True if link are equal, false otherwise</returns>
        internal bool isEqual(MLink link, bool withStateAndType)
        {
            bool res;
            res = ((this.idFrom.isEqual(link.idFrom)) && (this.idTo.isEqual(link.idTo)));
            if (withStateAndType == true) res = res && ((this.linkState == link.linkState) && (this.linkType == link.linkType));
            return res;
        }

        /// <summary>
        /// Predicate - Sorting links by LinkType
        /// </summary>
        /// <param name="x">X link</param>
        /// <param name="y">Y link</param>
        /// <returns>1, 0, -1</returns>
        /// <remarks>
        /// Used as sort predicate in List.Sort(). 
        /// Sorting order: Restricted, Normal, Undefined
        /// </remarks>
        public static int SortByLinkType(MLink x, MLink y)
        {
            if (x == null)
            {
                if (y == null) return 0; else return -1;
            }
            else
            {
                if (y == null) return 1;
                else
                {
                    if (x.eLinkType > y.eLinkType) return -1;
                    else if (x.eLinkType == y.eLinkType) return 0;
                    else return 1;
                }
            }
        }

        /// <summary>
        /// Parse string representation of link
        /// </summary>
        /// <remarks>Used for XML and debugger representation of link</remarks>
        /// <param name="str">String representation of link (For example: 256:0 Normal Semantic 258:0)</param>
        private void parseStrValue(String str)
        {
            //parse string    256:0 Normal Semantic 258:0
            String[] strs = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            this.SrcObjectID.IDstr = strs[0];
            this.eLinkState  = (MLinkState)TypeDescriptor.GetConverter(typeof(MLinkState)).ConvertFromString(strs[1]);
            this.eLinkType = (MLinkType)TypeDescriptor.GetConverter(typeof(MLinkType)).ConvertFromString(strs[2]);
            this.DestObjectID.IDstr = strs[3];
        }

        /// <summary>
        /// Return copy of current link
        /// </summary>
        /// <returns>Copy of current link</returns>
        public MLink getCopy()
        {
            return new MLink(this);
        }

        #region ** XML function ***
        /// <summary>
        /// NU-Save data to XML file
        /// </summary>
        /// <param name="filename">Name of XML file</param>
        public void SaveToXML(string filename)
        {
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            writer.Serialize(file, this);
            file.Close();
        }
        /// <summary>
        /// NU-Load data from XML file
        /// </summary>
        /// <param name="filename">name of XML file</param>
        public static MLink LoadFromXML(string filename)
        {
            MLink li = new MLink();
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(li.GetType());
            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            li = (MLink)reader.Deserialize(file);
            file.Close();
            return li;
        }
        #endregion
    }
}
