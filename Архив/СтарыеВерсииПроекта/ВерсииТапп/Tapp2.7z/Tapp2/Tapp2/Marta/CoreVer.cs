﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Marta
{
    /// <summary>
    /// Easy access to engine version
    /// </summary>
    public static class CoreVer
    {
        /// <summary>
        /// Engine version number
        /// </summary>
        /// <remarks>Means idea generation.</remarks>
        public static Int32 CoreVersion
        {
            get { return 2; }
        }
        /// <summary>
        /// Engine subversion number
        /// </summary>
        /// <remarks>
        /// Means xml base format changes.
        /// Look version history for details.
        /// </remarks>
        public static Int32 CoreSubVersion
        {
            get { return 1; }//look version history for details
        }
        /// <summary>
        /// Description of current version 
        /// </summary>
        /// <remarks>Here can be listed changes and newly added something</remarks>
        public static String DescriptionVer
        {
            //TODO: Add specific description and constraints here
            get { return "See Version.txt for full description"; }
        }

        #region Assembly Attribute Accessors
        /// <summary>
        /// Engine assembly Title
        /// </summary>
        public static string AssemblyTitle
        {
            get
            {
                return "Semantic platform project core engine";
            }
        }
        /// <summary>
        /// Engine assembly Version
        /// </summary>
        public static string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }
        /// <summary>
        /// Engine assembly Description
        /// </summary>
        public static string AssemblyDescription
        {
            get
            {
                return "Semantic Platform Project core engine library";
            }
        }
        /// <summary>
        /// Engine assembly Product name
        /// </summary>
        public static string AssemblyProduct
        {
            get
            {
                return "Semantic Platform Project";
            }
        }
        /// <summary>
        /// Engine assembly Copyright
        /// </summary>
        public static string AssemblyCopyright
        {
            get
            {
                return "Copyright (C) 2011 Pavel Selyakov"; 
            }
        }
        /// <summary>
        /// Engine assembly Company
        /// </summary>
        public static string AssemblyCompany
        {
            get
            {
                return "Pavel Selyakov";
            }
        }
        #endregion
    }
}
