﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;


namespace Marta
{
    /// <summary>
    /// Class represent semantic data ID
    /// </summary>
    /// <remarks>
    /// Semantic id represent by two parts: class id and object id.
    /// Classes and objects from 0 to 255 form System space, all other form User Space.
    /// Classes and objects from System space is defined by system architecture and cannot be changed or deleted.
    /// </remarks>
    public class MID
    {
        /// <summary>
        /// Id of class
        /// </summary>
        private uint classId;
        /// <summary>
        /// Id of object
        /// </summary>
        private uint objId;
        /// <summary>
        /// Default constructor used by XML
        /// </summary>
        public MID()
        {
            classId = 0;
            objId = 0;
        }
        /// <summary>
        /// Parameter constructor
        /// </summary>
        /// <param name="cId">Class id number</param>
        /// <param name="oId">Object id number</param>
        public MID(uint cId, uint oId)
        {
            classId = cId;
            objId = oId;
        }
        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="copy">ID for copying</param>
        public MID(MID copy)
        {
            classId = copy.ClassID;
            objId = copy.ObjID;
        }        
        /// <summary>
        /// Class ID of current object
        /// </summary>
        [XmlIgnore]
        public uint ClassID
        {
            get { return classId; }
            set { classId = value;}
        }

        /// <summary>
        /// Object ID of current object
        /// </summary>
        [XmlIgnore]
        public uint ObjID
        {
            get { return objId; }
            set { objId = value;}
        }

        /// <summary>
        /// Current ID is Class?
        /// </summary>
        /// <remarks>Read-Only. If current id is Class, this property return True. Otherwise return False.</remarks>
        [XmlIgnore]
        public bool IsMainObject
        {
            get { return (this.objId == (uint)SystemObjectNames.Main); }
        }

        /// <summary>
        /// Current ID is Unknown object?
        /// </summary>
        /// <remarks>Read-Only. If current id is system object Unknown, this property return True. Otherwise return False.</remarks>
        [XmlIgnore]
        public bool IsUnknownObject
        {
            get { return (this.objId == (uint)SystemObjectNames.Unknown); }
        }

        /// <summary>
        /// Current ID is Undefined object?
        /// </summary>
        /// <remarks>Read-Only. If current id is system object Undefined, this property return True. Otherwise return False.</remarks>
        [XmlIgnore]
        public bool IsUndefinedObject
        {
            get { return (this.objId == (uint)SystemObjectNames.Undefined); }
        }

        /// <summary>
        /// Current ID is World class?
        /// </summary>
        /// <remarks>Read-Only. If current id is system class World, this property return True. Otherwise return False.</remarks>
        [XmlIgnore]
        public bool IsWorldClass
        {
            get { return (this.classId == (uint)SystemClassNames.World); }
        }

        ///// <summary>
        ///// Get default class icon ID - Not used, for debug only
        ///// </summary>
        //[XmlIgnore]
        //public static MID DefaultIconId
        //{
        //    get { return new MID(0, 0); }
        //}

        /// <summary>
        /// Get Unused ID - if you need specify ID, which is not match any semantic type. ID(255:255)
        /// </summary>
        [XmlIgnore]
        public static MID UnusedId
        {
            get { return new MID((uint)SystemClassNames.Unused, (uint)SystemObjectNames.Unused); } 
        }

        /// <summary>
        /// Get or set string representation of ID
        /// </summary>
        /// <remarks>
        /// This property used for debugging and XML de/serializing to present id as class:object.
        /// For example: 255:255
        /// </remarks>
        public string IDstr
        {
            get
            {
                return this.ToString();
            }
            set
            {
                string[] sar = value.Split(new char[] {':'}, StringSplitOptions.RemoveEmptyEntries);
                classId = UInt32.Parse(sar[0]);
                objId = UInt32.Parse(sar[1]);
            }
        }
        /// <summary>
        /// Detect User space of object ID (ID bigger than 255)
        /// </summary>
        [XmlIgnore]
        public Boolean isUserObject
        {
            get { return (this.objId > 255); }
        }
        /// <summary>
        /// Detect User space of class ID (ID bigger than 255)
        /// </summary>
        [XmlIgnore]
        public Boolean isUserClass
        {
            get { return (this.classId > 255); }
        }

        /// <summary>
        /// 170511 NT Detect User space of class and object ID (ID bigger than 255).
        /// Return true if ID is user class or user object of user class.
        /// </summary>
        [XmlIgnore]
        public Boolean isUserClassOrObject
        {
            get { return ((this.classId > 255) && ((this.objId == 0) || (this.objId > 255))); }
        }
        /// <summary>
        /// Return string representation of ID
        /// </summary>
        /// <returns>ID in format 255:255</returns>
        public override string ToString()
        {
            return String.Format("{0}:{1}", classId, objId);
        }
        /// <summary>
        /// Is equal ID's?
        /// </summary>
        /// <param name="id">Compared ID</param>
        /// <returns>True if ID's full equal, false otherwise</returns>
        public bool isEqual(MID id)
        {
            return ((this.objId == id.objId) && (this.classId == id.classId));
        }

        /// <summary>
        /// Get ID Unknown obj as copy of current ID
        /// </summary>
        /// <returns>Return copy of ID of Unknown object of specified class.</returns>
        public MID getID_Unknown()
        {
            return new MID(this.classId, (uint) SystemObjectNames.Unknown );
        }
        /// <summary>
        /// Get ID Undefined obj as copy of current ID
        /// </summary>
        /// <returns>Return copy of ID of Undefined object of specified class</returns>
        public MID getID_Undefined()
        {
            return new MID(this.classId, (uint) SystemObjectNames.Undefined );
        }
        /// <summary>
        /// Get ID Nothing obj as copy of current ID
        /// </summary>
        /// <returns>Return copy of ID of Nothing object of specified class</returns>
        public MID getID_Nothing()
        {
            return new MID(this.classId, (uint) SystemObjectNames.Nothing );
        }

        /// <summary>
        /// Get ID of class as copy of current ID
        /// </summary>
        /// <returns>Return copy of ID of specified class</returns>
        public MID getID_Main()
        {
            return new MID(this.classId, (uint)SystemObjectNames.Main);
        }

        /// <summary>
        /// If current ID represent a class, throw exception
        /// </summary>
        /// <remarks>Perform simple checking for all operations with objects where ID must be used as argument</remarks>
        /// <exception cref="SeInvalidUseClassException"> Thrown if ID is semantic class.</exception>
        public void IsMainObjectThrowException()
        {
            if (this.objId == (uint)SystemObjectNames.Main) throw new SeInvalidUseClassException(this);
        }
        /// <summary>
        /// Get World class ID
        /// </summary>
        /// <returns>Return new copy of ID of system class World</returns>
        public static MID GetWorldClassID()
        {
            return new MID((uint)SystemClassNames.World,  (uint)SystemObjectNames.Main);
        }
        /// <summary>
        /// Get Unknown class ID
        /// </summary>
        /// <returns>Return new copy of ID of system class Unknown</returns>
        public static MID GetUnknownClassID()
        {
            return new MID((uint)SystemClassNames.Unknown, (uint)SystemObjectNames.Main);
        }
        /// <summary>
        /// get Undefined class ID
        /// </summary>
        /// <returns>Return new copy of ID of system class Undefined</returns>
        public static MID GetUndefinedClassID()
        {
            return new MID((uint)SystemClassNames.Undefined, (uint)SystemObjectNames.Main);
        }
        /// <summary>
        /// get Nothing class ID
        /// </summary>
        /// <returns>Return new copy of ID of system class Nothing</returns>
        public static MID GetNothingClassID()
        {
            return new MID((uint)SystemClassNames.Nothing, (uint)SystemObjectNames.Main);
        }
        /// <summary>
        /// Get copy of current ID
        /// </summary>
        /// <returns>Copy of current ID.</returns>
        /// <remarks>Because C#-class is reference type, you must create local copy of ID when assign ID to any other entities.</remarks>
        public MID getCopy()
        {
            return new MID(this.classId, this.objId);
        }
    }
}
