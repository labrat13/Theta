﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using Marta.Methods;
using System.Reflection;
using System.Windows.Forms;


namespace Marta
{
    /// <summary>
    /// Class represent container for all database entities
    /// </summary>
    public class MEngine
    {
        #region Fields
        /// <summary>
        /// Base version (also XML format version)
        /// </summary>
        /// <remarks>This value not correspond to engine version or subversion.</remarks>
        private int m_version;
        /// <summary>
        /// Base step (data content version)
        /// </summary>
        /// <remarks>Initially zero, increment after every snapshot saving</remarks>
        private int m_step;
        /// <summary>
        /// Data file path
        /// </summary>
        private string m_filePath;
        /// <summary>
        /// Description text
        /// </summary>
        /// <remarks>Store database description here.</remarks>
        private String m_descr;
        /// <summary>
        /// Creation time
        /// </summary>
        /// <remarks>Timestamp of database creation.</remarks>
        private DateTime m_creaTime;
        /// <summary>
        /// List of classes
        /// </summary>
        private List<MClass> m_classList;
        /// <summary>
        /// Log file path
        /// </summary>
        private System.IO.StreamWriter m_logPath;
        /// <summary>
        /// List of methods
        /// </summary>
        private List<Methods.MMethod> m_methodList;
#endregion

        /// <summary>
        /// Default constructor used by XML serializing. Do not use this constructor!
        /// </summary>
        public MEngine()
        {
            m_classList = new List<MClass>();
            m_methodList = new List<Marta.Methods.MMethod>(); //List of methods
            m_creaTime = DateTime.Now;
            m_step = 0;
            m_version = CoreVer.CoreVersion;
            m_descr = String.Format("Tapp database file, ver {0}, step {1}", m_version, m_step); //base description
            m_filePath = "";
            openLog(); //open log file
        }

        /// <summary>
        /// Creates new container with predefined classes and objects
        /// </summary>
        /// <param name="initialStep">Initial base step value. 0 for first use</param>
        public MEngine(int initialStep)
        {
            m_classList = new List<MClass>();
            m_methodList = new List<Marta.Methods.MMethod>(); //List of methods
            m_creaTime = DateTime.Now;
            m_step = initialStep;
            m_version = CoreVer.CoreVersion;
            m_descr = String.Format("Tapp database file, ver {0}, step {1}", m_version, m_step); //base description
            m_filePath = "";
            openLog(); //open log file
            //create system classes with objects here
            MClass cls = new MClass((uint)SystemClassNames.World, "WORLD", typeof(Object), "Main system class");
            this.Classes.Add(cls);
            cls = new MClass((uint)SystemClassNames.Unknown, "UNKNOWN", typeof(Object), "System class Unknown");
            this.Classes.Add(cls);
            cls = new MClass((uint)SystemClassNames.Undefined, "UNDEFINED", typeof(Object), "System class Undefined");
            this.Classes.Add(cls);
            cls = new MClass((uint)SystemClassNames.Nothing, "NOTHING", typeof(Object), "System class Nothing");
            this.Classes.Add(cls);
            //set backrefs cascade
            SetBackRefs();
        }
        /// <summary>
        /// Set all classes's and it's objects backref to current container
        /// </summary>
        /// <remarks>Internal use only.</remarks>
        private void SetBackRefs()
        {
            foreach (MClass m in m_classList)
            {
                m.intSetBackRefs(this);
            }
        }



        /// <summary>
        /// Destructor
        /// </summary>
        ~MEngine()
        {
            closeLog();
        }

        #region Properties
        /// <summary>
        /// Description text
        /// </summary>
        /// <remarks>Short database description.</remarks>
        public String Description
        {
            get
            {
                return m_descr;
            }
            set
            {
                m_descr = value;
            }
        }

        /// <summary>
        /// Base version (also XML format version)
        /// </summary>
        /// <remarks>This value not correspond to engine version or subversion.</remarks>
        public int Version
        {
            get
            {
                return m_version;
            }
            set
            {
                m_version = value;
            }
        }

        /// <summary>
        /// Base step (data content version)
        /// </summary>
        /// <remarks>Initially zero, increment after every snapshot saving</remarks>
        public int Step
        {
            get
            {
                return m_step;
            }
            set
            {
                m_step = value;
            }
        }

        /// <summary>
        /// Creation time
        /// </summary>
        /// <remarks>Timestamp of database creation.</remarks>
        public DateTime CreationTime
        {
            get
            {
                return m_creaTime;
            }
            set
            {
                m_creaTime = value;
            }
        }

        /// <summary>
        /// List of classes
        /// </summary>
        public List<MClass> Classes
        {
            get
            {
                return m_classList;
            }
        }
        /// <summary>
        /// List of methods
        /// </summary>
        public List<Marta.Methods.MMethod> Methods
        {
            get
            {
                return m_methodList;
            }
        }

        #endregion

        /// <summary>
        /// Return string representation of object - RE
        /// </summary>
        /// <returns>String format: Engine: [num of cells]</returns>
        /// <remarks>For debugger and user views</remarks>
        public override string ToString()
        {
            return "Engine: " + this.m_classList.Count.ToString();
        }

        #region Class functions
        /// <summary>
        /// NT-get free classID for new class
        /// </summary>
        /// <returns>Free classID for new class</returns>
        /// <remarks>Calculate as max from class ID's + 1, but more than 255</remarks>
        private uint getFreeClassId()
        {
            uint max = 0;
            uint tmp = 0;
            //get max of classID
            foreach(MClass cla in this.Classes)
            {
                tmp = cla.ID.ClassID;
                if (tmp > max) max = tmp;
            }
            //if max not in user space, change it
            if (max < 255) max = 255;
            //return next number
            max++;
            return max;
        }
        /// <summary>
        /// NR-Create new class in User class space (ID > 255). Do not use for System space classes.
        /// </summary>
        /// <returns>created class</returns>
        /// <param name="clsName">Class name string</param>
        /// <param name="dataType">Class data type</param>
        /// <param name="comment">Class comment</param>
        public MClass createClass(string clsName, Type dataType, string comment)
        {
            //create class
            MClass cls = new MClass(getFreeClassId(), clsName, dataType, comment);
            //add back reference of classset
            cls.intSetBackRefs(this);
            //add class to classes list
            this.Classes.Add(cls);
            //add links to World class
            // to MID.GetWorldClassID();
            //cls.createUpLink(this.getClass((uint)SystemClassNames.World)); function not realized
            return cls;
        }
        /// <summary>
        /// NT-Get class by class num
        /// throw SeObjectNotFoundException if class not found or has been deleted
        /// </summary>
        /// <param name="classId">Class num</param>
        /// <returns>Specified class. Throw SeObjectNotFoundException if class not found or has ObjState.Deleted state.</returns>
        /// <exception cref="SeObjectNotFoundException">Class not found</exception>
        public MClass getClass(uint classId)
        {
            //get class from classes list
            MClass cls = intGetClass(classId);
            //return class
            if ((cls == null) || (cls.State == MCellState.Deleted)) throw new SeObjectNotFoundException(classId);
            else return cls;
        }
        /// <summary>
        /// NT-Get class from classes list. Return class or null if class not found
        /// </summary>
        /// <param name="clsId">Class num</param>
        /// <returns>Class or null if class not found.</returns>
        internal MClass intGetClass(uint clsId)
        {
            //get class from classes list
            MClass cls = null;
            foreach (MClass cl in this.Classes)
            {
                if (cl.ID.ClassID == clsId)
                {
                    cls = cl;
                    break;
                }
            }
            return cls;            //return class
        }

        /// <summary>
        /// NT-Delete class or mark as deleted
        /// </summary>
        /// <param name="classId">Class num</param>
        /// <param name="markOnly">True - mark as deleted, False - remove object</param>
        /// <exception cref="SeObjectNotFoundException">Class not found</exception>
        /// <exception cref="SeInvalidUseSystemObjectException">System class cannot be deleted!</exception>
        public void deleteClass(uint classId, bool markOnly)
        {
            MClass cl = this.getClass(classId);
            cl.Delete(markOnly);
        }

        /// <summary>
        /// NT-get object by ID
        /// throw SeObjectNotFoundException if object not found or has been deleted
        /// </summary>
        /// <param name="objId">Object ID</param>
        /// <returns>Object or throw SeObjectNotFoundException if object not exists</returns>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        public MObj getObject(MID objId)
        {
            //get class
            MClass cls = getClass(objId.ClassID);
            //get object
            return cls.GetObject(objId);
        }

        /// <summary>
        /// 170611 NT-Get MCell by it's ID. For type-independent code only
        /// </summary>
        /// <param name="cellId">Cell ID</param>
        /// <returns>MCell class or object</returns>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        public MCell getCell(MID cellId)
        {
            MClass cls = getClass(cellId.ClassID);
            if (cellId.IsMainObject) return (MCell)cls;
            else return (MCell)cls.GetObject(cellId);
        }

        /// <summary>
        /// 180511 Clear search flag for all classes
        /// </summary>
        /// <param name="withObjects">True - for all objects of classes, False - for classes only</param>
        internal void clearSearchFlagClasses(bool withObjects)
        {
            foreach (MClass c in this.Classes)
            {
                c.SearchFlag = 0;//clear search flag for class
                if (withObjects) c.clearSearchFlagObjs(); //clear search flar for all objects
            }
        }
        /// <summary>
        /// 180511 Clear search flag for all methods
        /// </summary>
        internal void clearSearchFlagMethods()
        {
            foreach (MMethod m in this.Methods)
                m.SearchFlag = 0;
        }

        #endregion

        #region Log functions
        /// <summary>
        /// Open log file and write startup message
        /// </summary>
        private void openLog()
        {
            DateTime d = DateTime.Now;
            String fname = String.Format("MartaLog_{0}.txt", d.ToString("ddMMyy_HHmmss_FFFFFFF", CultureInfo.InvariantCulture));
            m_logPath = new System.IO.StreamWriter(fname, true, Encoding.Unicode);
            m_logPath.AutoFlush = true; //autoflush content after every Write 
            addLogMsg(0, String.Format("Database start: {0} {1}", m_descr, m_filePath));
        }

        /// <summary>
        /// Add message to log
        /// </summary>
        /// <param name="code">Message code</param>
        /// <param name="msg">Message text</param>
        /// <remarks>Message code system not assigned now.</remarks>
        public void addLogMsg(int code, String msg)
        {
            m_logPath.WriteLine(String.Format("{0} {1} {2}", DateTime.Now, code, msg));
        }

        /// <summary>
        /// Close log file
        /// </summary>
        private void closeLog()
        {
            addLogMsg(1, "Database closed");
            m_logPath.Close();
            m_logPath = null;
        }
        #endregion

        #region XML functions
        /// <summary>
        /// Save data to XML file - old, for code and test use only
        /// </summary>
        /// <param name="filename">Name of XML file</param>
        public void SaveToXML(string filename)
        {
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            writer.Serialize(file, this);
            file.Close();
            file.Dispose();
        }

        /// <summary>
        /// Load data from XML file - old, for code and test use only
        /// </summary>
        /// <param name="filename">Name of XML file</param>
        public static MEngine LoadFromXML(string filename)
        {
            MEngine li;
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(Type.GetType("Marta.MEngine"));
            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            li = (MEngine)reader.Deserialize(file);
            file.Close();
            //patch to right base object references structure
            li.SetBackRefs();
            return li;
        }
        /// <summary>
        /// Load database from stepped database file pathname
        /// </summary>
        /// <param name="pathname">Stepped database file pathname</param>
        /// <returns>Database object</returns>
        public static MEngine LoadBaseStep(string pathname)
        {
            //refine database name from step number
            //example:  c:\dir\dbfile.8.xml   - dbfile.xml step 8
            String newPath = removeStepPath(pathname);
            MEngine cs = MEngine.LoadFromXML(pathname);
            cs.m_filePath = newPath;
            return cs;
        }

        /// <summary>
        /// Save base as snapshot (base step) 
        /// </summary>
        /// <param name="pathname">Pathname for new database file. If pathname = null, use pathname stored by database loading</param>
        public void SaveBaseStep(string pathname)
        {
            //get and check pathname
            if (String.IsNullOrEmpty(pathname)) pathname = this.m_filePath;
            //save base
            this.m_step++;
            this.m_creaTime = DateTime.Now;
            String stepPath = addStepPath(pathname);
            SaveToXML(stepPath);
        }
        /// <summary>
        /// Add base step number to file pathname 
        /// </summary>
        /// <param name="path">Path for modifying</param>
        /// <returns>Modified path</returns>
        private string addStepPath(string path)
        {
            //TODO: change filename - add step number to end
            //if filename already has step number, remove it.
            string ext = System.IO.Path.GetExtension(path);
            string dir = System.IO.Path.GetDirectoryName(path);
            string nt = System.IO.Path.GetFileNameWithoutExtension(path);//remove first extension
            string name = System.IO.Path.GetFileNameWithoutExtension(nt);//remove second extension

            path = String.Format("{0}{1}{2}.{3}{4}", dir, System.IO.Path.DirectorySeparatorChar, name, m_step, ext);
            //now return path without any modification
            return path;
        }

        /// <summary>
        /// Delete base step number from file pathname
        /// </summary>
        /// <param name="path">Path for modifying</param>
        /// <returns>Modified path</returns>
        private static string removeStepPath(string path)
        {
            //TODO: change filename - delete step number from end
            string ext = System.IO.Path.GetExtension(path);
            string dir = System.IO.Path.GetDirectoryName(path);
            string nt = System.IO.Path.GetFileNameWithoutExtension(path);//remove first extension
            string name = System.IO.Path.GetFileNameWithoutExtension(nt);//remove second extension
            nt = System.IO.Path.ChangeExtension(name, ext);//insert first extension
            path = String.Format("{0}{1}{2}", dir, System.IO.Path.DirectorySeparatorChar, nt);
            //now return path without any modification
            return path;
        }

        #endregion


        #region Methods

        /// <summary>
        /// NT-Return array of methods linked to specified class, with specified name. Link from method used.
        /// </summary>
        /// <param name="clsId">id of class linked to methods</param>
        /// <param name="name">Method name</param>
        /// <returns>Returns list of methods linked to class</returns>
        internal List<MMethod> intGetClassLinkedMethodsByName(uint clsId, string name)
        {
            List<MMethod> lm = new List<MMethod>(); 
            //iterate Methods list, check name and check linked class
            foreach(MMethod mm in this.m_methodList)
                if (mm.Name.Equals(name, StringComparison.Ordinal)) //check method name
                {
                    foreach (McmLink cl in mm.classList)            //check class id
                        if (cl.ClassID.ClassID == clsId) lm.Add(mm);  
                }
            //return list
            return lm;
        }

        /// <summary>
        /// NT-Get list of methods with specified name from container
        /// </summary>
        /// <param name="name">Method name</param>
        /// <returns>Returns list of methods</returns>
        internal List<MMethod> intGetMethodsByName(string name)
        {
            List<MMethod> lm = new List<MMethod>();
            //iterate Methods list, check name and check linked class
            foreach (MMethod mm in this.m_methodList)
                if (mm.Name.Equals(name, StringComparison.Ordinal)) //check method name
                      lm.Add(mm);
            //return list
            return lm;
        }

        /// <summary>
        /// Get method by num. Return method or null if method not exists
        /// </summary>
        /// <param name="methodNum">Method number</param>
        /// <returns>Return method object or null</returns>
        internal Methods.MMethod intGetMethod(uint methodNum)
        {
            MMethod res = null;
            foreach(MMethod mm in this.m_methodList)
                if (mm.ID == methodNum) 
                {
                    res = mm;
                    break;
                }
            //return method or null
            return res;
        }

        /// <summary>
        /// Get method by num. Return method or throw SeMethodNotFound exception if method not found.
        /// </summary>
        /// <param name="methodNum">Method number</param>
        /// <returns>Return method object</returns>
        /// <exception cref="SeMethodNotFoundException">Method not found</exception>
        public MMethod getMethod(uint methodNum)
        {
            MMethod res = intGetMethod(methodNum);
            if (res == null) throw new SeMethodNotFoundException(methodNum);
            else return res;
        }

        /// <summary>
        /// Get free method number for new user method
        /// </summary>
        /// <returns>Returns free method number</returns>
        /// <remarks>New number calculate as (max from existing methods) + 1, but more than 255</remarks>
        private uint getFreeMethodId()
        {
            uint n = 0;
            foreach (MMethod m in this.m_methodList)
                if (m.ID > n) n = m.ID;
            //user space for methods start from 256
            if (n < 255) n = 255; 
            return n + 1;
        }

        /// <summary>
        /// NR-Create method and add to method list.
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="descr">Method description</param>
        /// <returns>Created method</returns>
        /// <remarks>Need refactoring.</remarks>
        public MMethod createMethod(string name, string descr)
        {
            MMethod mm = new MMethod(getFreeMethodId(), name, descr);
            //TODO: add initialization here...
            
            m_methodList.Add(mm);//add to method list
            return mm;
        }

        /// <summary>
        /// NR-Create method and add to method list.
        /// </summary>
        /// <param name="name">Method name</param>
        /// <param name="descr">Method description</param>
        /// <param name="kta0">Kta filled with arguments and return values, for use as kta0 in method</param>
        /// <param name="codePath">Path for method implementation code: myAssembly.myClass.myFunction</param>
        /// <returns>Created method</returns>
        /// <remarks>
        /// Create method with filled kta0 and codepath.
        /// codePath must be composited as A.C.F
        /// Assembly (XYZ.dll File name without extension. .dll will be added automatically before call).
        /// Class (Must be public static, with SeImplementAttribute)
        /// Function (Must be public static, with SeImplementAttribute)
        /// See example (if found)
        ///</remarks>
        public MMethod createMethod(string name, string descr, string codePath,MKTA kta0)
        {
            MMethod mm = new MMethod(getFreeMethodId(), name, descr, kta0);
            mm.CodePath = codePath;
            
            m_methodList.Add(mm);//add to method list
            return mm;
        }
        #endregion


        /// <summary>
        /// Fill list of cell MLink links with class or objects references. Use container, slow.
        /// </summary>
        /// <remarks>Internal use only</remarks>
        /// <param name="links">List of links to fill</param>
        /// <exception cref="SeObjectNotFoundException">Class or object not found</exception>
        /// <exception cref="SeArgumentException">Invalid ClassID of object</exception>
        /// <exception cref="SeInvalidUseClassException">ID is class</exception>
        internal void intFillLinksRef(List<MLink> links)
        {
            foreach (MLink li in links)
                li.TargetObject = this.getCell(li.DestObjectID);
        }




    }
}
