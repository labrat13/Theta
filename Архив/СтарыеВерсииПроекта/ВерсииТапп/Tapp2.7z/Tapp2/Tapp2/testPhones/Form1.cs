﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace testPhones
{
    /// <summary>
    /// PhoneBase test application 
    /// </summary>
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Open XML file and create phone base
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Open existing database for any work
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openBaseToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Close any open database and exit app
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }



    }
}