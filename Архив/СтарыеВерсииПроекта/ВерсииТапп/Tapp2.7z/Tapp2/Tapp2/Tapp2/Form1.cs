﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Marta;
using Marta.Methods;

namespace Tapp2
{
    public partial class Form1 : Form
    {
        //public MEngine me;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //create engine
            Marta.MEngine me = new Marta.MEngine(777);
            /*
            //create user classes and objects
            MClass c1 = me.createClass("c1", typeof(String), "");
            MClass c2 = me.createClass("c2", typeof(String), "");
            MClass c3 = me.createClass("c3", typeof(String), "");
            MClass c4 = me.createClass("c4", typeof(String), "");
            MClass c5 = me.createClass("c5", typeof(String), "");
            MClass c6 = me.createClass("c6", typeof(String), "");
            MClass c7 = me.createClass("c7", typeof(String), "");
            MClass c8 = me.createClass("c8", typeof(String), "");
            //create objects
            MObj b1 = c1.createObject("b1", "", "");
            MObj b2 = c2.createObject("b2", "", "");
            MObj b3 = c3.createObject("b3", "", "");
            MObj b4 = c4.createObject("b4", "", "");
            MObj b5 = c5.createObject("b5", "", "");
            MObj b6 = c6.createObject("b6", "", "");
            MObj b7 = c7.createObject("b7", "", "");
            MObj b8 = c8.createObject("b8", "", "");
            //create link between classes
            //c1-c4 x down
            c1.createLink(Axiss.Xdown, c2, MLinkType.Normal);
            c2.createLink(Axiss.Xdown, c3, MLinkType.Normal);
            c3.createLink(Axiss.Xdown, c4, MLinkType.Normal);
            //c5-c8 y down
            c5.createLink(Axiss.Ydown, c6, MLinkType.Normal);
            c6.createLink(Axiss.Ydown, c7, MLinkType.Normal);
            c7.createLink(Axiss.Ydown, c8, MLinkType.Normal);
            //c1-c5, c2-c6, c3-c7, c4-c8 z down
            c1.createLink(Axiss.Zdown, c5, MLinkType.Normal);
            c2.createLink(Axiss.Zdown, c6, MLinkType.Normal);            
            c3.createLink(Axiss.Zdown, c7, MLinkType.Normal);
            c4.createLink(Axiss.Zdown, c8, MLinkType.Normal);  

            //world link creation
            c1.deleteLink(Axiss.Xdown, c2);

            //save to xml file
            me.SaveToXML("test.xml");


            //delete link between object

            //delete link between classes

            //delete object

            //delete class
            */
            
             
            //Methods test 030511
            //create methods
            MMethod m = me.createMethod("testMethod1", "new method");
            //m.setCodePath("Codes", "Example");//set code path - for not exists function only
            m.CodePath = "Codes.Example.testMethod1";
            //add arguments
            m.KTA_0.Result.argType = typeof(int);
            m.KTA_0.Result.ClassId = MID.UnusedId;
            m.KTA_0.Result.Name = "Result";
            m.KTA_0.Result.Value = 0;
            //m.KTA_0.argList.Add(new MArg("Kta", "Arguments", new MKTA())); //add kta as argument
            //вариант с передачей кта не проработан - как обозначать, что в метод нужно передавать кта целиком?.
            //Никак. Если код метода третьим параметром принимает кта, то передавать ему весь кта.
            //В самом кта просто перечисляются аргументы в любом количестве   
            MMethod mm = me.createMethod("testMethod2", "description");
            mm.CodePath = "Codes.Example.testMethod2";
            //add arguments
            mm.KTA_0.Result.argType = typeof(uint);
            mm.KTA_0.Result.ClassId = MID.UnusedId;
            mm.KTA_0.Result.Name = "Result";
            mm.KTA_0.Result.Value = 0;
            mm.KTA_0.argList.Add(new MArg("arg1", "value A", typeof(uint), (uint)1024, MID.UnusedId));
            mm.KTA_0.argList.Add(new MArg("arg2", "value B", typeof(uint), (uint)56, MID.UnusedId));

            MMethod mmm = me.createMethod("testMethod3", "new method");
            //m.setCodePath("Codes", "Example");//set code path - for not exists function only
            mmm.CodePath = "Codes.Example.testMethod3";
            //add arguments
            mmm.KTA_0.Result.argType = typeof(uint);
            mmm.KTA_0.Result.ClassId = MID.UnusedId;
            mmm.KTA_0.Result.Name = "Result";
            mmm.KTA_0.Result.Value = 0;

            //run methods by number
            Object res = me.getClass(0).ExecuteMethod(m.ID, new MIDType(typeof(int)), false, null); //func with mkta args
            Object resa = me.getClass(0).ExecuteMethod(mm.ID, new MIDType(typeof(uint)), false, new Object[] { (uint)5, (uint)10 });//5+10 func with separated args
            // throw exception because function return int, but method send uint type
            //Object resb = me.getClass(0).ExecuteMethod(mmm.ID, new MIDType(typeof(uint)), new Object[0], false);//func without args -
            //run methods by name
            Object nres = me.getClass(0).ExecuteMethod(m.Name, new MIDType(typeof(int)),false,  null); //func with mkta args
            Object nresa = me.getClass(0).ExecuteMethod(mm.Name, new MIDType(typeof(uint)), false, new Object[] { (uint)5, (uint)10 });//5+10 func with separated args
            // throw exception because function return int, but method send uint type
            //Object nresb = me.getClass(0).ExecuteMethod(mmm.Name, new MIDType(typeof(uint)), false, new Object[0]);//func without args -
            
            //Run method directly (fast but not safer)
            Object r = m.ExecuteSimple(me, me.getClass(0), null); //no arguments in this method

            //Create and run test method in other way
            //For best example get method with two arguments and visible works
            ////[SeImplement(ImplementationState.NotTested)]
            ////public static uint testMethod2(MEngine me, MCell caller, uint arg1, uint arg2)
            ////{
            ////    return arg1 + arg2;
            ////}
            //create kta for arguments
            MKTA kta = new MKTA(0, 0);
            //fill result and args
            kta.Result = new MArg("Result", "Description", typeof(uint), null);
            kta.argList.Add(new MArg("Arg0", "argument0", typeof(uint), null));
            kta.argList.Add(new MArg("Arg1", "argument1", typeof(uint), null));
            MMethod n = me.createMethod("testMethod2", "method description", "Codes.Example.testMethod2", kta);
            //run method
            uint t = (uint) me.getClass(0).ExecuteMethod(n.ID, new MIDType(typeof(uint)), false, (uint)10, (uint)99);
            MessageBox.Show("ExecuteMethod returns: " + t.ToString());
            //link two methods
            //mutual links check not performed?
            //m.createLink(Axiss.Ydown, mm);
            //delete link
            //m.deleteLink(Axiss.Ydown, mm);
            //create class
            //MClass c = me.createClass("tmp", typeof(String), "comment");
            //link class and method
            //c.addClassMethodLink(m); //link from class
            //mm.addClassMethodLink(c); //link from method not ready
            //delete cm link
            //c.deleteClassMethodLink(mm); //need test deleting from method too!
            


            /*
            //Test hierarchy walker
            MClass c1 = me.createClass("c1", typeof(String), "");
            MClass c2 = me.createClass("c2", typeof(String), "");
            MClass c3 = me.createClass("c3", typeof(String), "");
            MClass c4 = me.createClass("c4", typeof(String), "");
            MClass c5 = me.createClass("c5", typeof(String), "");
            MClass c6 = me.createClass("c6", typeof(String), "");
            MClass c7 = me.createClass("c7", typeof(String), "");
            MClass c8 = me.createClass("c8", typeof(String), "");
            //create hierarchy
            c1.createLink(Axiss.Ydown, c2, MLinkType.Normal);
            c1.createLink(Axiss.Ydown, c3, MLinkType.Normal);
            c2.createLink(Axiss.Ydown, c4, MLinkType.Normal);
            c2.createLink(Axiss.Ydown, c5, MLinkType.Normal);
            c3.createLink(Axiss.Ydown, c6, MLinkType.Normal);
            c3.createLink(Axiss.Ydown, c7, MLinkType.Normal);
            c5.createLink(Axiss.Ydown, c8, MLinkType.Normal);
            c3.createLink(Axiss.Ydown, c5, MLinkType.Normal);
            //walker
            MCell.intGetCellsHierarhyLevel(Axiss.Ydown, c1, c8, 3); 
            MCell.intGetCellsHierarhyLevel(Axiss.Yup, c8, c1, 3); 
            */


            me.SaveToXML("test0.xml");
            Marta.MEngine m1 = Marta.MEngine.LoadFromXML("test0.xml");

        }
    }
}