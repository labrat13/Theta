using System;
using System.Collections.Generic;
using System.Text;

namespace MyAddin1
{
    /// <summary>
    /// Parsed XML tag
    /// </summary>
    public class Str3
    {
        /// <summary>
        /// Tag name
        /// </summary>
        public string Name;
        /// <summary>
        /// Tag value, if exists
        /// </summary>
        public string Value;
        /// <summary>
        /// Tag text, if exists
        /// </summary>
        public string Text;
        /// <summary>
        /// Default constructor
        /// </summary>
        public Str3()
        {
            Name = "";
            Value = "";
            Text = "";
        }

    }
}
