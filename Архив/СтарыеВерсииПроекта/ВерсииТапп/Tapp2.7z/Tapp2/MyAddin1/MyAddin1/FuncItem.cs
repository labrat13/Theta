using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.IO;

namespace MyAddin1
{
    public class FuncItem : Item
    {
        /// <summary>
        /// Func kind
        /// </summary>
        public vsCMFunction FunctionKind;
        /// <summary>
        /// Overloaded functions
        /// </summary>
        public List<FuncItem> Overloads;
        /// <summary>
        /// func params with description
        /// </summary>
        public List<ParamItem> Parameters;
        /// <summary>
        /// Project filename
        /// </summary>
        public string ProjectFile;

        public string Prototype;
        /// <summary>
        /// function code listing
        /// </summary>
        public string codeText;
        /// <summary>
        /// default constructor
        /// </summary>
        public FuncItem(CodeFunction cf)
        {
                this.MakeAccessString(cf.Access, cf.IsShared, false, cf.IsOverloaded, cf.MustImplement, false);
                this.parseAttributes(cf.Attributes);
                this.codeText = "";
                this.DocComment = cf.DocComment;
                this.ParseDocComment(cf.DocComment);
                this.FullName = cf.FullName;
                this.FunctionKind = cf.FunctionKind;
                this.Name = cf.Name;
                //this.Overloads = new List<FuncItem>;
                FillParameters(cf.Parameters);
                this.ProjectFile = cf.ProjectItem.Name;
                this.Prototype = cf.get_Prototype((int)(vsCMPrototype.vsCMPrototypeType | vsCMPrototype.vsCMPrototypeParamTypes | vsCMPrototype.vsCMPrototypeParamNames));//void Main(string[] args)
            //get function text
                this.codeText = this.getCodeText((CodeElement)cf);

        }

        /// <summary>
        /// Fill func params
        /// </summary>
        /// <param name="ces"></param>
        private void FillParameters(CodeElements ces)
        {
            this.Parameters = new List<ParamItem>();
            foreach (CodeElement ce in ces)
            {
                if (ce.Kind == vsCMElement.vsCMElementParameter)
                {
                    ParamItem pi = new ParamItem((CodeParameter)ce);
                    this.Parameters.Add(pi);
                }
            }
        }
        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public override void MakeHtml()
        {
            StreamWriter sw = new StreamWriter(this.FileName, false, Encoding.UTF8);
            sw.WriteLine("<html><head><title>{0} function</title></head><body>", this.FullName);
            sw.WriteLine(Item.makeHeader());
            sw.WriteLine("<h1>{0}</h1>", this.Name);
            sw.WriteLine("<P>");
            sw.WriteLine(this.makeAttrHtmlString());
            sw.WriteLine("<b>{0} {1}</b>", this.Access, Item.makeHTMLsafe(this.Prototype));
            sw.WriteLine("</P>");
            sw.Write(this.XmlMakeDescription(true, true, true));//write unit description from doc comment
            sw.WriteLine(this.makeHTMLcode(this.codeText));
            sw.WriteLine(Item.makeFooter());
            sw.WriteLine("</body></html>");
            sw.Close();

        }
    }
}
