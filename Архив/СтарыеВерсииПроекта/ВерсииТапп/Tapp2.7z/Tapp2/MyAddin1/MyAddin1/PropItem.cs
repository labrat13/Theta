using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.IO;

namespace MyAddin1
{
    public class PropItem:Item
    {
        public string Prototype;
        public FuncItem Get;
        public FuncItem Set;
        public string propType;
        /// <summary>
        /// Code text for property
        /// </summary>
        public string codeText;
        /// <summary>
        /// Project filename
        /// </summary>
        public string ProjectFile;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="cp"></param>
        public PropItem(CodeProperty cp)
        {
            this.MakeAccessString(cp.Access, false, false, false, false, false);
            this.parseAttributes(cp.Attributes);
            this.DocComment = cp.DocComment;
            this.ParseDocComment(cp.DocComment);
            this.FullName = cp.FullName;
            this.Name = cp.Name;
            this.ProjectFile = cp.ProjectItem.Name;
            this.propType = cp.Type.AsFullName;
            this.Prototype = cp.get_Prototype((int)(vsCMPrototype.vsCMPrototypeType | vsCMPrototype.vsCMPrototypeParamTypes | vsCMPrototype.vsCMPrototypeParamNames));//void Main(string[] args)
            if (cp.Getter == null) this.Get = null; else this.Get = new FuncItem(cp.Getter);
            if (cp.Setter == null) this.Set = null; else this.Set = new FuncItem(cp.Setter);
            this.codeText = this.getCodeText((CodeElement)cp);
        }

        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public override void MakeHtml()
        {
            StreamWriter sw = new StreamWriter(this.FileName, false, Encoding.UTF8);
            sw.WriteLine("<html><head><title>{0} property</title></head><body>", this.FullName);
            sw.WriteLine(Item.makeHeader());
            sw.WriteLine("<h1>{0}</h1>", this.Name);
            sw.WriteLine("<P>");
            sw.WriteLine(this.makeAttrHtmlString());
            sw.WriteLine("<b>{0} {1}</b>", this.Access, Item.makeHTMLsafe(this.Prototype));
            sw.WriteLine("</P>");
            sw.Write(this.XmlMakeDescription(false, false, true));//write unit description from doc comment
            sw.WriteLine(this.makeHTMLcode(this.codeText));
            sw.WriteLine(Item.makeFooter());
            sw.WriteLine("</body></html>");
            sw.Close();

        }
    }
}
