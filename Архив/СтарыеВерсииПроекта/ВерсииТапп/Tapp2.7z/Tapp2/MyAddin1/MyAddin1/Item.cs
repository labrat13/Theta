using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.Xml;
using System.IO;

namespace MyAddin1
{
    /// <summary>
    /// Base class for codegraph
    /// </summary>
    public class Item : Object
    {
        public List<String> Attributes;
        public string DocComment;
        public List<Str3> Comments;
        public string Access; //public static virtual override...

        public string Name;

        public string FullName;
        /// <summary>
        /// Html file name
        /// </summary>
        public string FileName;
        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public virtual void MakeHtml()
        {
            //TODO: add default code here
        }
        /// <summary>
        /// ����������� �� ������� �����
        /// </summary>
        /// <param name="acc"></param>
        /// <returns></returns>
        private string access2str(vsCMAccess acc)
        {
            string s;
            switch (acc)
            {
                case vsCMAccess.vsCMAccessPrivate:
                    s = "private";
                    break;
                case vsCMAccess.vsCMAccessProtected:
                    s = "protected";
                    break;
                case vsCMAccess.vsCMAccessPublic:
                    s = "public";
                    break;
                default:
                    s = "";
                    break;
            }
            return s;

        }

        /// <summary>
        /// Make access string as "public override static" and save internally
        /// </summary>
        /// <param name="acc"></param>
        /// <param name="isShared">true or false</param>
        /// <param name="isAbstract">true or false</param>
        /// <param name="isOverload">true or false</param>
        /// <param name="mustImplement">true or false</param>
        /// <param name="isConst">true or false</param>
        public void MakeAccessString(vsCMAccess acc, bool isShared, bool isAbstract, bool isOverload, bool mustImplement, bool isConst)
        {
            string res = access2str(acc);
            if (isShared) res = res + " static";
            if (isOverload) res = res + " overload";
            if (mustImplement) res = res + " virtual";
            if (isConst) res = res + " const";
            if (isAbstract) res = res + " abstract";
            this.Access = res;
        }
        /// <summary>
        /// Make string from attribute
        /// </summary>
        /// <param name="ca">code element</param>
        /// <returns>string representation of attribute</returns>
        public string parseAttribute(CodeAttribute ca)
        {
            String res;
            try
            {
                if (String.IsNullOrEmpty(ca.Value))
                    res = String.Format("<i>{0}</i>", ca.FullName);
                else res = String.Format("<i>{0}</i> ({1})", ca.FullName, ca.Value);
            }
            catch
            {
                res = "Error parsing attribute";
            }
            return res;
        }
        /// <summary>
        /// Create and fill list of attributes
        /// </summary>
        /// <param name="ca">attributes collection</param>
        public void parseAttributes(CodeElements ca)
        {
            Attributes = new List<string>();
            foreach (CodeElement ce in ca)
            {
                Attributes.Add(parseAttribute((CodeAttribute)ce));
            }
        }

        /// <summary>
        /// Parse XML comments and create comments list
        /// </summary>
        /// <param name="txt">Doc comments as XML</param>
        public void ParseDocComment(String txt)
        {
            this.Comments = new List<Str3>();
            Str3 node = null;
            if (!String.IsNullOrEmpty(txt))
            {
                
                //create xml reader
                XmlTextReader rd = new XmlTextReader((TextReader)new StringReader(txt));
                rd.WhitespaceHandling = WhitespaceHandling.None;
                ///Parse text
                while (rd.Read())
                {
                    switch (rd.NodeType)
                    {
                        case XmlNodeType.Element:
                            node = new Str3();
                            node.Name = rd.Name;
                            if (rd.HasAttributes)
                            {
                                rd.MoveToFirstAttribute();
                                node.Value = rd.Value;
                            }
                            break;
                        case XmlNodeType.EndElement:
                            //add node to list
                            Comments.Add(node);
                            break;
                        case XmlNodeType.Text:
                            node.Text = rd.Value.Trim();
                            break;
                        default:
                            break;
                    }
                }
                //close reader
                rd.Close();
            }
        }

        /// <summary>
        /// Get list of tag filtered by tag name
        /// </summary>
        /// <param name="tagName">tag name: example exception permission remarks returns value </param>
        /// <param name="sort"> True - sort items by middle field</param>
        /// <returns>tag list</returns>
        public List<Str3> getTagList(string tagName, bool sort)
        {
            List<Str3> li = new List<Str3>();
            foreach (Str3 s in this.Comments)
                if (String.Equals(s.Name, tagName)) li.Add(s);
            if (sort)    //sort list items
                li.Sort(Item.sortByStr3Value);
            return li;
        }
        /// <summary>
        /// Get text of tag by name. If more than one tags match the name, concatenate it.
        /// </summary>
        /// <param name="tagName">tag name</param>
        /// <param name="Append">true - concatenate founded tags text</param>
        /// <returns>tag text or String.Empty</returns>
        public string getTagText(String tagName, bool Append)
        {
            StringBuilder sb = new StringBuilder();
            foreach (Str3 s in this.Comments)
                if(String.Equals(s.Name, tagName))
                {
                    sb.AppendLine(s.Text);
                    if (!Append) break; 
                }
            return sb.ToString();
        }
        /// <summary>
        /// Get text of tag by name and value - for example, param tag
        /// </summary>
        /// <param name="tagName">tag name - f.e. param</param>
        /// <param name="tagValue">tag value - f.e. tagValue</param>
        /// <returns>tag text or String.Empty</returns>
        public string getTagText(String tagName, string tagValue)
        {
            foreach (Str3 s in this.Comments)
                if ((String.Equals(s.Value, tagValue)) && (String.Equals(s.Name, tagName)))
                    return s.Text;
            return "";
        }
        /// <summary>
        /// Make description string for summary, remarks, returns, exception 
        /// </summary>
        /// <returns>description string</returns>
        public string XmlMakeDescription(bool showParams, bool showReturns, bool showExceptions )
        {
            StringBuilder sb = new StringBuilder();
            String text;
            sb.AppendLine("");
            //summary
            text = this.getTagText("summary", false);
            if (String.IsNullOrEmpty(text)) text = "No info";
            sb.AppendLine("<H4>Summary</H4>");
            sb.AppendLine("<P>");
            sb.AppendLine(text);
            sb.AppendLine("</P>");
            sb.AppendLine("");
            //params
            if (showParams)
            {
                text = makeTableParams("", getTagList("param", false));
                if (String.IsNullOrEmpty(text)) text = "No parameters";
                sb.AppendLine("<H4>Parameters</H4>");
                sb.AppendLine("<P>");
                sb.AppendLine(text);
                sb.AppendLine("</P>");
                sb.AppendLine("");
            }
            //returns
            if (showReturns)
            {
                text = this.getTagText("returns", false);
                if (String.IsNullOrEmpty(text)) text = "No info";
                sb.AppendLine("<H4>Returns</H4>");
                sb.AppendLine("<P>");
                sb.AppendLine(text);
                sb.AppendLine("</P>");
                sb.AppendLine("");
            }
            //remarks
            text = this.getTagText("remarks", false);
            if (String.IsNullOrEmpty(text)) text = "No remarks";
            sb.AppendLine("<H4>Remarks</H4>");
            sb.AppendLine("<P>");
            sb.AppendLine(text);
            sb.AppendLine("</P>");
            sb.AppendLine("");

            //exceptions
            if (showExceptions)
            {
                text = makeTableParams("", getTagList("exception", true));
                if (String.IsNullOrEmpty(text)) text = "No exceptions";
                sb.AppendLine("<H4>Exceptions</H4>");
                sb.AppendLine("<P>");
                sb.AppendLine(text);
                sb.AppendLine("</P>");
                sb.AppendLine("");
            }
            return sb.ToString();
        }
        /// <summary>
        /// Make table for params, exceptions, etc.
        /// </summary>
        /// <param name="colZero">content for column0, if need (picture)</param>
        /// <param name="itemsList">list of item tag</param>
        /// <returns>table representation</returns>
        public string makeTableParams(string colZero, List<Str3> itemsList)
        {
            if(itemsList.Count == 0) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<table cellpadding=3; font-family:arial; >");
            foreach (Str3 s in itemsList)
                sb.AppendFormat("<tr><td>{0}</td>{1}<td><B>{2}</B></td>{3}<td>{4}</td></tr>{5}", colZero, Environment.NewLine, s.Value, Environment.NewLine, s.Text, Environment.NewLine);
            sb.AppendLine("</table>");
            return sb.ToString();
        }
        /// <summary>
        /// Get summary info about item
        /// </summary>
        /// <returns>info or message</returns>
        public string getSummary()
        {
            String text = this.getTagText("summary", false);
            if(String.IsNullOrEmpty(text)) text = "No information";
            return text;
        }
        /// <summary>
        /// Make table with description for items
        /// </summary>
        /// <param name="colZero">content for column0, if need (picture)</param>
        /// <param name="iList">list of item </param>
        /// <param name="wLinks">True - with HTML links to item page</param>
        /// <returns>table representation</returns>
        public static string makeTableItems(string colZero, List<Item> iList, bool wLinks)
        {
            if (iList.Count == 0) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<table cellpadding=3; font-family:arial; >");
            string name;

            foreach (Item i in iList)
            {
                if (wLinks) name = Item.makeItemNameLink(i); else name = i.Name;
                sb.AppendFormat("<tr><td>{0}</td>{1}<td><B>{2}</B></td>{3}<td>{4}</td></tr>{5}", colZero, Environment.NewLine, name, Environment.NewLine, i.getSummary(), Environment.NewLine);
            }
            sb.AppendLine("</table>");
            return sb.ToString();
        }
        /// <summary>
        /// Return item name as hyperlink
        /// </summary>
        /// <param name="i">item</param>
        /// <returns>string</returns>
        public static string makeItemNameLink(Item i)
        {
             return String.Format("<a href=\"{0}\">{1}</a>", i.FileName, i.Name);
        }

        /// <summary>
        /// Make attributes html string for items
        /// </summary>
        /// <returns></returns>
        public string makeAttrHtmlString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (string s in this.Attributes)
                sb.AppendFormat("{0}<br>{1}", s, Environment.NewLine);
            return sb.ToString();
        }

        /// <summary>
        /// Sort predicate for sorting by item name
        /// </summary>
        /// <param name="i1"></param>
        /// <param name="i2"></param>
        /// <returns></returns>
        public static int sortByItemName(Item i1, Item i2)
        {
            return String.Compare(i1.Name, i2.Name, true);
        }

        /// <summary>
        /// Sort predicate for sorting by Str3 name
        /// </summary>
        /// <param name="i1"></param>
        /// <param name="i2"></param>
        /// <returns></returns>
        public static int sortByStr3Value(Str3 i1, Str3 i2)
        {
            return String.Compare(i1.Value, i2.Value, true);
        }
        /// <summary>
        /// get code text of function, field, property 
        /// </summary>
        /// <param name="ce">Code element</param>
        /// <returns>string of code text</returns>
        public String getCodeText(CodeElement ce)
        {
            EditPoint ep = ce.StartPoint.CreateEditPoint();
            ep.StartOfLine();
            return ep.GetText(ce.EndPoint);
        }
        /// <summary>
        /// make html text for code text 
        /// </summary>
        /// <param name="Txt">code text for element</param>
        /// <returns>html string</returns>
        public string makeHTMLcode(string Txt)
        {
            //exclude <> chars from text
            string codeText = makeHTMLsafe(Txt);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<h4>Code</h4>");
            sb.AppendLine("<PRE>");
            sb.AppendLine(codeText);
            sb.AppendLine("</PRE>");
            return sb.ToString();
        }

        /// <summary>
        /// Replace XML brackets in text to safe HTML show
        /// </summary>
        /// <param name="text">Original text</param>
        /// <returns>HTML-safe text</returns>
        public static string makeHTMLsafe(String text)
        {
            string codeText = text.Replace("<", "&lt");
            codeText = codeText.Replace(">", "&gt");
            return codeText;
        }
        /// <summary>
        /// make document header
        /// </summary>
        /// <returns></returns>
        public static string makeHeader()
        {
            return "<BASEFONT face=\"Arial\">";
        }
        
        /// <summary>
        /// make document footer
        /// </summary>
        /// <returns></returns>
        public static string makeFooter()
        {
            return "<HR>Document generated " + DateTime.Now.ToString(); 
        }
    }
}
