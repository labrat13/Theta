﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace SppCore
{
    public class MCell
    {
        #region Fields
        /// <summary>
        /// Cell ID
        /// </summary>
        private CID m_id;
        /// <summary>
        /// Comment string
        /// </summary>
        private String m_comment;
        /// <summary>
        /// Creation datetime
        /// </summary>
        private DateTime m_creaTime;
        /// <summary>
        /// Data of cell
        /// </summary>
        private Object m_data;
        /// <summary>
        /// Type of cell data
        /// </summary>
        private System.Type m_dataType;
        /// <summary>
        /// Modification datetime
        /// </summary>
        private DateTime m_modiTime;
        /// <summary>
        /// Cell name
        /// </summary>
        private String m_name;
        /// <summary>
        /// Cell state
        /// </summary>
        private MCellState m_state;
        /// <summary>
        /// Cell metainfo object
        /// </summary>
        private Object m_meta;
        /// <summary>
        /// Read-only flag
        /// </summary>
        private bool m_ReadOnly;
        /// <summary>
        /// Parent container
        /// </summary>
        private MEngine m_engine;
        /// <summary>
        /// X up links list
        /// </summary>
        private List<CLink> m_Xup;
        /// <summary>
        /// X down links list
        /// </summary>
        private List<CLink> m_Xdn;
        /// <summary>
        /// Y up links list
        /// </summary>
        private List<CLink> m_Yup;
        /// <summary>
        /// Y down links list
        /// </summary>
        private List<CLink> m_Ydn;
        /// <summary>
        /// Z up links list
        /// </summary>
        private List<CLink> m_Zup;
        /// <summary>
        /// Z down links list
        /// </summary>
        private List<CLink> m_Zdn;
        #endregion
        /// <summary>
        /// Default constructor, used by XML serializator
        /// </summary>
        public MCell()
        {
            m_creaTime = DateTime.Now;
            m_comment = null;
            m_data = null;
            m_dataType = typeof(Object);
            m_engine = null;
            m_id = null;
            m_meta = null;
            m_modiTime = m_creaTime;
            m_name = null;
            m_ReadOnly = false;
            m_state = MCellState.Normal;
            m_Xdn = new List<CLink>();
            m_Xup = new List<CLink>();
            m_Ydn = new List<CLink>();
            m_Yup = new List<CLink>();
            m_Zdn = new List<CLink>();
            m_Zup = new List<CLink>();
        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="me"></param>
        /// <param name="objId"></param>
        /// <param name="name"></param>
        /// <param name="comment"></param>
        /// <param name="cellData"></param>
        /// <param name="dataType"></param>
        /// <param name="meta"></param>
        internal MCell(MEngine me, CID objId, string name, String comment, Object cellData, Type dataType, Object meta)
        {
            m_creaTime = DateTime.Now;
            m_comment = comment;
            m_data = cellData;
            m_dataType = dataType;
            m_engine = me;
            m_id = objId;
            m_meta = meta;
            m_modiTime = m_creaTime;
            m_name = name;
            m_ReadOnly = false;
            m_state = MCellState.Normal;
            m_Xdn = new List<CLink>();
            m_Xup = new List<CLink>();
            m_Ydn = new List<CLink>();
            m_Yup = new List<CLink>();
            m_Zdn = new List<CLink>();
            m_Zup = new List<CLink>();
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~MCell()
        {
            
        }

        #region Properties
        /// <summary>
        /// Cell ID
        /// </summary>
        public CID ID
        {
            get
            {
                return m_id;
            }
            set
            {
                m_id = value;
            }
        }

        /// <summary>
        /// Cell name
        /// </summary>
        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }
        /// <summary>
        /// Cell state
        /// </summary>
        public MCellState State
        {
            get
            {
                return m_state;
            }
            set
            {
                m_state = value;
            }
        }
        /// <summary>
        /// Type of cell data
        /// </summary>
        [XmlIgnore]
        public Type DataType
        {
            get
            {
                return m_dataType;
            }
            set
            {
                m_dataType = value;
            }
        }

        /// <summary>
        /// Data type as string, because System.Type not serialized to XML correctly
        /// </summary>
        public String DataTypeAsString
        {
            get { return m_dataType.ToString(); }
            set { m_dataType = Type.GetType(value, true, true); }
        }

        /// <summary>
        /// Data of cell
        /// </summary>
        public Object Data
        {
            get
            {
                return m_data;
            }
            set
            {
                m_data = value;
            }
        }


        /// <summary>
        /// Comment string
        /// </summary>
        public string Comment
        {
            get
            {
                return m_comment;
            }
            set
            {
                m_comment = value;
            }
        }

        /// <summary>
        /// Creation datetime
        /// </summary>
        public DateTime CreationTime
        {
            get
            {
                return m_creaTime;
            }
            set
            {
                m_creaTime = value;
            }
        }

        /// <summary>
        /// Modification datetime
        /// </summary>
        public DateTime ModifyTime
        {
            get
            {
                return m_modiTime;
            }
            set
            {
                m_modiTime = value;
            }
        }

        /// <summary>
        /// Parent container
        /// </summary>
        [XmlIgnore]
        public MEngine Engine
        {
            get
            {
                return m_engine;
            }
        }

        /// <summary>
        /// Cell metainfo object
        /// </summary>
        public Object MetaInfo
        {
            get
            {
                return m_meta;
            }
            set
            {
                m_meta = value;
            }
        }



        /// <summary>
        /// Read-only flag
        /// </summary>
        public bool ReadOnly
        {
            get
            {
                return m_ReadOnly;
            }
            set
            {
                m_ReadOnly = value;
            }
        }



        /// <summary>
        /// X up links list
        /// </summary>
        public System.Collections.Generic.List<CLink> XupLinks
        {
            get
            {
                return m_Xup;
            }
        }

        /// <summary>
        /// X down links list
        /// </summary>
        public System.Collections.Generic.List<CLink> XdnLinks
        {
            get
            {
                return m_Xdn;
            }
        }

        /// <summary>
        /// Y up links list
        /// </summary>
        public System.Collections.Generic.List<CLink> YupLinks
        {
            get
            {
                return m_Yup;
            }
        }

        /// <summary>
        /// Y down links list
        /// </summary>
        public System.Collections.Generic.List<CLink> YdnLinks
        {
            get
            {
                return m_Ydn;
            }
        }

        /// <summary>
        /// Z up links list
        /// </summary>
        public System.Collections.Generic.List<CLink> ZupLinks
        {
            get
            {
                return m_Zup;
            }
        }

        /// <summary>
        /// Z down links list
        /// </summary>
        public System.Collections.Generic.List<CLink> ZdnLinks
        {
            get
            {
                return m_Zdn;
            }
        }
        #endregion


        /// <summary>
        /// Return string representation of object
        /// </summary>
        /// <returns>ID name state</returns>
        public override string ToString()
        {
            return String.Format("{0} {1} {2}", this.m_id.ToString(), m_name, m_state.ToString());
        }

        /// <summary>
        /// Set backreference to container
        /// </summary>
        /// <param name="me"></param>
        internal void intSetBackRef(MEngine me)
        {
            m_engine = me;
        }

        #region *** XML function (not used, for XML testing only)***
        /// <summary>
        /// save data to XML file
        /// </summary>
        /// <param name="filename">name of XML file</param>
        public void SaveToXML(string filename)
        {
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            writer.Serialize(file, this);
            file.Close();
        }

        /// <summary>
        /// load data from XML file
        /// </summary>
        /// <param name="filename">name of XML file</param>
        public static MCell LoadFromXML(string filename)
        {
            MCell li;
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(Type.GetType("MCell"));
            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            li = (MCell) reader.Deserialize(file);
            file.Close();
            return li;
        }
        #endregion

    }
}
