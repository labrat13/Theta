﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;


namespace SppCore
{
    /// <summary>
    /// Class represent Object ID
    /// </summary>
    public class CID
    {
        /// <summary>
        /// Id of class
        /// </summary>
        private uint classId;
        /// <summary>
        /// Id of object
        /// </summary>
        private uint objId;
        /// <summary>
        /// default constructor
        /// </summary>
        public CID()
        {
            classId = 0;
            objId = 0;
        }
        /// <summary>
        /// parameter constructor
        /// </summary>
        /// <param name="cId">class id number</param>
        /// <param name="oId">object id number</param>
        public CID(uint cId, uint oId)
        {
            classId = cId;
            objId = oId;
        }
        /// <summary>
        /// copy constructor
        /// </summary>
        /// <param name="copy">object for copying</param>
        public CID(CID copy)
        {
            classId = copy.ClassID;
            objId = copy.ObjID;
        }        
        /// <summary>
        /// get set Class ID of current object
        /// </summary>
        [XmlIgnore]
        public uint ClassID
        {
            get { return classId; }
            set { classId = value;}
        }

        /// <summary>
        /// get set Object ID of current object
        /// </summary>
        [XmlIgnore]
        public uint ObjID
        {
            get { return objId; }
            set { objId = value;}
        }

        /// <summary>
        /// Current CID is class template object?
        /// </summary>
        [XmlIgnore]
        public bool IsTemplateObject
        {
            get { return (this.objId == (uint)SystemObjectNames.Template); }
        }

        /// <summary>
        /// Current CID is Unknown object?
        /// </summary>
        [XmlIgnore]
        public bool IsUnknownObject
        {
            get { return (this.objId == (uint)SystemObjectNames.Unknown); }
        }

        /// <summary>
        /// Current CID is Undefined object?
        /// </summary>
        [XmlIgnore]
        public bool IsUndefinedObject
        {
            get { return (this.objId == (uint)SystemObjectNames.Undefined); }
        }

        /// <summary>
        /// Current CID is World class?
        /// </summary>
        [XmlIgnore]
        public bool IsWorldClass
        {
            get { return (this.classId == (uint)SystemClassNames.World); }
        }

        /// <summary>
        /// Get default class icon ID
        /// </summary>
        [XmlIgnore]
        public static CID DefaultIconId
        {
            get { return new CID(0, 0); }
        }

        /// <summary>
        /// Get unused ID - if you need specify ID, which is not used (255:255)
        /// </summary>
        [XmlIgnore]
        public static CID UnusedId
        {
            get { return new CID(255, 255); }
        }
        /// <summary>
        /// get or set String representation of ID's
        /// </summary>
        public string IDstr
        {
            get
            {
                return this.ToString();
            }
            set
            {
                string[] sar = value.Split(new char[] {':'}, StringSplitOptions.RemoveEmptyEntries);
                classId = UInt32.Parse(sar[0]);
                objId = UInt32.Parse(sar[1]);
            }
        }
        /// <summary>
        /// Detect User space of object ID (ID bigger than 256)
        /// </summary>
        [XmlIgnore]
        public Boolean isUserObject
        {
            get { return (this.objId > 255); }
        }
        /// <summary>
        /// Detect User space of class ID (ID bigger than 256)
        /// </summary>
        [XmlIgnore]
        public Boolean isUserClass
        {
            get { return (this.classId > 255); }
        }

        /// <summary>
        /// Return string representation of object
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("{0}:{1}", classId, objId);
        }
        /// <summary>
        /// Is equal ID's?
        /// </summary>
        /// <param name="id">compared ID</param>
        /// <returns>true if ID's full equal</returns>
        public bool isEqual(CID id)
        {
            return ((this.objId == id.objId) && (this.classId == id.classId));
        }

        /// <summary>
        /// Get ID Unknown as copy of current ID
        /// </summary>
        /// <returns></returns>
        public CID getID_Unknown()
        {
            return new CID(this.classId, (uint) SystemObjectNames.Unknown );
        }
        /// <summary>
        /// Get ID Undefined as copy of current ID
        /// </summary>
        /// <returns></returns>
        public CID getID_Undefined()
        {
            return new CID(this.classId, (uint) SystemObjectNames.Undefined );
        }
        /// <summary>
        /// Get ID Nothing as copy of current ID
        /// </summary>
        /// <returns></returns>
        public CID getID_Nothing()
        {
            return new CID(this.classId, (uint) SystemObjectNames.Nothing );
        }

        /// <summary>
        /// Get ID of template of current class
        /// </summary>
        public CID getID_Template()
        {
            return new CID(this.classId, (uint)SystemObjectNames.Template);
        }

        /// <summary>
        /// If current CID represent a class template object, throw exception
        /// </summary>
        /// <remarks>Performing simple checking checking for all operations with objects</remarks>
        /// <exception cref="Score.SeInvalidUseTemplateException"> Thrown if ID of object is template</exception>
        public void IsTemplateObjectThrowException()
        {
            if (this.objId == (uint)SystemObjectNames.Template) throw new SeInvalidUseTemplateException(this);
        }
        /// <summary>
        /// Get World class ID
        /// </summary>
        /// <returns></returns>
        public static CID GetWorldClassID()
        {
            return new CID((uint)SystemClassNames.World,  (uint)SystemObjectNames.Template);
        }
        /// <summary>
        /// Get Unknown class ID
        /// </summary>
        /// <returns></returns>
        public static CID GetUnknownClassID()
        {
            return new CID((uint)SystemClassNames.Unknown, (uint)SystemObjectNames.Template);
        }
        /// <summary>
        /// get Undefined class ID
        /// </summary>
        /// <returns></returns>
        public static CID GetUndefinedClassID()
        {
            return new CID((uint)SystemClassNames.Undefined, (uint)SystemObjectNames.Template);
        }
        /// <summary>
        /// get Nothing class ID
        /// </summary>
        /// <returns></returns>
        public static CID GetNothingClassID()
        {
            return new CID((uint)SystemClassNames.Nothing, (uint)SystemObjectNames.Template);
        }
        /// <summary>
        /// Get copy of current object
        /// </summary>
        /// <returns>copy of current object</returns>
        public CID getCopy()
        {
            return new CID(this.classId, this.objId);
        }
    }
}
