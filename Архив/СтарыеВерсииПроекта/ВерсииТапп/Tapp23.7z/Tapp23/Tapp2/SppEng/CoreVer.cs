﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace SppCore
{
    /// <summary>
    /// Easyest access to database engine version from any outside apps
    /// </summary>
    public static class CoreVer
    {
        /// <summary>
        /// Database engine version number
        /// </summary>
        public static Int32 CoreVersion
        {
            get { return 2; }
        }
        
        /// <summary>
        /// Database engine subversion number. For User only. Can be ignored in code.
        /// </summary>
        public static Int32 CoreSubVersion
        {
            get { return 1; }//look version history for details
        }
        /// <summary>
        /// Description of current version of engine 
        /// </summary>
        public static String DescriptionVer
        {
            //TODO: Add specific description and constraints here
            get { return "See Version.txt for full description"; }
        }

        #region Assembly Attribute Accessors
        /// <summary>
        /// Engine assembly title
        /// </summary>
        public static string AssemblyTitle
        {
            get
            {
                return "Semantic platform project core engine";
            }
        }
        /// <summary>
        /// Engine assembly version
        /// </summary>
        public static string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }
        /// <summary>
        /// Engine assembly description
        /// </summary>
        public static string AssemblyDescription
        {
            get
            {
                return "Semantic platform project core engine library";
            }
        }
        /// <summary>
        /// Engine assembly product name
        /// </summary>
        public static string AssemblyProduct
        {
            get
            {
                return "Semantic platform project";
            }
        }
        /// <summary>
        /// Engine assembly Copyright
        /// </summary>
        public static string AssemblyCopyright
        {
            get
            {
                return "Copyright (ReadOnly) 2011 Pavel Selyakov"; 
            }
        }
        /// <summary>
        /// Engine assembly company
        /// </summary>
        public static string AssemblyCompany
        {
            get
            {
                return "Pavel Selyakov";
            }
        }
        #endregion
    }
}
