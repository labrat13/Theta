﻿
namespace SppCore
{
    /// <summary>
    /// Dimension axis code: X-aggregation, Y-abstraction, Z-reserved
    /// </summary>
    public enum MAxis
    {
        /// <summary>
        /// Aggregation axis
        /// </summary>
        Aggr_X = 0,
        /// <summary>
        /// Abstraction axis
        /// </summary>
        Abst_Y = 1,
        /// <summary>
        /// Alternative axis
        /// </summary>
        Axis_Z = 2,
    }
    
    
    /// <summary>
    /// Link states
    /// </summary>
    /// <remarks>Link states defined by system architecture</remarks>
    public enum HLinkState
    {
        /// <summary>
        /// Restricted link - prohibite link between classes or objects
        /// </summary>
        /// <remarks>For objects - prohibite link between specified objects, for templates (classes) - prohibite link between any objects of these classes</remarks>
        Restricted = 0,

        /// <summary>
        /// Normal link 
        /// </summary>
        Normal = 1,

        /// <summary>
        /// Deleted link - link non-actual and must be deleted physically by database optimization service
        /// </summary>
        /// <remarks>связь только помечается удаленной, но физически не удаляется до выгрузки в БД. 
        /// Удаляется в процессе выгрузки структуры в БД после окончания работы.
        /// применение в шаблоне означает, что ссылки всех объектов на конечный класс готовятся к удалению, 
        /// поэтому ссылки на объекты этого класса постепенно тоже отмечаются как удаляемые
        /// применение в объекте означает, что ссылка на конечный объект готовится к удалению.
        /// </remarks>
        Deleted = 2,

        /// <summary>
        /// Undefined link - for automate data serving.
        /// </summary>
        /// <remarks>применение в шаблоне означает, что для связи не установлен конечный класс – то есть,
        /// связь «висит», и оптимизатор должен определить, что с ней делать или запросить пользователя.
        /// Применение в объекте означает,  что для связи не установлен конечный объект, хотя, возможно, 
        /// известен класс.  Оптимизатор должен определить сам или запросить пользователя. </remarks>
        Undefined = 3,
    }


    /// <summary>
    /// Link types
    /// </summary>
    /// <remarks>Type of link can use different link types (semantic, hierarchy or associative) with uniform storing and using.
    /// </remarks>
    public enum LinkType
    {
        /// <summary>
        /// Semantic link 
        /// </summary>
        Semantic = 0,
        /// <summary>
        /// Meta link 
        /// </summary>
        /// <remarks>15.11.2010 v1.11</remarks>
        Meta = 1,
        /// <summary>
        /// Other link type
        /// </summary>
        Other

    }

    /// <summary>
    /// Defines cell state
    /// </summary>
    public enum MCellState
    {
        /// <summary>
        /// Normal state
        /// </summary>
        Normal = 0,
        /// <summary>
        /// Ready to delete
        /// </summary>
        /// <remarks>если применен в классе или шаблоне, класс и его объекты готовятся к удалению;
        /// если применен в объекте – объект готовится к удалению</remarks>
        Deleted,
        /// <summary>
        /// Not used now, reserved
        /// </summary>
        Restricted,
        /// <summary>
        /// класс или объект неопределен – промежуточное состояние объекта или класса, означающее, что он требует внимания оптимизатора\пользователя.
        /// </summary>
        Undefined,
        /// <summary>
        /// Класс или объект неизвестен
        /// </summary>
        Unknown,
        /// <summary>
        /// Класс или объект не существует
        /// </summary>
        Nothing
    }

    /// <summary>
    /// System objects names
    /// </summary>
    /// <remarks>Исользуются для исключения путаницы в предопределенных значениях</remarks>
    public enum SystemObjectNames
    {
        /// <summary>
        /// System object - template
        /// </summary>
        Template = 0,
        /// <summary>
        /// Неизвестно
        /// </summary>
        Unknown = 1,
        /// <summary>
        /// Неопределено
        /// </summary>
        Undefined = 2,
        /// <summary>
        /// Не существует
        /// </summary>
        Nothing = 3
    }
    /// <summary>
    /// System class names
    /// </summary>
    public enum SystemClassNames
    {
        /// <summary>
        /// Start class of database view
        /// </summary>
        World = 0,
        /// <summary>
        /// Class "Unknown"
        /// </summary>
        Unknown = 1,
        /// <summary>
        /// Class "Undefined"
        /// </summary>
        Undefined = 2,
        /// <summary>
        /// Class "Nothing"
        /// </summary>
        Nothing = 3,
    }



    /// <summary>
    /// Metatype for classes
    /// </summary>
    /// <remarks>15.11.2010 v1.11</remarks>
    public enum MetaTypeOfClass
    {
        /// <summary>
        /// Metatype not defined - may be error
        /// </summary>
        Default = 0,
        /// <summary>
        /// Class represent data value
        /// </summary>
        Data,
        /// <summary>
        /// Class represent category or entity
        /// </summary>
        Category,
        /// <summary>
        /// Class represent collection of any elements
        /// </summary>
        Collection,
        /// <summary>
        /// Class represent element of collection
        /// </summary>
        CollectionElement,
        /// <summary>
        /// reserved
        /// </summary>
        Unknown,
        /// <summary>
        /// reserved
        /// </summary>
        Undefined,
        /// <summary>
        /// reserved
        /// </summary>
        Nothing,
        /// <summary>
        /// Class represent system class
        /// </summary>
        System,

    }

}