﻿using System;
using System.Collections.Generic;
using System.Text;


namespace SppCore
{
    public class MEngine
    {
        #region Fields
        /// <summary>
        /// Base version (format version)
        /// </summary>
        private int m_version;
        /// <summary>
        /// Base step (data content version)
        /// </summary>
        private int m_step;
        /// <summary>
        /// Data file path
        /// </summary>
        private string m_filePath;
        /// <summary>
        /// Description text
        /// </summary>
        private String m_descr;
        /// <summary>
        /// Creation time
        /// </summary>
        private DateTime m_creaTime;
        /// <summary>
        /// List of cells
        /// </summary>
        private List<MCell> m_cellList;
        /// <summary>
        /// Log file path
        /// </summary>
        private System.IO.StreamWriter m_logPath;
#endregion

        /// <summary>
        /// Default constructor used by XML serializing. Do not use this constructor!
        /// </summary>
        public MEngine()
        {
            m_cellList = new List<MCell>();
            m_creaTime = DateTime.Now;
            m_step = 0;
            m_version = CoreVer.CoreVersion;
            m_descr = String.Format("Tapp database file, ver {0}, step {1}", m_version, m_step); //base description
            m_filePath = "";
            openLog(); //open log file
        }

        /// <summary>
        /// Create new ClassSet with predefined objects
        /// </summary>
        /// <param name="initialStep">initial base step value. 0 for first use</param>
        public MEngine(int initialStep)
        {
            m_cellList = new List<MCell>();
            m_creaTime = DateTime.Now;
            m_step = initialStep;
            m_version = CoreVer.CoreVersion;
            m_descr = String.Format("Tapp database file, ver {0}, step {1}", m_version, m_step); //base description
            m_filePath = "";
            openLog(); //open log file
            //create system objects here

            //set backrefs
            SetBackRefs();
        }
        /// <summary>
        /// Set all cell's backref to current container
        /// </summary>
        private void SetBackRefs()
        {
            foreach (MCell m in m_cellList)
            {
                m.intSetBackRef(this);
            }
        }



        /// <summary>
        /// Destructor
        /// </summary>
        ~MEngine()
        {
            closeLog();
        }

        #region Properties
        /// <summary>
        /// Description text
        /// </summary>
        public String Description
        {
            get
            {
                return m_descr;
            }
            set
            {
                m_descr = value;
            }
        }

        /// <summary>
        /// Base version (format version)
        /// </summary>
        public int Version
        {
            get
            {
                return m_version;
            }
            set
            {
                m_version = value;
            }
        }

        /// <summary>
        /// Base step (data content version)
        /// </summary>
        public int Step
        {
            get
            {
                return m_step;
            }
            set
            {
                m_step = value;
            }
        }

        /// <summary>
        /// Creation time
        /// </summary>
        public DateTime CreationTime
        {
            get
            {
                return m_creaTime;
            }
            set
            {
                m_creaTime = value;
            }
        }

        /// <summary>
        /// List of cells
        /// </summary>
        public List<MCell> Cells
        {
            get
            {
                return m_cellList;
            }
        }
        #endregion

        /// <summary>
        /// Return string representation of object - RE
        /// </summary>
        /// <returns>Engine: [num of cells]</returns>
        public override string ToString()
        {
            return "Engine: " + this.m_cellList.Count.ToString();
        }


        /// <summary>
        /// Open log file and write startup message
        /// </summary>
        private void openLog()
        {
            m_logPath = new System.IO.StreamWriter(String.Format("SppCoreLog_{0}.txt", DateTime.Now.Ticks), true, Encoding.Unicode);
            addLogMsg(0, String.Format("Database start: {0} {1}", m_descr, m_filePath));
        }

        /// <summary>
        /// Add message to log
        /// </summary>
        /// <param name="code">Message code</param>
        /// <param name="msg">message text</param>
        public void addLogMsg(int code, String msg)
        {
            m_logPath.WriteLine(String.Format("{0} {1} {2}", DateTime.Now, code, msg));
            m_logPath.Flush();
        }

        /// <summary>
        /// Close log file
        /// </summary>
        private void closeLog()
        {
            addLogMsg(1, "Database closed");
            m_logPath.Close();
            m_logPath = null;
        }

        #region XML functions
        /// <summary>
        /// save data to XML file - old, for code and test use only
        /// </summary>
        /// <param name="filename">name of XML file</param>
        public void SaveToXML(string filename)
        {
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            writer.Serialize(file, this);
            file.Close();
            file.Dispose();
        }

        /// <summary>
        /// load data from XML file - old, for code and test use only
        /// </summary>
        /// <param name="filename">name of XML file</param>
        public static MEngine LoadFromXML(string filename)
        {
            MEngine li;
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(Type.GetType("SppCore.MEngine"));
            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            li = (MEngine)reader.Deserialize(file);
            file.Close();
            //patch to right base object references structure
            li.SetBackRefs();
            return li;
        }
        /// <summary>
        /// Load database from stepped database file pathname
        /// </summary>
        /// <param name="pathname">stepped database file pathname</param>
        /// <returns>database object</returns>
        public static MEngine LoadBaseStep(string pathname)
        {
            //refine database name from step number
            //example:  c:\dir\dbfile.8.xml   - dbfile.xml step 8
            String newPath = removeStepPath(pathname);
            MEngine cs = MEngine.LoadFromXML(pathname);
            cs.m_filePath = newPath;
            return cs;
        }

        /// <summary>
        /// Save base as base step 
        /// </summary>
        /// <param name="path">Pathname for new database file. If pathname = null, use pathname stored by database loading</param>
        public void SaveBaseStep(string pathname)
        {
            //get and check pathname
            if (String.IsNullOrEmpty(pathname)) pathname = this.m_filePath;
            //save base
            this.m_step++;
            this.m_creaTime = DateTime.Now;
            String stepPath = addStepPath(pathname);
            SaveToXML(stepPath);
        }
        /// <summary>
        /// Add base step number to file pathname 
        /// </summary>
        /// <param name="path">path for modifying</param>
        /// <returns>modified path</returns>
        private string addStepPath(string path)
        {
            //TODO: change filename - add step number to end
            //if filename already has step number, remove it.
            string ext = System.IO.Path.GetExtension(path);
            string dir = System.IO.Path.GetDirectoryName(path);
            string nt = System.IO.Path.GetFileNameWithoutExtension(path);//remove first extension
            string name = System.IO.Path.GetFileNameWithoutExtension(nt);//remove second extension

            path = String.Format("{0}{1}{2}.{3}{4}", dir, System.IO.Path.DirectorySeparatorChar, name, m_step, ext);
            //now return path without any modification
            return path;
        }

        /// <summary>
        /// Delete base step number from file pathname
        /// </summary>
        /// <param name="path">path for modifying</param>
        /// <returns>modified path</returns>
        private static string removeStepPath(string path)
        {
            //TODO: change filename - delete step number from end
            string ext = System.IO.Path.GetExtension(path);
            string dir = System.IO.Path.GetDirectoryName(path);
            string nt = System.IO.Path.GetFileNameWithoutExtension(path);//remove first extension
            string name = System.IO.Path.GetFileNameWithoutExtension(nt);//remove second extension
            nt = System.IO.Path.ChangeExtension(name, ext);//insert first extension
            path = String.Format("{0}{1}{2}", dir, System.IO.Path.DirectorySeparatorChar, nt);
            //now return path without any modification
            return path;
        }

        #endregion
    }
}
