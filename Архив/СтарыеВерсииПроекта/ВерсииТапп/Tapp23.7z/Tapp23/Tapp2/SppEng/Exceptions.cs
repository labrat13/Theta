﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SppCore
{
    /// <summary>
    /// General Base Exception class
    /// </summary>
    public class SeBaseException :Exception
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeBaseException()
            : base("Database work error.")
        {
        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeBaseException(string message):base(message)
        {
        }

        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeBaseException(string message, Exception inner)
            : base(message, inner)
        {
        }
        /// <summary>
        /// parametrized constructor
        /// </summary>
        /// <param name="msg">Message text</param>
        /// <param name="obj">broken object</param>
        protected SeBaseException(String msg, Object obj):base (String.Format("{0}\n\n Broken object: {1} [{2}]", msg, obj.GetType().FullName, obj.ToString()))
        {
            //this.Data.Add("exData", obj); ошибка - передаваемый аргумент не является сериализуемым
            BrokenObject = obj;
        }
        /// <summary>
        /// broken object
        /// </summary>
        private Object obj;

        /// <summary>
        /// Broken object thrown exception
        /// </summary>
        public Object BrokenObject
        {
            get { return obj; }
            set { obj = value; }
        }
    }
//***************************************************************
    /// <summary>
    /// General Code exception class
    /// </summary>
    public class SeCodeException :SeBaseException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeCodeException()
            : base("Error in database operation.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeCodeException(string message): base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeCodeException(string message, Exception inner) :base(message, inner)
        {

        }

        protected SeCodeException(String msg, Object obj)
            : base(msg, obj)
        {
        }
        
    }
    /// <summary>
    /// General Data exception class
    /// </summary>
    public class SeDataException : SeBaseException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeDataException()
            : base("Invalid data.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeDataException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeDataException(string message, Exception inner)
            : base(message, inner)
        {

        }
        protected SeDataException(String msg, Object obj)
            : base(msg, obj)
        {
        }
        
    }
    /// <summary>
    /// General Link exception class
    /// </summary>
    public class SeLinkException : SeBaseException
    {
        ///// <summary>
        ///// Copy of broken link
        ///// </summary>
        ////private CLink link;
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkException()
            : base("Invalid link.")
        {
        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeLinkException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkException(string message, Exception inner)
            : base(message, inner)
        {

        }

        ///// <summary>
        ///// Constructor with Message and CLink copy
        ///// </summary>
        ///// <param name="message">Message text</param>
        ///// <param name="brokenLink">Broken link</param>
        //protected SeLinkException(string message, CLink brokenLink)
        //    : base(String.Format("{0}\nBroken link: {1}", message, brokenLink))
        //{
        //    this.BrokenLink = brokenLink;
        //}

        protected SeLinkException(String msg, Object obj)
            : base(msg, obj)
        {
        }

    }
    //***************************************************************
    #region *** Code Exceptions ***
    /// <summary>
    /// Invalid use template as object exception class
    /// </summary>
    public class SeInvalidUseTemplateException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidUseTemplateException()
            : base("Invalid use template as object.")
        {
        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidUseTemplateException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidUseTemplateException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj"></param>
        public SeInvalidUseTemplateException(Object obj)
            : base("Invalid use template as object.", obj)
        {
        }

    }
    /// <summary>
    ///  Invalid use System object exception class
    /// </summary>
    public class SeInvalidUseSystemObjectException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidUseSystemObjectException():base("This operation allowed for User objects only. Current object is not User object.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidUseSystemObjectException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidUseSystemObjectException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeInvalidUseSystemObjectException(Object obj)
            : base("This operation allowed for User objects only. Current object is not User object.", obj)
        {
        }
    }
    /// <summary>
    ///  Invalid use User object exception class
    /// </summary>
    public class SeInvalidUseUserObjectException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidUseUserObjectException()
            : base("Object is not system object.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidUseUserObjectException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidUseUserObjectException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeInvalidUseUserObjectException(Object obj)
            : base("Object is not system object.", obj)
        {
        }
    }

    /// <summary>
    ///  Error creating database object exception class
    /// </summary>
    public class SeErrorCreateObjectException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeErrorCreateObjectException()
            : base("Can't create object (technical).")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeErrorCreateObjectException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeErrorCreateObjectException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeErrorCreateObjectException(Object obj)
            : base("Can't create object (technical).", obj)
        {
        }
    }
    /// <summary>
    /// Invalid argument exception class
    /// </summary>
    public class SeArgumentException : SeCodeException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeArgumentException():base("Invalid argument of function in metodology context.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeArgumentException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeArgumentException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeArgumentException(Object obj)
            : base("Invalid argument of function in metodology context.", obj)
        {
        }
    }
    #endregion

    #region *** Data Exceptions ***

    /// <summary>
    ///  Object not found exception class
    /// </summary>
    public class SeObjectNotFoundException : SeDataException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeObjectNotFoundException()
            : base("Object or class not found in database.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeObjectNotFoundException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeObjectNotFoundException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeObjectNotFoundException(Object obj)
            : base("Object or class not found in database.", obj)
        {
        }
    }
    /// <summary>
    /// Base need rollback operation exception class
    /// </summary>
    public class SeRollbackBaseException : SeDataException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeRollbackBaseException()
            : base("Error in operation. Rollback required.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeRollbackBaseException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeRollbackBaseException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeRollbackBaseException(Object obj)
            : base("Error in operation. Rollback required.", obj)
        {
        }
    }
    /// <summary>
    /// Invalid database state exception class
    /// </summary>
    public class SeInvalidBaseException : SeDataException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeInvalidBaseException():base("Unrecoverable error occured.  Last snapshot of database must be loaded.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeInvalidBaseException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeInvalidBaseException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeInvalidBaseException(Object obj)
            : base("Unrecoverable error occured.  Last snapshot of database must be loaded.", obj)
        {
        }
    }
    /// <summary>
    /// Mismatched data types exception class
    /// </summary>
    public class SeDataTypeMismatchException : SeDataException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeDataTypeMismatchException()
            : base("Source and destination datatype mismatch.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        public SeDataTypeMismatchException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeDataTypeMismatchException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with broken object
        /// </summary>
        /// <param name="obj">broken object</param>
        public SeDataTypeMismatchException(Object obj)
            : base("Source and destination datatype mismatch.", obj)
        {
        }
    }

    #endregion

    #region *** Link Exceptions ***
    /// <summary>
    ///  Source object already has link to other object  - exception class
    /// </summary>
    public class SeSourceAlreadyUsedException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeSourceAlreadyUsedException():base("Cannot create link between objects because source object already has any links to objects of target class. Object can't have more than one link to objects of target class.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeSourceAlreadyUsedException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeSourceAlreadyUsedException(string message, Exception inner)
            : base(message, inner)
        {

        }
        /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeSourceAlreadyUsedException(Object link)
            : base("Cannot create link between objects because source object already has any links to objects of target class. Object can't have more than one link to objects of target class.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeSourceAlreadyUsedException(string message, Object brokenLink)
            : base(message, brokenLink)
        {

        }

    }
    /// <summary>
    ///  Destination object already has link to other object  - exception class
    /// </summary>
    public class SeDestAlreadyUsedException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeDestAlreadyUsedException()
            : base("Can't create link between objects because target object already has link to another object of source class.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeDestAlreadyUsedException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeDestAlreadyUsedException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeDestAlreadyUsedException(Object link)
            : base("Can't create link between objects because target object already has link to another object of source class.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeDestAlreadyUsedException(string message, CLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Link between two objects/classes already exists - exception class
    /// </summary>
    public class SeLinkAlreadyExistsException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkAlreadyExistsException()
            : base("Link already exists and cannot be created.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeLinkAlreadyExistsException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkAlreadyExistsException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeLinkAlreadyExistsException(Object link)
            : base("Link already exists and cannot be created.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeLinkAlreadyExistsException(string message, CLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Between two objects/classes more than one link exists - exception class
    /// </summary>
    public class SeTooMoreLinksException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeTooMoreLinksException():base("More than one actual link found between linked objects.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeTooMoreLinksException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeTooMoreLinksException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeTooMoreLinksException(Object link)
            : base("More than one actual link found between linked objects.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeTooMoreLinksException(string message, CLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Link between two objects not found - exception class
    /// </summary>
    public class SeLinkNotFoundException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkNotFoundException()
            : base("Link not found.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeLinkNotFoundException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkNotFoundException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeLinkNotFoundException(Object link)
            : base("Link not found.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeLinkNotFoundException(string message, CLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    ///  Can't create link between objects. Need link between two classes first - exception class
    /// </summary>
    public class SeNeedClassesLinkException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeNeedClassesLinkException()
            : base("Can't create link between objects because classes not linked.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeNeedClassesLinkException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeNeedClassesLinkException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeNeedClassesLinkException(Object link)
            : base("Can't create link between objects because classes not linked.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeNeedClassesLinkException(string message, CLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    /// Can't create link. Restricted link only might be created - exception class
    /// </summary>
    public class SeRestrictedLinkOnlyException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeRestrictedLinkOnlyException()
            : base("Link between classes is Restricted. Link between objects can't have different state.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeRestrictedLinkOnlyException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeRestrictedLinkOnlyException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeRestrictedLinkOnlyException(Object link)
            : base("Link between classes is Restricted. Link between objects can't have different state.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeRestrictedLinkOnlyException(string message, Object broken)
            : base(message, broken)
        {

        }
    }
    /// <summary>
    /// Link states mismatch - exception class
    /// </summary>
    public class SeLinkStateMismatchException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeLinkStateMismatchException():base("Link states mismatch.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeLinkStateMismatchException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeLinkStateMismatchException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeLinkStateMismatchException(Object link)
            : base("Link states mismatch.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeLinkStateMismatchException(string message, CLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }
    /// <summary>
    /// Mutual link cannot be created - exception class
    /// </summary>
    public class SeMutualLinkErrorException : SeLinkException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SeMutualLinkErrorException()
            : base("Mutual link cannot be created.")
        {

        }
        /// <summary>
        /// Param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        private SeMutualLinkErrorException(string message)
            : base(message)
        {

        }
        /// <summary>
        /// param constructor
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="inner">Inner exception</param>
        public SeMutualLinkErrorException(string message, Exception inner)
            : base(message, inner)
        {

        }
                /// <summary>
        /// Constructor with CLink copy
        /// </summary>
        /// <param name="link">Broken link</param>
        public SeMutualLinkErrorException(Object link)
            : base("Mutual link cannot be created.", link)
        {

        }
        /// <summary>
        /// Constructor with Message and CLink copy
        /// </summary>
        /// <param name="message">Message text</param>
        /// <param name="brokenLink">Broken link</param>
        private SeMutualLinkErrorException(string message, CLink brokenLink)
            : base(message, brokenLink)
        {

        }
    }


    #endregion

}
