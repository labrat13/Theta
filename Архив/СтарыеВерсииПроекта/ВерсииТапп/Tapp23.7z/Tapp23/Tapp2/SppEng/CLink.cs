﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;

namespace SppCore
{
    /// <summary>
    /// class represent link between classes or objects
    /// </summary>
    public class CLink
    {
        /// <summary>
        /// Source ID
        /// </summary>
        private CID idFrom;
        /// <summary>
        /// Target ID
        /// </summary>
        private CID idTo;
        /// <summary>
        /// Link type 
        /// </summary>
        private LinkType linkType;
        /// <summary>
        /// Reference to target cell (for accelerate access to cell)
        /// </summary>
        private MCell tCell;
        /// <summary>
        /// Link state
        /// </summary>
        private HLinkState linkState;

        /// <summary>
        /// Default constructor
        /// </summary>
        public CLink()
        {
            idFrom = new CID();
            idTo = new CID();
            linkType = LinkType.Semantic;
            tCell = null;
            linkState = HLinkState.Normal;
        }
        /// <summary>
        /// parameter constructor
        /// </summary>
        /// <param name="objFrom">source object</param>
        /// <param name="objTo">target object</param>
        /// <param name="linktype">link type</param>
        /// <param name="objref">reference to target or null</param>
        public CLink(CID objFrom, CID objTo, LinkType linktype, HLinkState linkstate, MCell objref)
        {
            idFrom = new CID(objFrom);
            idTo = new CID(objTo);
            linkType = linktype;
            tCell = objref;
            linkState = linkstate;
        }
        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="copy">link to copy</param>
        public CLink(CLink copy)
        {
            idFrom = new CID(copy.SrcObjectID);
            idTo = new CID(copy.DestObjectID);
            linkType = copy.eLinkType;
            linkState = copy.eLinkState;
            tCell = null;
        }
        /// <summary>
        /// Source object ID
        /// </summary>
        [XmlIgnore]
        public CID SrcObjectID
        {
            get { return idFrom; }
            set { idFrom = value; }
        }
        /// <summary>
        /// Destination object ID
        /// </summary>
        [XmlIgnore]
        public CID DestObjectID
        {
            get { return idTo; }
            set { idTo = value; }
        }
        /// <summary>
        /// Link type code
        /// </summary>
        [XmlIgnore]
        public LinkType eLinkType
        {
            get { return linkType; }
            set { linkType = value; }
        }
        /// <summary>
        /// Link state code
        /// </summary>
        [XmlIgnore]
        public HLinkState eLinkState
        {
            get { return linkState; }
            set { linkState = value; }
        }
        /// <summary>
        /// Reference to target object or null
        /// </summary>
        [XmlIgnore]
        public MCell TargetCell
        {
            get { return tCell; }
            set { tCell = value; }
        }

        /// <summary>
        /// Link as text string for XML serializing and best readability
        /// </summary>
        public String LinkAsText
        {
            get { return this.ToString(); }
            set { parseStrValue(value); }
        }
        /// <summary>
        /// Return string representation of object
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("{0} {1} {2} {3}", this.idFrom.ToString(), this.linkState.ToString(), this.linkType.ToString(), this.idTo.ToString()); 
        }

        /// <summary>
        /// Create link to Unknown target
        /// </summary>
        /// <returns>Link</returns>
        public CLink createUnknownTargetLink()
        {
            CLink li = new CLink();
            li.idFrom = new CID(idFrom); //main object
            li.idTo = idTo.getID_Unknown();//target object - "неизвестно"
            li.linkState = linkState;
            li.linkType = linkType;
            li.TargetCell = null;
            return li;
        }

        /// <summary>
        /// Create link to Undefined object
        /// </summary>
        /// <returns>Link</returns>
        public CLink createUndefinedTargetLink()
        {
            CLink li = new CLink();
            li.idFrom = new CID(idFrom); //main object
            li.idTo = idTo.getID_Undefined();//target object - "Undefined"
            li.linkState = linkState;
            li.linkType = linkType;
            li.TargetCell = null;
            return li;
        }

        /// <summary>
        /// is Link's equals
        /// </summary>
        /// <param name="withStateAndType">true - check link states, false - check IDs only</param>
        /// <returns></returns>
        internal bool isEqual(CLink link, bool withStateAndType)
        {
            bool res;
            res = ((this.idFrom.isEqual(link.idFrom)) && (this.idTo.isEqual(link.idTo)));
            if (withStateAndType == true) res = res && ((this.linkState == link.linkState) && (this.linkType == link.linkType));
            return res;
        }

        /// <summary>
        /// Predicate - Sorting links by LinkState field
        /// </summary>
        /// <param name="x">X link</param>
        /// <param name="y">Y link</param>
        /// <returns>1, 0, -1</returns>
        /// <remarks>Sorting order Top to bottom: Restricted, Normal, Deleted, Undefined</remarks>
        public static int SortByLinkState(CLink x, CLink y)
        {
            if (x == null)
            {
                if (y == null) return 0; else return -1;
            }
            else
            {
                if (y == null) return 1;
                else
                {
                    if (x.eLinkState > y.eLinkState) return 1;
                    else if (x.eLinkState == y.eLinkState) return 0;
                    else return -1;//x < y
                }
            }
        }

        /// <summary>
        /// parse string representation of link
        /// </summary>
        /// <param name="str">string representation of link</param>
        private void parseStrValue(String str)
        {
            //parse string    256:0 Normal Semantic 258:0
            String[] strs = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            this.SrcObjectID.IDstr = strs[0];
            this.eLinkState  = (HLinkState)TypeDescriptor.GetConverter(typeof(HLinkState)).ConvertFromString(strs[1]);
            this.eLinkType = (LinkType)TypeDescriptor.GetConverter(typeof(LinkType)).ConvertFromString(strs[2]);
            this.DestObjectID.IDstr = strs[3];
        }

        /// <summary>
        /// Return copy of current link
        /// </summary>
        /// <returns>copy of current link</returns>
        public CLink getCopy()
        {
            return new CLink(this);
        }

        #region ** XML function ***
        /// <summary>
        /// save data to XML file
        /// </summary>
        /// <param name="filename">name of XML file</param>
        public void SaveToXML(string filename)
        {
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            writer.Serialize(file, this);
            file.Close();
        }
        /// <summary>
        /// load data from XML file
        /// </summary>
        /// <param name="filename">name of XML file</param>
        public static CLink LoadFromXML(string filename)
        {
            CLink li = new CLink();
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(li.GetType());
            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            li = (CLink)reader.Deserialize(file);
            file.Close();
            return li;
        }
        #endregion
    }
}
