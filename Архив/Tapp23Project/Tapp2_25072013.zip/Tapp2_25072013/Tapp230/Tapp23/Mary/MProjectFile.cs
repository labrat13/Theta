﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;
using System.IO;

namespace Mary
{
    /// <summary>
    /// Представляет файл проекта.
    /// </summary>
    public class MProjectFile
    {
        #region Fields
        /// <summary>
        /// Project creation date
        /// </summary>
        private DateTime m_cdate;
        /// <summary>
        /// Database name
        /// </summary>
        private string m_dbname;
        /// <summary>
        /// Database server path
        /// </summary>
        private string m_dbServerPath;
        /// <summary>
        /// Project description
        /// </summary>
        private string m_descr;
        /// <summary>
        /// Engine major version number
        /// </summary>
        private int m_ver;
        /// <summary>
        /// Engine minor version number
        /// </summary>
        private int m_subver;
        /// <summary>
        /// Project name
        /// </summary>
        private string m_name;
        /// <summary>
        /// User name of database server account
        /// </summary>
        private string m_uname;
        /// <summary>
        /// User password of database server account
        /// </summary>
        private string m_upass;
        /// <summary>
        /// Project file pathname
        /// </summary>
        private string m_file;
        /// <summary>
        /// Project connection timeout, seconds
        /// </summary>
        private int m_timeout;
        #endregion
        /// <summary>
        /// Default constructor
        /// </summary>
        public MProjectFile()
        {
            m_cdate = DateTime.Now;
            m_dbname = "";
            m_dbServerPath = "";
            m_descr = "";
            m_file = "";
            m_name = "";
            m_subver = MVersion.VersionSubID;
            m_ver = MVersion.VersionID;
            m_uname = "";
            m_upass = "";
        }

        #region Properties
        /// <summary>
        /// Project name
        /// </summary>
        [Category("Description"), Description("Project name")]
        public string ProjectName
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }

        /// <summary>
        /// Project description
        /// </summary>
        [Category("Description"), Description("Project description")]
        public string Description
        {
            get
            {
                return m_descr;
            }
            set
            {
                m_descr = value;
            }
        }

        /// <summary>
        /// Project creation date
        /// </summary>
        [Category("Description"), Description("Project initial date")]
        public DateTime CreationDate
        {
            get
            {
                return m_cdate;
            }
            set
            {
                m_cdate = value;
            }
        }
        /// <summary>
        /// Engine major version number
        /// </summary>
        [Category("Description"), Description("Project engine major version")]
        public int EngineVersion
        {
            get
            {
                return m_ver;
            }
            set
            {
                m_ver = value;
            }
        }

        /// <summary>
        /// Engine minor version number
        /// </summary>
        [Category("Description"), Description("Project engine minor version")]
        public int EngineSubVersion
        {
            get
            {
                return m_subver;
            }
            set
            {
                m_subver = value;
            }
        }


        /// <summary>
        /// Project file pathname
        /// </summary>
        [XmlIgnore]
        [Category("Description"), Description("Project file pathname")]
        public string ProjectFilePath
        {
            get
            {
                return m_file;
            }
            set
            {
                m_file = value;
            }
        }

        /// <summary>
        /// Database server path
        /// </summary>
        [Category("Database"), Description("Database server path")]
        public string DatabaseServerPath
        {
            get
            {
                return m_dbServerPath;
            }
            set
            {
                m_dbServerPath = value;
            }
        }

        /// <summary>
        /// Database name
        /// </summary>
        [Category("Database"), Description("Project database name")]
        public string DatabaseName
        {
            get
            {
                return m_dbname;
            }
            set
            {
                m_dbname = value;
            }
        }

        /// <summary>
        /// User name of database server account
        /// </summary>
        [Category("Database"), Description("Database server account user name. For project creation, user must have dbcreator permission on SQL server")]
        public string UserName
        {
            get
            {
                return m_uname;
            }
            set
            {
                m_uname = value;
            }
        }

        /// <summary>
        /// User password of database server account
        /// </summary>
        [Category("Database"), Description("Database server account user password")]
        public string UserPassword
        {
            get
            {
                return m_upass;
            }
            set
            {
                m_upass = value;
            }
        }

        /// <summary>
        /// Connection timeout, sec
        /// </summary>
        [Category("Database"), Description("Database server connection timeout in seconds")]
        public int Timeout
        {
            get
            {
                return m_timeout;
            }
            set
            {
                m_timeout = value;
            }
        }


 
        #endregion



        





        /// <summary>
        /// Create or overwrite project file with current path, write values, close project file.
        /// </summary>
        /// <remarks>Без лога, или проверять его существование!</remarks>
        public void Save()
        {
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StreamWriter file = new System.IO.StreamWriter(this.m_file);
            writer.Serialize(file, this);
            file.Close();
        }

        /// <summary>
        /// Open project file, load values, close project file.
        /// </summary>
        /// <remarks>Без лога, или проверять его существование!</remarks>
        public static MProjectFile Load(string filename)
        {
            //load file
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(typeof(MProjectFile));
            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            MProjectFile set = (MProjectFile)reader.Deserialize(file);
            file.Close();
            set.m_file = filename;
            return set;
        }

        /// <summary>
        /// Get main project directory from project file pathname
        /// </summary>
        /// <returns></returns>
        public string getProjectDirectory()
        {
            return Path.GetDirectoryName(this.m_file);
        }

        /// <summary>
        /// Return true if current project has database server path 
        /// </summary>
        /// <returns></returns>
        /// <exception cref="">None</exception>
        public bool IsDBused()
        {
            return !(String.IsNullOrEmpty(m_dbServerPath));
        }

        /// <summary>
        /// Return first 16 chars of project name
        /// </summary>
        /// <returns></returns>
        public string getProjectName16()
        {
            string res = this.m_name.Trim();
            if (res.Length > 16)
                res = res.Remove(16);
            return res;
        }

        /// <summary>
        /// Check project parameters and raise exceptions if not valid
        /// </summary>
        /// <remarks>Можно добавить проверку допустимых символов.</remarks>
        public void checkValues()
        {
            //1) check project name exists
            if (String.IsNullOrEmpty(this.m_name))
                throw new Exception("Invalid project name");
            //cut project name to 256
            if (m_name.Length > 256) m_name = m_name.Substring(0, 256);
            //2) check project description
            if (String.IsNullOrEmpty(m_descr))
                m_descr = ""; //если нуль, то пусть лучше будет пустая строка
            else
            {
                //cut to 8192 chars
                if (m_descr.Length > 8192) m_descr = m_descr.Substring(0, 8192);
            }
            //3) check database server path
            if (String.IsNullOrEmpty(m_dbServerPath))
                m_dbServerPath = "";  //если нуль, то пусть лучше будет пустая строка
            //PRJNODB:
            if (IsDBused())
            {
                //4) check database name
                if (String.IsNullOrEmpty(m_dbname))
                    m_dbname = getProjectName16();
                //5) check user name
                if (String.IsNullOrEmpty(m_uname)) throw new Exception("User login invalid");
                //6) check user password
                if (String.IsNullOrEmpty(m_upass)) throw new Exception("User password invalid");
                //7) check tmeout value
                if (m_timeout < 30) m_timeout = 30;
            }
            return;
        }






    }
}
