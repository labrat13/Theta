﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security.AccessControl;

namespace Mary
{
    /// <summary>
    /// Maintains project file system and project structure
    /// </summary>
    public class MProject
    {
        /// <summary>
        /// Project file 
        /// </summary>
        private MProjectFile m_prjFile;
        /// <summary>
        /// Backref to container
        /// </summary>
        private MEngine m_container;

        public const string m_SnapshotFolderName = "Snapshots";
        public const string m_LogFolderName = "Logs";
        public const string m_MethodFolderName = "Methods";
        public const string m_ResourceFolderName = "Resources";

        /// <summary>
        /// Param constructor
        /// </summary>
        public MProject(MEngine me)
        {
            m_container = me;
        }


#region Properties
        /// <summary>
        /// Project folder path
        /// </summary>
        public string ProjectFolderPath
        {
            get
            {
                return m_prjFile.getProjectDirectory();
            }
        }
        /// <summary>
        /// Project file reference
        /// </summary>
        public MProjectFile ProjectFile
        {
            get { return m_prjFile; }
            set
            {
                //set project file ref
                m_prjFile = value;
            }
        }
        /// <summary>
        /// Is this project use database?
        /// </summary>
        public bool UsesDatabase
        {
            get { return m_prjFile.IsDBused(); }
        }

        /// <summary>
        /// Snapshot folder path
        /// </summary>
        public string SnapshotFolderPath
        {
            get { return Path.Combine(ProjectFolderPath, m_SnapshotFolderName); } 
        }
        /// <summary>
        /// Resource main folder path
        /// </summary>
        public string ResourceFolderPath
        {
            get { return Path.Combine(ProjectFolderPath, m_ResourceFolderName); } 
        }
        /// <summary>
        /// Log folder path
        /// </summary>
        public string LogFolderPath
        {
            get { return Path.Combine(ProjectFolderPath, m_LogFolderName); } 
        }
        /// <summary>
        /// Method folder path
        /// </summary>
        public string MethodFolderPath
        {
            get { return Path.Combine(ProjectFolderPath, m_MethodFolderName); }
        }


#endregion
        /// <summary>
        /// NFT-Create project folders and files
        /// </summary>
        /// <param name="pfile">Fullfilled project file</param>
        /// <param name="rootDir">root directory</param>
        /// <remarks>Без лога, или проверять его существование!</remarks>
        public static void CreateProjectFolder(MProjectFile pfile, string rootDir)
        {
            //check file permissions
            if (!Directory.Exists(rootDir)) throw new Exception("Directory not exists");
            //DirectorySecurity ds = Directory.GetAccessControl(rootDir);
            //ds.

            //create main directory
            string maindir = Path.Combine(rootDir, pfile.getProjectName16());
            Directory.CreateDirectory(maindir);
            //create subdirectories
            Directory.CreateDirectory(Path.Combine(maindir, MProject.m_LogFolderName));
            Directory.CreateDirectory(Path.Combine(maindir, MProject.m_MethodFolderName));
            Directory.CreateDirectory(Path.Combine(maindir, MProject.m_ResourceFolderName));
            Directory.CreateDirectory(Path.Combine(maindir, MProject.m_SnapshotFolderName));
            //create files
            string fname = String.Format("{0}.tapj", pfile.getProjectName16());
            pfile.ProjectFilePath = Path.Combine(maindir, fname);
            pfile.Save();
        }
        /// <summary>
        /// NT- Delete folder and all items within
        /// </summary>
        /// <param name="p"></param>
        internal static void DeleteFolder(string p)
        {
            Directory.Delete(p, true);
        }

    }
}
