﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mary
{
    /// <summary>
    /// Порядковый код сообщения. Соответствует функции или событию.
    /// </summary>
    public enum MMessageCode: uint
    {
        /// <summary>
        /// Special value
        /// </summary>
        Nothing = 0,



    }
}
