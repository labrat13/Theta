﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mary
{
    /// <summary>
    /// Class contains some utility functions
    /// </summary>
    public static class MUtility
    {
        /// <summary>
        /// NR-Convert bytes to hex string
        /// </summary>
        /// <param name="byteArray"></param>
        /// <returns>Hex string</returns>
        public static string BytesToHex(byte[] byteArray)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// NR-Convert hex string to bytes
        /// </summary>
        /// <param name="hexStr"></param>
        /// <returns></returns>
        public static byte[] HexToBytes(string hexStr)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// NFT-Check that char is hex digit 0..9,A..H
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        ///<exception cref=""></exception>
        public static bool isHexDigit(char c)
        {
            if (Char.IsDigit(c)) return true;
            char t = Char.ToUpper(c);
            if ((t == 'A') || (t == 'B') || (t == 'C') || (t == 'D') || (t == 'E') || (t == 'F')) return true;
            return false;
        }

        /// <summary>
        /// Remove chars that non-safe to XML parsing
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static string createXmlSafeString(string s)
        {
            Char rep = '?';
            string t = s.Replace('<', rep);
            string tt = t.Replace('>', rep);
            string ttt = tt.Replace('&', rep);
            return ttt.Replace('"', rep);
        }

    }
}
