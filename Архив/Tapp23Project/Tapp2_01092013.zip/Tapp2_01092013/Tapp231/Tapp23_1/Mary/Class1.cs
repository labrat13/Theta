using System;
using System.Collections.Generic;
using System.Text;

namespace Mary
{
    public class Class1
    {
    }
}
