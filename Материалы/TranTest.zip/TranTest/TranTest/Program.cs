﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;

namespace TranTest
{
    class Program
    {
        //тест вложенных транзакций в Аксцесс: успешно.
        //но мои стандартные приемы работы с функциями в адаптере БД совершенно не подходят.
        //их надо переделывать:
        //- объект транзакции надо хранить в вызывающем коде а не внутри объекта адаптера, как сейчас.
        //- первый объект транзакции получать из объекта соединения вызовом m_connection.BeginTransaction();
        //- последующие вложенные транзакции получать вызовом OleDbTransaction tran2 = tran1.Begin();
        //- каждой функции-запросу надо передавать объект текущей транзакции.
        //- значит, либо каждая функция кода должна хранить в стеке собственный начатый объект транзакции,
        //  и сама завершать начатую ей транзакцию,
        //  либо в код адаптера надо добавлять очередь начатых транзакций,
        //  чтобы он выдавал клиенту самую свежую (текущую) транзакцию. 
        //  - тогда и объект транзакции выдавать не надо, но могут быть проблемы с очередью транзакций.
        //    если я забуду завершить транзакцию внутри начавшей ее функции.
        //- объект команды использует объект транзакции, поэтому теперь нельзя создавать одну команду на все случаи.
        //  теперь придется создавать команду при каждом вызове.
        //  - или заменять в ней старый объект транзакции на текущий?
        //- в любом случае, это все еще надо проверить. Потребуются эксперименты и простой текстовый лог.
        
        static void Main(string[] args)
        {
            //by default, IsolationLevel = ReadCommitted - значит, читать уже подтвержденные данные.
            //однако тут в тесте успешно изменяются неподтвержденные данные.
            //возможно, они не будут читаться, а только изменяться.
            //тут надо больше исследований на эту тему.
            
            OleDbConnection m_connection;
            String connectionString = createConnectionString("db1.mdb", false);
            //1 открыть БД
            m_connection = new OleDbConnection(connectionString);
            m_connection.Open();

            //2 начать транзакцию 1
            OleDbTransaction tran1 = m_connection.BeginTransaction();
            //добавить запись в таблицу 
            AddRow(tran1, "tran1", "value1");

            //3 начать транзакцию 2
            //OleDbTransaction tran2 = m_connection.BeginTransaction();//error: OleDbConnection does not support parallel transactions.
            OleDbTransaction tran2 = tran1.Begin();
            //добавить запись в таблицу 
            AddRow(tran2, "tran2", "value2");
            //изменить запись в таблице
            ChangeRow(tran2, "tran1", "value3");

            //4 подтвердить транзакцию 2
            tran2.Commit();

            //5 начать транзакцию 3
            OleDbTransaction tran3 = tran1.Begin();
            AddRow(tran3, "tran3", "value4");
            //изменить запись в таблице
            ChangeRow(tran3, "tran1", "value5");

            //6 отменить транзакцию 3
            tran3.Rollback();

            //7 начать транзакцию 4
            OleDbTransaction tran4 = tran1.Begin();
            AddRow(tran4, "tran4", "value6");
            //изменить запись в таблице
            ChangeRow(tran4, "tran1", "value7");

            //8 подтвердить транзакцию 4
            tran4.Commit();

            //9 подтвердить транзакцию 1
            tran1.Commit();

            m_connection.Close();

            return;

            //results in tablica table:
            //id	val1	val2
            //1	tran1	value7
            //2	tran2	value2
            //4	tran4	value6

        }

        /// <summary>
        /// NT-Создать строку соединения с БД
        /// </summary>
        /// <param name="dbFile">Путь к файлу БД</param>
        public static string createConnectionString(string dbFile, bool ReadOnly)
        {
            //Provider=Microsoft.Jet.OLEDB.4.0;Data Source="C:\Documents and Settings\salomatin\Мои документы\Visual Studio 2008\Projects\RadioBase\радиодетали.mdb"
            OleDbConnectionStringBuilder b = new OleDbConnectionStringBuilder();
            b.Provider = "Microsoft.Jet.OLEDB.4.0";
            b.DataSource = dbFile;
            //это только для БД на незаписываемых дисках
            if (ReadOnly)
            {
                b.Add("Mode", "Share Deny Write");
            }
            //user id and password can specify here
            return b.ConnectionString;
        }

        private static void AddRow(OleDbTransaction tran, string val1, string val2)
        {
            String query = String.Format("INSERT INTO tablica (val1, val2) VALUES ('{0}', '{1}');", val1, val2);
            OleDbCommand cmd = new OleDbCommand(query, tran.Connection, tran);
            cmd.ExecuteNonQuery();
        }

        private static void ChangeRow(OleDbTransaction tran, string val1, string val2)
        {
            String query = String.Format("UPDATE tablica SET val2 = '{0}' WHERE (tablica.val1 = '{1}');", val2, val1);
            OleDbCommand cmd = new OleDbCommand(query, tran.Connection, tran);
            cmd.ExecuteNonQuery();
        }
    }
}
