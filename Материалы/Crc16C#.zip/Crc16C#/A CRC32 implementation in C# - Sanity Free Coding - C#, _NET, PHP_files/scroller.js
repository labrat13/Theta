if (navigator.appName.indexOf("Microsoft") == -1)
	{
		HTMLElement.prototype.attachEvent = function (sType, fHandler) {
		   var shortTypeName = sType.replace(/on/, "");
		   fHandler._ieEmuEventHandler = function (e) {
			  window.event = e;
			  return fHandler();
		   };
		   this.addEventListener(shortTypeName, fHandler._ieEmuEventHandler, false);
		};

		HTMLElement.prototype.detachEvent = function (sType, fHandler) {
		   var shortTypeName = sType.replace(/on/, "");
		   if (typeof fHandler._ieEmuEventHandler == "function")
			  this.removeEventListener(shortTypeName, fHandler._ieEmuEventHandler, false);
		   else   // we can always try :-)
			  this.removeEventListener(shortTypeName, fHandler, true);
		};
	}

	function Scroller() {

		var This = this;
		this.obj = null;
		this.objHeight = 0;
		this.objFullHeight = 0;
		this.scrollTop = 0;
		this.DragY = 0;
		this.intrvl = null;
		this.iScroller = null;
		this.oArrowTop = null;
		this.oArrowBottom = null;
		this.DraggedLineContainer = null;
		this.Spacer = null;
		this.iIntrvlCount = 0;
		this.oScroller = null;
		this.DraggedLine = null;
		this.imgArrowTop = "/images/su.gif";
		this.imgArrowTopHover = "/images/su.gif";
		this.imgArrowBottom = "/images/sd.gif";
		this.imgArrowBottomHover = "/images/su.gif";
		this.imgBgScroller = "/images/scbg.gif";
		this.scrollerBorder = "#d0d0d0";
		this.scrollerBgColor = "#222f3c";
		this.scrollerInnerBgColor = "#222f3c";
		this.scrollerInnerBorderColor = "#6988a2";
		this.iArrowWidth = 7;
		this.iArrowHeight = 6;
		this.isIE = navigator.appName.indexOf("Microsoft") > -1;

		this.FullHeight = 0;
		this.iInnerScrollHeight = 0;
		this.iDistancePerPixel = 0;
		this.iSpaceFromTop = 0;
		
		if(this.isIE) {
			this.OnDrag = function() {
				return false;
			}
		}

		this.SetContinuing = function(fFunc) {
			fFunc();
			This.iIntrvlCount = 0;
			This.intrvl = setInterval(function() {
					fFunc();
					This.iIntrvlCount++;
					if (This.iIntrvlCount > 10 && !This.isIE)
						clearInterval(This.intrvl);
			},150);
		}

		this.ScrollUp = function() {
			if (This.obj.scrollTop > 0)
				if (This.obj.scrollTop > 10)
					This.obj.scrollTop -= 10;
				else
					This.obj.scrollTop = 0;
			This.Update();
		}

		this.ScrollDown = function() {
			if (This.obj.scrollTop < This.obj.scrollHeight)
				if (This.obj.scrollTop < (This.obj.scrollHeight - 10))
					This.obj.scrollTop += 10;
				else
					This.obj.scrollTop = This.obj.scrollHeight;

			This.Update();
		}


		this.Apply = function(sId,sIdToAppendScroller) {

			This.obj = document.getElementById(sId);
			This.obj.scrollTop = 0;
			This.iScroller = This.obj.scrollHeight < This.obj.offsetHeight ? This.obj.offsetHeight : This.obj.scrollHeight; 
			// alert(This.iScroller + "--" + This.obj.offsetHeight + "--" + This.obj.scrollTop);

			This.oScroller = document.getElementById(sIdToAppendScroller);
				This.oScroller.innerHTML = "";
				This.oScroller.style.height = (This.obj.offsetHeight) - (This.isIE?2:2) + "px";
				This.oScroller.style.width = This.isIE ? "7px" : "7px";
				This.oScroller.style.border = "1px solid "+ This.scrollerBorder;
				This.oScroller.style.backgroundColor = This.scrollerBgColor;
			//if (!This.isIE && This.obj.tagName == "TEXTAREA")
			//	This.oScroller.style.marginTop = "1px";
			
			This.oArrowTop = document.createElement("IMG");
			    This.oArrowTop.src = This.imgArrowTop;
				This.oArrowTop.style.display = "block";
				This.oArrowTop.style.width = This.iArrowWidth;
				This.oArrowTop.style.height = This.iArrowHeight;
				This.oArrowTop.attachEvent("onmousedown",function() { This.SetContinuing(This.ScrollUp) });
				This.oArrowTop.onmouseout = function() {clearInterval(This.intrvl)}
				This.oArrowTop.onmouseup = function() {clearInterval(This.intrvl)}

			This.oArrowBottom = document.createElement("IMG");
			    This.oArrowBottom.src = This.imgArrowBottom;
				This.oArrowBottom.style.width = This.iArrowWidth;
				This.oArrowBottom.style.height = This.iArrowHeight;
				This.oArrowBottom.attachEvent("onmousedown",function() { This.SetContinuing(This.ScrollDown) });
				This.oArrowBottom.onmouseout = function() {
					if (This.DraggedLineContainer.style.marginBottom == "0px")
					{
						clearInterval(This.intrvl);
					}
					
				}
				This.oArrowBottom.onmouseup = function() {clearInterval(This.intrvl)}

			This.DraggedLineContainer = document.createElement("DIV");
			This.DraggedLineContainer.style.width = "7px";
			This.DraggedLineContainer.style.background = "url("+This.imgBgScroller+")";
			This.DraggedLineContainer.style.height = (This.obj.offsetHeight - (This.iArrowHeight * 2) - 2) + "px"; // 2 is the border of the arrows			
			
			This.Spacer = document.createElement("DIV");
			This.DraggedLine = document.createElement("DIV");
			This.DraggedLine.id = "scc";
			
			This.oScroller.appendChild(This.oArrowTop);
			This.oScroller.appendChild(This.DraggedLineContainer);

			This.DraggedLineContainer.appendChild(This.Spacer);
			This.DraggedLineContainer.appendChild(This.DraggedLine);
			This.oScroller.appendChild(This.oArrowBottom);
			if (This.obj.tagName == "TEXTAREA")
			{
				This.obj.onkeypress = This.Update;
				This.obj.onkeyup = This.Update;
			}
		}

		this.Update = function() {

			This.iScroller = This.obj.scrollHeight < This.obj.offsetHeight ? This.obj.offsetHeight : This.obj.scrollHeight;
			This.DraggedLineContainer.style.marginBottom = "0px";
			This.FullHeight = This.DraggedLineContainer.offsetHeight - 2;
			// This.DraggedLineContainer.style.height = This.FullHeight.toString() + "px";

			// alert("obj.offsetHeight:"+This.obj.offsetHeight + "\nThis.iScroller:" + This.iScroller + "\nThis.FullHeight:" + This.FullHeight + "\nThis.obj.scrollTop:"+ This.obj.scrollTop);


			if (This.iScroller > This.obj.offsetHeight)
			{
				This.Spacer.style.visibility = This.DraggedLine.style.visibility = "visible";
				This.DraggedLine.style.width = "5px";
				This.DraggedLine.style.marginLeft = "1px";
				This.DraggedLine.style.borderTop = "1px solid " + This.scrollerInnerBorderColor;
				This.DraggedLine.style.borderBottom = "1px solid " + This.scrollerInnerBorderColor;
				//This.DraggedLine.style.backgroundColor = This.scrollerInnerBgColor;
				This.DraggedLine.onmousedown = This.ScrollMove;

				

				This.iInnerScrollHeight = (This.obj.offsetHeight / This.iScroller) * This.FullHeight;
					This.DraggedLine.style.height = This.iInnerScrollHeight.toString() + "px";
					This.iDistancePerPixel = This.obj.offsetHeight/This.iInnerScrollHeight;

				This.iSpaceFromTop = (This.obj.scrollTop / This.iDistancePerPixel);
					This.Spacer.style.height = This.iSpaceFromTop + "px";
					This.scrollTop = This.iSpaceFromTop;

			} else {
				This.Spacer.style.visibility = This.DraggedLine.style.visibility = "hidden";

			}
		}

		this.ScrollMove = function() {
			var e = arguments[0] || event;
			This.DragY = e.clientY;
			document.body.attachEvent("onselectstart",This.SelectStartFalse);
			if (This.isIE)
			{
				document.body.onmousemove = This.Move;
				document.body.onmouseup = This.ScrollStop;
			} else {
				window.onmousemove = This.Move;
				window.onmouseup = This.ScrollStop;
			}
		}

		this.SelectStartFalse = function() {
			return false;
		}
		this.ScrollStop = function() {
			document.body.detachEvent("onselectstart",This.SelectStartFalse);
			if (This.isIE)
			{
				document.body.onmousemove = null;
				document.body.onmouseup = null;
			} else {
				window.onmousemove = null;
				window.onmouseup = null;
			}
		}

		this.Move = function() {
			var e = arguments[0] || event;
			if (This.obj.scrollHeight > (This.iDistancePerPixel * (This.scrollTop + (e.clientY - This.DragY))) && (This.scrollTop + (e.clientY - This.DragY)) > 0 && e.clientY != This.DragY)
			{
				This.obj.scrollTop = This.iDistancePerPixel * (This.scrollTop + (e.clientY - This.DragY));
				This.Update();
			}
			This.DragY = e.clientY;
		}
	}
	
	onload = function() {
		oS = new Scroller(true);
		oS.Apply('txt','scroller');
		oS.Update();
	}