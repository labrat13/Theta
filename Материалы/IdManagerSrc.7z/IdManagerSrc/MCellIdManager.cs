using System;
using System.Collections.Generic;
using System.Text;

namespace Walk
{
    /// <summary>
    /// ��������� ������� ��������������� ��� ����������� ����� 
    /// </summary>
    /// <remarks></remarks>
    /// <seealso cref=""/>
    public class MCellIdManager: MElementIdManager
    {
        #region *** Fields ***

        #endregion
        /// <summary>
        /// �����������
        /// </summary>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public MCellIdManager()
        {
        }

        #region *** Properties ***

        #endregion

        ///// <summary>
        ///// Override this function in child classes to get max const id
        ///// </summary>
        ///// <returns></returns>
        //public override int OnGetMaxConstElementId()
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}
        ///// <summary>
        ///// Override this function in child classes to get max temp id
        ///// </summary>
        ///// <returns></returns>
        //public override int OnGetMaxTempElementId()
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}

        /// <summary>
        /// Get string representation of object.
        /// </summary>
        /// <returns>Return string representation of object.</returns>
        /// <remarks></remarks>
        /// <seealso cref=""/>
        public override string ToString()
        {
            throw new NotImplementedException();
        }

    }
}
