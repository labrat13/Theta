using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.IO;

namespace MyAddin1
{
    public class ClassItem: Item
    {

        /// <summary>
        /// Base classes
        /// </summary>
        public List<Item> Bases;
        public List<Item> ImplemInterfaces;
        public List<Item> Properties;
        public List<Item> Fields;
        public List<Item> Functions;

        /// <summary>
        /// Project filename
        /// </summary>
        public string ProjectFile;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="cc"></param>
        public ClassItem(CodeClass cc)
        {
            this.MakeAccessString(cc.Access, false, cc.IsAbstract, false, false, false);
            this.parseAttributes(cc.Attributes);
            //this.Bases
            this.DocComment = cc.DocComment;
            this.ParseDocComment(cc.DocComment);
            this.FullName = cc.FullName;
            //this.ImplemInterfaces
            this.Name = cc.Name;
            this.ProjectFile = cc.ProjectItem.Name;
            FillMembers(cc.Members);//this.Properties//this.Functions//this.Fields
        }
        /// <summary>
        /// Fill lists with fields, props and functions
        /// </summary>
        /// <param name="cel"></param>
        private void FillMembers(CodeElements cel)
        {
            //create lists if it's not created 
            if (this.Functions == null) this.Functions = new List<Item>();
            if (this.Properties == null) this.Properties = new List<Item>();
            if (this.Fields == null) this.Fields = new List<Item>();
            if (this.Bases == null) this.Bases = new List<Item>();
            if (this.ImplemInterfaces == null) this.ImplemInterfaces = new List<Item>();

            foreach (CodeElement ce in cel)
            {
                if (ce.Kind == vsCMElement.vsCMElementFunction)
                {
                    FuncItem fi = new FuncItem((CodeFunction) ce);
                    this.Functions.Add(fi);
                }
                else if (ce.Kind == vsCMElement.vsCMElementProperty)
                {
                    PropItem pi = new PropItem((CodeProperty) ce);
                    this.Properties.Add(pi);

                }
                else if (ce.Kind == vsCMElement.vsCMElementVariable)
                {
                    FieldItem fi = new FieldItem((CodeVariable)ce);
                    this.Fields.Add(fi);
                }
            }
        }

        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public override void MakeHtml()
        {
            StreamWriter sw = new StreamWriter(this.FileName, false, Encoding.UTF8);
            sw.WriteLine("<html><head><title>{0} class</title></head><body>", this.FullName);
            sw.WriteLine(Item.makeHeader());
            sw.WriteLine("<h2>{0} class</h2>", this.Name);
            sw.WriteLine("<P>");
            sw.WriteLine(this.makeAttrHtmlString());
            sw.WriteLine("<b>{0} {1}</b>", this.Access, this.FullName);
            sw.WriteLine("</P>");
            sw.Write(this.XmlMakeDescription(false, false, false));
            if (this.Fields.Count > 0)
            {
                sw.WriteLine("<h3>Fields</h3>");
                this.Fields.Sort(Item.sortByItemName);
                
                sw.Write(Item.makeTableItems("", this.Fields, true));
                foreach (FieldItem ci in this.Fields)
                {
                    //sw.WriteLine("<a href=\"{0}\">{1}</a> {2}<br>", ci.FileName, ci.Name, ci.DocComment);
                    ci.MakeHtml();
                }
            }
            if (this.Functions.Count > 0)
            {
                sw.WriteLine("<h3>Functions</h3>");
                this.Functions.Sort(Item.sortByItemName);
                sw.Write(Item.makeTableItems("", this.Functions, true));
                foreach (FuncItem ci in this.Functions)
                {
                    //sw.WriteLine("<a href=\"{0}\">{1}</a> {2}<br>", ci.FileName, ci.Name, ci.DocComment);
                    ci.MakeHtml();
                }
            }
            if (this.Properties.Count > 0)
            {
                sw.WriteLine("<h3>Properties</h3>");
                this.Properties.Sort(Item.sortByItemName);
                sw.Write(Item.makeTableItems("", this.Properties, true));
                foreach (PropItem ci in this.Properties)
                {
                    //sw.WriteLine("<a href=\"{0}\">{1}</a> {2}<br>", ci.FileName, ci.Name, ci.DocComment);
                    ci.MakeHtml();
                }
            }
            sw.WriteLine(Item.makeFooter());
            sw.WriteLine("</body></html>");
            sw.Close();
        }
    }
}
