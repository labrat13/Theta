using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.IO;

namespace MyAddin1
{
    public class EnumItem:Item
    {
        /// <summary>
        /// Base classes
        /// </summary>
        public List<Item> Bases;
        /// <summary>
        /// Enum code listing
        /// </summary>
        public string codeText;
        /// <summary>
        /// Project filename
        /// </summary>
        public string ProjectFile;
        /// <summary>
        /// Enum members list
        /// </summary>
        public List<Item> Members;
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="ce">code element</param>
        public EnumItem(CodeEnum ce)
        {
            this.MakeAccessString(ce.Access, false, false, false, false, false);
            this.parseAttributes(ce.Attributes);
            this.Bases = new List<Item>();
            //TODO: fill list of bases after
            this.codeText = "";
            this.DocComment = ce.DocComment;
            this.ParseDocComment(ce.DocComment);
            this.FullName = ce.FullName;
            fillFieldsList(ce.Members);
            this.Name = ce.Name;
            this.ProjectFile = ce.ProjectItem.Name;
        }
        /// <summary>
        /// Fill fields list
        /// </summary>
        /// <param name="cel"></param>
        private void fillFieldsList(CodeElements cel)
        {
            this.Members = new List<Item>();
            foreach(CodeElement ce in cel)
            {
                if (ce.Kind == vsCMElement.vsCMElementVariable)
                {
                    FieldItem fi = new FieldItem((CodeVariable)ce);
                    this.Members.Add(fi);
                }
            }
        }

        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public override void MakeHtml()
        {
            StreamWriter sw = new StreamWriter(this.FileName, false, Encoding.UTF8);
            sw.WriteLine("<html><head><title>{0} enum</title></head><body>", this.FullName);
            sw.WriteLine(Item.makeHeader());
            sw.WriteLine("<h2>{0} enum</h2>", this.Name);
            sw.WriteLine("<P>");
            sw.WriteLine(this.makeAttrHtmlString());
            sw.WriteLine("<b>{0} {1}</b>", this.Access, this.FullName);
            sw.WriteLine("</P>");
            sw.Write(this.XmlMakeDescription(false, false, false));
            //only one file for enum
            if (this.Members.Count > 0)
            {
                sw.WriteLine("<h3>Members</h3>");
                //foreach (FieldItem ci in this.Members)
                //{
                //    sw.WriteLine("{1} {2}<br>", ci.Name, ci.DocComment);
                //}
                this.Members.Sort(Item.sortByItemName);
                sw.Write(Item.makeTableItems("", this.Members, false));
            }
            sw.WriteLine(Item.makeFooter());
            sw.WriteLine("</body></html>");
            sw.Close();
        }
    }
}
