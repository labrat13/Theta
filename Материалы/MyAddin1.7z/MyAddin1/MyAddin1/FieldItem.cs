using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.IO;

namespace MyAddin1
{
    public class FieldItem:Item
    {
        public string Prototype;
        public string varType;
        /// <summary>
        /// Project filename
        /// </summary>
        public string ProjectFile;
        /// <summary>
        /// Code text for field
        /// </summary>
        public string codeText;
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="cv"></param>
        public FieldItem(CodeVariable cv)
        {
            //Access
            this.MakeAccessString(cv.Access, cv.IsShared, false, false, false, cv.IsConstant); //??? ��������
            this.parseAttributes(cv.Attributes);
            this.DocComment = cv.DocComment;
            this.ParseDocComment(cv.DocComment);
            this.FullName = cv.FullName;
            this.Name = cv.Name;
            this.ProjectFile = cv.ProjectItem.Name;
            this.Prototype = cv.get_Prototype((int)(vsCMPrototype.vsCMPrototypeType | vsCMPrototype.vsCMPrototypeParamTypes | vsCMPrototype.vsCMPrototypeParamNames));//void Main(string[] args)
            this.varType = cv.Type.AsFullName;
            this.codeText = this.getCodeText((CodeElement)cv);
        }

        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public override void MakeHtml()
        {
            StreamWriter sw = new StreamWriter(this.FileName, false, Encoding.UTF8);
            sw.WriteLine("<html><head><title>{0} field</title></head><body>", this.FullName);
            sw.WriteLine(Item.makeHeader());
            sw.WriteLine("<h1>{0}</h1>", this.Name);
            sw.WriteLine("<P>");
            sw.WriteLine(this.makeAttrHtmlString());
            sw.WriteLine("<b>{0} {1}</b>", this.Access, Item.makeHTMLsafe(this.Prototype));
            sw.WriteLine("</P>");
            sw.Write(this.XmlMakeDescription(false, false, false));//write unit description from doc comment
            sw.WriteLine(this.makeHTMLcode(this.codeText));
            sw.WriteLine(Item.makeFooter());
            sw.WriteLine("</body></html>");
            sw.Close();

        }
    }
}
