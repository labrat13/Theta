using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;

namespace MyAddin1
{
    public class ParamItem:Item
    {
        /// <summary>
        /// argument type
        /// </summary>
        public string argType;
        /// <summary>
        /// Default constructor
        /// </summary>
        public ParamItem(CodeParameter cp)
        {
            this.Access = ""; //no access for params
            this.parseAttributes(cp.Attributes);
            this.argType = cp.Type.AsFullName;
            this.DocComment = cp.DocComment;
            this.ParseDocComment(cp.DocComment);
            this.FullName = cp.FullName;
            this.Name = cp.Name;
        }
        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public override void MakeHtml()
        {
        }
    }
}
