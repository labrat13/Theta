using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using System.IO;

namespace MyAddin1
{
    public class NspaceItem: Item
    {
        public List<Item> Classes;
        public List<Item> Enums;
        public List<Item> Delegates;
        public List<Item> Interfaces;

        /// <summary>
        /// Default constructor
        /// </summary>
        public NspaceItem(CodeNamespace cn)
        {
            Classes = new List<Item>();
            Enums = new List<Item>();
            this.Access = "";
            this.Attributes = new List<string>();
            this.DocComment = cn.DocComment;
            this.ParseDocComment(cn.DocComment);
            this.FullName = cn.FullName;
            this.Name = cn.Name;
            
        }

        /// <summary>
        /// Add members to namespace
        /// </summary>
        /// <param name="cel"></param>
        public void AddMembers(CodeElements cel)
        {
            foreach (CodeElement ce in cel)
            {
                if (ce.Kind == vsCMElement.vsCMElementClass)
                {
                    ClassItem ci = new ClassItem((CodeClass)ce);
                    this.Classes.Add(ci);
                }
                else if (ce.Kind == vsCMElement.vsCMElementEnum)
                {
                    EnumItem ei = new EnumItem((CodeEnum)ce);
                    this.Enums.Add(ei);
                }
            }

        }
        /// <summary>
        /// Make HTML file from item
        /// </summary>
        /// <returns></returns>
        public override void MakeHtml()
        {
            StreamWriter sw = new StreamWriter(this.FileName, false, Encoding.UTF8);
            sw.WriteLine("<html><head><title>{0} namespace</title></head><body>", this.FullName);
            sw.WriteLine(Item.makeHeader());
            sw.WriteLine("<h2>{0} namespace</h2>", this.Name);
            sw.WriteLine("<P>");
            sw.WriteLine(this.makeAttrHtmlString());
            sw.WriteLine("<B>{0}</B>", this.FullName);
            sw.WriteLine("</P>");
            sw.Write(this.XmlMakeDescription(false, false, false));//write unit description from doc comment
            if (this.Classes.Count > 0)
            {
                sw.WriteLine("<h3>Classes</h3>");
                this.Classes.Sort(Item.sortByItemName);
                sw.Write(Item.makeTableItems("", this.Classes, true));
                foreach (ClassItem ci in this.Classes)
                {
                    //sw.WriteLine("<a href=\"{0}\">{1}</a> {2}<br>", ci.FileName, ci.Name, ci.getSummary());
                    ci.MakeHtml();
                }
            }
            if (this.Enums.Count > 0)
            {
                sw.WriteLine("<h3>Enums</h3>");
                this.Enums.Sort(Item.sortByItemName);
                sw.Write(Item.makeTableItems("", this.Enums, true));
                foreach (EnumItem ci in this.Enums)
                {
                    //sw.WriteLine("<a href=\"{0}\">{1}</a> {2}<br>", ci.FileName, ci.Name, ci.getSummary());
                    ci.MakeHtml();
                }                
            }
            sw.WriteLine(Item.makeFooter());
            sw.WriteLine("</body></html>");
            sw.Close();
        }


    }
}
