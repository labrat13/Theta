using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using EnvDTE;

namespace MyAddin1
{
    public class SolItem
    {
        /// <summary>
        /// Solution name
        /// </summary>
        public string Name;
        /// <summary>
        /// solution index file directory
        /// </summary>
        private string filePath;
        /// <summary>
        /// Namespaces
        /// </summary>
        public List<Item> Namespaces;
        //constructor
        public SolItem()
        {
            Namespaces = new List<Item>();
        }
        
        /// <summary>
        /// Set file pathes and create directories for html file generation
        /// </summary>
        /// <param name="initialDir">initial dir for docs. Must be accessible for writing.</param>
        private void SetFilePathes(string initialDir)
        {
            int num = 0;//file counter
            //create index file name as solution name
            this.filePath = Path.ChangeExtension(Path.GetFileName(Name), ".html");
            this.filePath = Path.Combine(initialDir, this.filePath);
            //for all namespaces in solution
            foreach (NspaceItem it in Namespaces)
            {
                string pathStr = Path.Combine(initialDir, it.Name);
                Directory.CreateDirectory(pathStr);
                it.FileName = Path.Combine(pathStr, "index.html");
                //Classes
                foreach (ClassItem ci in it.Classes)
                {
                    ci.FileName = Path.Combine(pathStr, String.Format("{0}{1}.html", ci.Name, num));
                    num++;
                    //one file for one field
                    foreach (FieldItem fi in ci.Fields)
                    {
                        fi.FileName = Path.Combine(pathStr, String.Format("{0}{1}.html", ci.Name, num));
                        num++;
                    }
                    //one file for one function
                    foreach (FuncItem fi in ci.Functions)
                    {
                        fi.FileName = Path.Combine(pathStr, String.Format("{0}{1}.html", ci.Name, num));
                        num++;
                    }
                    //one file for one property
                    foreach (PropItem fi in ci.Properties)
                    {
                        fi.FileName = Path.Combine(pathStr, String.Format("{0}{1}.html", ci.Name, num));
                        num++;
                    }
                }
                //Enums
                foreach (EnumItem ci in it.Enums)
                {
                    ci.FileName = Path.Combine(pathStr, String.Format("{0}{1}.html", ci.Name, num));
                    num++;
                    //only one file for enum
                }
            }

        }
        
        /// <summary>
        /// Scan project unit
        /// </summary>
        /// <param name="fcm">file code model for unit</param>
        public void ScanPrjUnit(FileCodeModel fcm)
        {
            foreach (CodeElement cel in fcm.CodeElements)
            {
                if (cel.Kind == vsCMElement.vsCMElementNamespace)
                {
                    CodeNamespace cn = (CodeNamespace)cel;
                    //if namespace not exists, create new. If already exists, add extra.
                    NspaceItem cnn = getNamespace(cn.Name);
                    if (cnn == null)
                    {
                        cnn = new NspaceItem(cn);
                        cnn.AddMembers(cn.Members);
                        this.Namespaces.Add(cnn);
                    }
                    else
                    {
                        cnn.AddMembers(cn.Members);
                    }

                }

            }

        }
        /// <summary>
        /// get namespace item by namespace name
        /// </summary>
        /// <param name="name">namespace name</param>
        /// <returns>item or null</returns>
        private NspaceItem getNamespace(string name)
        {
            NspaceItem res = null;
            foreach(NspaceItem ni in this.Namespaces)
                if (String.Equals(ni.Name, name)) { res = ni; break; }
            return res;
        }
        /// <summary>
        /// Make html documentation files for solution
        /// </summary>
        /// <param name="initialDir">initial dir for documentation</param>
        public void makeHtml(string initialDir)
        {
            SetFilePathes(initialDir);

            StreamWriter sw = new StreamWriter(this.filePath, false, Encoding.UTF8);
            sw.WriteLine("<html><head><title>{0} solution</title></head><body>", this.Name);
            sw.WriteLine(Item.makeHeader());
            sw.WriteLine("<h2>{0} solution</h2>", this.Name);

            if (this.Namespaces.Count > 0)
            {
                sw.WriteLine("<h3>Namespaces</h3>");
                this.Namespaces.Sort(Item.sortByItemName);
                sw.Write(Item.makeTableItems("", this.Namespaces, true));
                foreach (NspaceItem ni in this.Namespaces)
                    ni.MakeHtml();
            }

            sw.WriteLine(Item.makeFooter());
            sw.WriteLine("</body></html>");
            sw.Close();
        }

    }
}
