﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class ИнтерпретаторЛога
    {
        public ИнтерпретаторЛога()
        {
            throw new System.NotImplementedException();
        }
    }
}
