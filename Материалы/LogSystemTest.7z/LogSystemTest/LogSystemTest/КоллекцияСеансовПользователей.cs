﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class КоллекцияСеансовПользователей
    {
        /// <summary>
        /// Список консолей пользователей - список сеансов пользователей.
        /// </summary>
        private List<КонсольПользователя> m_UserConsoleList;
        /// <summary>
        /// Конструктор
        /// </summary>
        public КоллекцияСеансовПользователей()
        {
            m_UserConsoleList = new List<КонсольПользователя>();
        }

        /// <summary>
        /// NT-Получить консоль пользователя по его ИдентификаторАгента
        /// </summary>
        /// <param name="идентификаторАгента">Название пользователя, символы в любом регистре</param>
        /// <param name="throwsException">Выбрасывать исключение или вернуть null?</param>
        /// <returns>Возвращает объект консоли или null, если не найден.</returns>
        internal КонсольПользователя ПолучитьКонсоль(string идентификаторАгента, bool throwsException)
        {
            //стандартный цикл foreach перебора элементов списка
            //возвращаем первый (так как имена пользователей уникальные) соответствующий условию элемент списка
            КонсольПользователя result = null;
            foreach (КонсольПользователя con in this.m_UserConsoleList)
            {
                if (String.Equals(con.ИдентификаторАгента, идентификаторАгента, StringComparison.OrdinalIgnoreCase))
                {
                    result = con;
                    break;
                }
            }

            //просто вернуть результат или выбросить исключение?
            if ((throwsException) && (result == null))
                throw new Exception(String.Format("Пользователь \"{0}\" не существует", идентификаторАгента));

            return result;
        }

        /// <summary>
        /// NT-Добавить объект КонсольПользователя в коллекцию.
        /// Выдает исключение, если пользователь с таким именем уже существует
        /// </summary>
        /// <param name="con">Консоль пользователя</param>
        internal void ДобавитьКонсоль(КонсольПользователя con)
        {
            //проверить что пользователя с таким именем еще не существует
            String username = con.ИдентификаторАгента;
            if (this.ПолучитьКонсоль(username, false) != null)
                throw new Exception(String.Format("Пользователь \"{0}\" уже существует", username));
            //добавить консоль в список
            this.m_UserConsoleList.Add(con);

            return;
        }



    }
}
