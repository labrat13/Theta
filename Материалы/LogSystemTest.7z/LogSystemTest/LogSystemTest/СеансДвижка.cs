﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class СеансДвижка
    {
        public СеансДвижка()
        {
            throw new System.NotImplementedException();
        }
    }
}
