﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LogSystemTest
{
    /// <summary>
    /// Исключение архитектуры движка
    /// Обычно сообщает о превышении установленных ограничений.
    /// </summary>
    public class EngineArchitectureException : Exception
    {
        //todo: переименовать исключение в соответствии с его функцией: сообщение о превышении установленных пределов.
        //Пусть показывает пользователю название предела в НастройкиСолюшена. И оно должно совпадать с именем в файле настроек солюшена.
        public EngineArchitectureException() : base()
        {
        }

        public EngineArchitectureException(String message) : base(message)
        {
        }

    }
}
