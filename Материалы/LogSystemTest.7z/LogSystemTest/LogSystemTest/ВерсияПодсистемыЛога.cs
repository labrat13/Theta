﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class ВерсияПодсистемыЛога
    {

        public ВерсияПодсистемыЛога()
        {
            throw new System.NotImplementedException();
        }
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="versionString">Строка версии, только цифры. Пример: 1.0.24.0546</param>
        public ВерсияПодсистемыЛога(String versionString)
        {
            if (!TryParse(versionString))
                throw new ArgumentException("Invalid format in: " + versionString, "versionString");
        }

        /// <summary>
        /// Можно ли указанную версию считать эквивалентной текущей версии.
        /// </summary>
        /// <param name="ver"></param>
        /// <returns></returns>
        public bool IsEqualVersion(ВерсияПодсистемыЛога ver)
        {
            return false;//TODO: Add code here...
        }
        /// <summary>
        /// Можно ли указанную версию считать допустимой для работы с ней.
        /// </summary>
        /// <param name="ver"></param>
        /// <returns></returns>
        public bool IsCompatibleVersion(ВерсияПодсистемыЛога ver)
        {
            return false;//TODO: Add code here...
        }

        public bool TryParse(String versionString)
        {
            return false;//TODO: Add code here...
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
