﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace LogSystemTest
{
    public class НастройкиСолюшена
    {
        
        public void Load()
        {
            //load settings
            LogSystemTest.Properties.Settings.Default.Reload();
            CheckAndPatchValues();
            //TODO: вписать настройки в переменные здесь.
        }

        public void Save()
        {
            //TODO: сохранить настройки здесь.
            LogSystemTest.Properties.Settings.Default.Save();
        }
        /// <summary>
        /// Проверить и исправить значения параметров в допустимые пределы
        /// </summary>
        public void CheckAndPatchValues()
        {
            if (!Directory.Exists(this.КаталогЛога))
                throw new Exception("Путь КаталогЛога не существует");

            if (!Directory.Exists(this.КаталогСолюшена))
                throw new Exception("Путь КаталогСолюшена не существует");

            if(String.IsNullOrEmpty(this.РасширениеФайлаЛога))
                throw new Exception("Значение РасширениеФайлаЛога не указано");

            if((this.МаксимальноеЧислоВложенныхТранзакций < 1) || (this.МаксимальноеЧислоВложенныхТранзакций > 65536))
                throw new Exception("Значение МаксимальноеЧислоВложенныхТранзакций не находится в допустимых пределах");

            long maxsizelimit = 2147418112; // 2гб = 2048 * 1024 * 1024 минус 64кб запаса, чтобы не превысить 2Гб на файл.
            long minsizelimit = 64 * 1024 * 1024; // 64Мб
            if ((this.ПределРазмераФайлаЛога < minsizelimit) || (this.ПределРазмераФайлаЛога > maxsizelimit))
                throw new Exception("Значение ПределРазмераФайлаЛога не находится в допустимых пределах");

            if ((this.ПределКоличестваФайловЛогаВСеансе < 1) || (this.ПределКоличестваФайловЛогаВСеансе > 8192))
                throw new Exception("Значение ПределКоличестваФайловЛогаВСеансе не находится в допустимых пределах");

            return;
        }

        public string КаталогЛога
        {
            get { return LogSystemTest.Properties.Settings.Default.LogFolderPath; }
            set { LogSystemTest.Properties.Settings.Default.LogFolderPath = value; }
        }

        public string КаталогСолюшена
        {
            get { return LogSystemTest.Properties.Settings.Default.SolutionFolderPath; }
            set { LogSystemTest.Properties.Settings.Default.SolutionFolderPath = value; }
        }

        public string РасширениеФайлаЛога
        {
            get { return LogSystemTest.Properties.Settings.Default.LogFileExtension; }
            set { LogSystemTest.Properties.Settings.Default.LogFileExtension = value; }
        }

        public int МаксимальноеЧислоВложенныхТранзакций
        {
            get { return LogSystemTest.Properties.Settings.Default.TransactionLimit; }
            set { LogSystemTest.Properties.Settings.Default.TransactionLimit = value; }
        }

        public long ПределРазмераФайлаЛога
        {
            get { return LogSystemTest.Properties.Settings.Default.MaxLogFileSize; }
            set { LogSystemTest.Properties.Settings.Default.MaxLogFileSize = value; }
        }

        public int ПределКоличестваФайловЛогаВСеансе
        {
            get { return LogSystemTest.Properties.Settings.Default.MaxLogFileCount; }
            set { LogSystemTest.Properties.Settings.Default.MaxLogFileCount = value; }
        }


        //todo: Добавить проверку границ значений добавляемых настроек в функцию CheckAndPatchValues()!
    }
}
