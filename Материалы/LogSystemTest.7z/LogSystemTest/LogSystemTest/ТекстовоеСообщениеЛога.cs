﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    /// <summary>
    /// Текстовая версия сообщения лога для КаналСообщенийЛога.
    /// </summary>
    public class ТекстовоеСообщениеЛога
    {
        private string m_message;

        /// <summary>
        /// ИдентификаторАгента пользователя, создавшего сообщение лога.
        /// </summary>
        private string m_username;


        public string Message
        {
            get { return m_message; }
            set { m_message = value; }
        }

        public ТекстовоеСообщениеЛога()
        {
            throw new System.NotImplementedException();
        }

        public ТекстовоеСообщениеЛога(string msg)
        {
            m_message = msg;
        }

        /// <summary>
        /// ИдентификаторАгента пользователя, создавшего сообщение лога.
        /// </summary>
        public string Username
        {
            get { return m_username; }
            set { m_username = value; }
        }


        public override string ToString()
        {
            //для отладки возвращаем пока фиксированную строку
            return m_message;
        }

    }



}
