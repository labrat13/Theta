﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace LogSystemTest
{
    public class ФайлЛогаСолюшена
    {
        private string m_filename;

        private string m_filepath;
        /// <summary>
        /// НомерФайлаЛога
        /// </summary>
        private int m_номерФайла;


        public ФайлЛогаСолюшена()
        {
            throw new System.NotImplementedException();
        }
        /// <summary>
        /// Имя файла без пути
        /// </summary>
        public string Filename
        {
            get { return m_filename; }
            //set { m_filename = value; }
        }

        /// <summary>
        /// НомерФайлаЛога
        /// </summary>
        public int НомерФайла
        {
            get { return m_номерФайла; }
            set { m_номерФайла = value; }
        }

        /// <summary>
        /// NT-Создать имя файла лога в формате ГГГГММДД-ЧЧММСС-ННН.ррр 
        /// </summary>
        /// <param name="sessionId">Строка идентификатора сеанса Движка</param>
        /// <param name="fileId">номер файла лога от 0 до 999</param>
        /// <param name="fileext">расширение файла лога без точки</param>
        /// <returns>Возвращает имя файла лога в виде строки вида: 20171101-221741-001.log</returns>
        internal static string СоздатьИмяФайла(string sessionId, int fileId, string fileext)
        {
            StringBuilder sb = new StringBuilder(sessionId);
            sb.Append('-');
            sb.Append(fileId.ToString("D3"));
            sb.Append('.');
            sb.Append(fileext);

            return sb.ToString();
        }

        /// <summary>
        /// NT-Разделить имя файла на части, не выбрасывая исключений.
        /// </summary>
        /// <param name="filename">Имя файла с расширением, но без пути</param>
        /// <param name="sessionId">Ссылка на строку, принимающую  идентификатор сеанса Движка</param>
        /// <param name="fileId">Ссылка на переменную, принимающую номер файла лога</param>
        /// <param name="fileextension">Ссылка на строку, принимающую расширение файла лога</param>
        /// <returns>Возвращает True, если формат правильный и разделение прошло успешно, False в противном случае</returns>
        internal static bool TryParseИмяФайла(string filename, out string sessionId, out int fileId, out string fileextension)
        {
            //нельзя точно сказать, какой длины будет расширения файла - оно определяется пользователем.
            //if (filename.Length < 20)
            //{
            //    sessionId = "";
            //    fileId = 0;
            //    fileextension = "";
            //    return false;
            //}
            //if ((filename[8] != '-') || (filename[15] != '-') || (filename[19] != '.'))
            //    return false;
            ////разделяем на части
            //sessionId = filename.Substring(0, 15);
            //fileextension = filename.Substring(20);
            //return Int32.TryParse(filename.Substring(16, 3), out fileId);

            //инверсия проверок для более компактного кода
            if ((filename.Length >= 20) && (filename[8] == '-') && (filename[15] == '-') && (filename[19] == '.'))
            {
                //разделяем на части
                sessionId = filename.Substring(0, 15);
                fileextension = filename.Substring(20);
                return Int32.TryParse(filename.Substring(16, 3), out fileId);
            }
            else
            {
                sessionId = "";
                fileId = 0;
                fileextension = "";
                return false;
            }
        }

        /// <summary>
        /// NR-Открыть файл для записи, не монопольно, и чтения.
        /// </summary>
        internal void OpenForWriting()
        {
            //открыть файл для записи и чтения, перемотать позицию записи в конец файла
            throw new NotImplementedException();
        }

        /// <summary>
        /// NR-Открыть файл для чтения только.
        /// </summary>
        internal void OpenForReading()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// NR-Закрыть файл
        /// </summary>
        private void Close()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// NR-Создать файл лога, но не открывать его. Потом пользователь сам откроет его как ему надо
        /// </summary>
        internal static ФайлЛогаСолюшена Create(string folderPath, string filename)
        {
            ФайлЛогаСолюшена result = new ФайлЛогаСолюшена();
            result.m_filepath = Path.Combine(folderPath, filename);
            result.m_filename = filename;
            Utilities.СоздатьФайлБезИндексирования(result.m_filepath);
            //тут вывести в файл лога шапку  с всеми нужными свойствами и закрыть файл лога
            result.OpenForWriting();
            result.WriteFileHeader();
            result.Close();//а может, сразу уже открытым отдавать? все равно же его открывать - он же создается пустой новый для записи.


            throw new NotImplementedException();//TODO: Add code here...
        }
        /// <summary>
        /// NR-Вывести в открытый файл ШапкаФайлаЛога
        /// </summary>
        private void WriteFileHeader()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// NR-Функция возвращает Int64 позицию записи в файл лога.
        /// </summary>
        /// <returns></returns>
        internal long ПолучитьПозициюЗаписиВКонецФайла()
        {
            //тут нужен объект потока открытого файла, чтобы перемотать позицию записи в конец и прочитать ее значение.
            throw new NotImplementedException();
        }

        internal void ДобавитьСообщениеЛога(ЗаписьЛога z)
        {
            //вписать запись в файл лога
            
            throw new NotImplementedException();
        }
    }
}
