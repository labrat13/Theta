﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class Ячейка
    {
        /// <summary>
        /// Свойство ячейки как пример для отладки системы
        /// </summary>
        private string m_title;


        /// <param name="title">Название ячейки</param>
        public Ячейка(string title)
        {
            m_title = title;
        }

        /// <summary>
        /// Свойство ячейки как пример для отладки системы
        /// </summary>
        public string Title
        {
            get { return m_title; }
            set { m_title = value; }
        }

    }
}
