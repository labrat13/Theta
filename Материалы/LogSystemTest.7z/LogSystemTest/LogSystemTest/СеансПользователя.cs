﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class СеансПользователя
    {
        /// <summary>
        /// Список транзакций пользователя
        /// </summary>
        private КоллекцияТранзакцийПользователя m_UserTransactionCollection;
        /// <summary>
        /// ИдентификаторАгента текущего СеансПользователя
        /// </summary>
        private String m_идентификаторАгента;
        /// <summary>
        /// Описание сеанса для лучшего понимания лога
        /// </summary>
        private String m_описаниеСеанса;
        /// <summary>
        /// ИдентификаторЗаписиЛога о начале СеансПользователя. Считается идентификатором СеансПользователя как первой транзакции.
        /// </summary>
        private ИдентификаторЗаписиЛога m_sessionRecordId;


        /// <summary>
        /// NR-
        /// </summary>
        /// <param name="идентификаторАгента">ИдентификаторАгента текущего СеансПользователя</param>
        public СеансПользователя(String идентификаторАгента)
        {
            m_идентификаторАгента = идентификаторАгента;
            m_описаниеСеанса = String.Empty;
            m_UserTransactionCollection = new КоллекцияТранзакцийПользователя();

            //TODO: Add code here...
        }

        #region Properties
        
        /// <summary>
        /// Получить ИдентификаторАгента текущего СеансПользователя
        /// </summary>
        internal String ИдентификаторАгента
        {
            get { return this.m_идентификаторАгента; }
            set { this.m_идентификаторАгента = value; }
        }

        /// <summary>
        /// Описание сеанса для лучшего понимания лога
        /// </summary>
        internal String ОписаниеСеанса
        {
            get { return this.m_описаниеСеанса; }
            set { this.m_описаниеСеанса = value; }
        }

        /// <summary>
        /// ИдентификаторЗаписиЛога о начале СеансПользователя. Считается идентификатором СеансПользователя как первой транзакции.
        /// </summary>
        internal ИдентификаторЗаписиЛога SessionRecordId
        {
            get { return m_sessionRecordId; }
            set { m_sessionRecordId = value; }
        }

        #endregion

        /// <summary>
        /// NT-Получить число активных вложенных транзакций в сеансе пользователя.
        /// </summary>
        /// <returns></returns>
        internal int ПолучитьЧислоТранзакций()
        {
            return this.m_UserTransactionCollection.ПолучитьЧислоТранзакций();
        }
        /// <summary>
        /// дозаполнить объект транзакции и добавить ее в сеанс
        /// </summary>
        /// <param name="tran"></param>
        internal void НачатьТранзакцию(ТранзакцияПользователя tran)
        {
            //эта функция должна дозаполнить объект транзакции, вписать ее в свой список транзакций и сделать ее текущей транзакцией.
            tran.РодительскаяТранзакция = this.m_UserTransactionCollection.getLastElement();//получить текущую транзакцию.
            tran.Состояние = СостояниеТранзакции.Начата;
            //добавить в конец списка транзакций пользователя
            this.m_UserTransactionCollection.Add(tran);

            //Add code here...
            return;
        }
    }
}
