﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public enum СостояниеТранзакции
    {
        /// <summary>
        /// Состояние неизвестное или ошибочное
        /// </summary>
        Неизвестно = 0,
        /// <summary>
        /// Транзакция начата
        /// </summary>
        Начата = 1,
        /// <summary>
        /// Транзакция завершена
        /// </summary>
        Завершена = 2,
        /// <summary>
        /// Транзакция отменена
        /// </summary>
        Отменена = 3,
    }
}
