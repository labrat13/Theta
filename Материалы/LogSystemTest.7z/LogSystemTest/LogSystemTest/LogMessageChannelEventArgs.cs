﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class LogMessageChannelEventArgs : EventArgs
    {
        /// <summary>
        /// Объект сообщения лога
        /// </summary>
        private ТекстовоеСообщениеЛога m_СообщениеЛога;

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="сообщениеЛога"></param>
        public LogMessageChannelEventArgs(ТекстовоеСообщениеЛога сообщениеЛога)
        {
            this.m_СообщениеЛога = сообщениеЛога;
        }

        /// <summary>
        /// Объект сообщения лога
        /// </summary>
        public ТекстовоеСообщениеЛога СообщениеЛога
        {
            get { return m_СообщениеЛога; }
            set { m_СообщениеЛога = value; }
        }

    }
}
