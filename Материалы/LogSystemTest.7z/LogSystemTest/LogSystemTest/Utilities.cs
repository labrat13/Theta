﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LogSystemTest
{
    internal class Utilities
    {
        internal static void СоздатьКаталогБезИндексирования(string m_ПутьПапкаСеансаЛога)
        {
            throw new NotImplementedException();
        }

        internal static void СоздатьФайлБезИндексирования(string p)
        {
            throw new NotImplementedException();
        }
    }
}
