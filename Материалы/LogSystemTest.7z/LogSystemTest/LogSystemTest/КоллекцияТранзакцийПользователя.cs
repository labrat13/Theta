﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class КоллекцияТранзакцийПользователя
    {
        /// <summary>
        /// Список транзакций пользователя. 
        /// Новые Транзакции  добавлять в конец списка.
        /// </summary>
        private List<ТранзакцияПользователя> m_UserTransactionList;
        
        public КоллекцияТранзакцийПользователя()
        {
            m_UserTransactionList = new List<ТранзакцияПользователя>();
            //TODO: Add code here...

        }
        /// <summary>
        /// NT-Получить число активных вложенных транзакций
        /// </summary>
        /// <returns></returns>
        internal int ПолучитьЧислоТранзакций()
        {
            return this.m_UserTransactionList.Count;
        }
        /// <summary>
        /// NT-Получить текущую транзакцию как последний элемент списка транзакций
        /// </summary>
        /// <returns></returns>
        internal ТранзакцияПользователя getLastElement()
        {
            int count = this.m_UserTransactionList.Count;
            if (count == 0)
                return null;
            else
                return this.m_UserTransactionList[count - 1];
        }
        /// <summary>
        /// NT-Добавить транзакцию в конец списка, сделав ее таким образом текущей транзакцией.
        /// </summary>
        /// <param name="tran"></param>
        internal void Add(ТранзакцияПользователя tran)
        {
            this.m_UserTransactionList.Add(tran);
            return;
        }
    }
}
