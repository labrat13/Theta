﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class ИдентификаторСеансаПользователя
    {
        public ИдентификаторСеансаПользователя()
        {
            throw new System.NotImplementedException();
        }
    }
}
