﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class ИтераторЛога
    {
        public ИтераторЛога()
        {
            throw new System.NotImplementedException();
        }
    }
}
