﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class ТранзакцияПользователя
    {

        /// <summary>
        /// Ссылка на родительскую транзакцию
        /// </summary>
        private ТранзакцияПользователя m_РодительскаяТранзакция;

        /// <summary>
        /// Ссылка на сеанс пользователя
        /// </summary>
        private СеансПользователя m_СеансПользователя;
        /// <summary>
        /// Название транзакции
        /// </summary>
        private String m_Название;

        /// <summary>
        /// Описание транзакции для отладки
        /// </summary>
        private String m_Описание;
        /// <summary>
        /// Состояние транзакции: Начата, Завершена, Отменена
        /// </summary>
        private СостояниеТранзакции m_Состояние;

        public ТранзакцияПользователя()
        {
            
            throw new System.NotImplementedException();
        }

        #region Properties
        /// <summary>
        /// Название транзакции
        /// </summary>
        public String Название
        {
            get { return m_Название; }
            set { m_Название = value; }
        }

        /// <summary>
        /// Описание транзакции для отладки
        /// </summary>
        public String Описание
        {
            get { return m_Описание; }
            set { m_Описание = value; }
        }

        /// <summary>
        /// Ссылка на родительскую транзакцию
        /// </summary>
        public ТранзакцияПользователя РодительскаяТранзакция
        {
            get { return m_РодительскаяТранзакция; }
            set { m_РодительскаяТранзакция = value; }
        }

        /// <summary>
        /// Ссылка на сеанс пользователя
        /// </summary>
        public СеансПользователя СеансПользователя
        {
            get { return m_СеансПользователя; }
            set { m_СеансПользователя = value; }
        }

        #endregion

        /// <summary>
        /// Состояние транзакции: Начата, Завершена, Отменена
        /// </summary>
        public СостояниеТранзакции Состояние
        {
            get { return m_Состояние; }
            set { m_Состояние = value; }
        }



        public override string ToString()
        {
            return base.ToString();
        }
    }
}
