﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogSystemTest
{
    public class ИдентификаторЗаписиЛога
    {
        private Int64 m_КодЗаписиЛога;

        private Int64 m_КодСеансаЛога;

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        public ИдентификаторЗаписиЛога()
        {
            
        }
        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="кодЗаписиЛога"></param>
        /// <param name="кодСеансаЛога"></param>
        public ИдентификаторЗаписиЛога(Int64 кодЗаписиЛога, Int64 кодСеансаЛога)
        {
            m_КодЗаписиЛога = кодЗаписиЛога;
            m_КодСеансаЛога = кодСеансаЛога;
        }

        public Int64 КодЗаписиЛога
        {
            get { return m_КодЗаписиЛога; }
            set { m_КодЗаписиЛога = value; }
        }

        public Int64 КодСеансаЛога
        {
            get { return m_КодСеансаЛога; }
            set { m_КодСеансаЛога = value; }
        }

        public override string ToString()
        {
            return m_КодСеансаЛога.ToString() + ":" + m_КодЗаписиЛога.ToString();
        }

    }
}
