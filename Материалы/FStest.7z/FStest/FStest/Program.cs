﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security.AccessControl;
using System.Globalization;

namespace FStest
{
    class Program
    {
        

        static void Main(string[] args)
        {
            
            //create file c://00//00//00//00000000.ext
            //File.Copy("C:\\Text.txt", "C:\\A00\\B00\\C00\\00000000.txt"); //fail
            //File.Create("C:\\A00\\B00\\C00\\00000001.txt"); //fail
            //create directory then copy file
            //Directory.CreateDirectory("C:\\A00\\B00\\C00\\");//ok
            //File.Copy("C:\\Text.txt", "C:\\A00\\B00\\C00\\00000000.txt"); //ок
            //Random r = new Random();
            //UInt32 id;
            //for(int i = 0; i < 65536; i++)
            //{
            //    id = (uint)r.Next(1, Int32.MaxValue);
            //    //generate names from uint
            //    Console.WriteLine(String.Format("FileId is {0}", id));
            //    string[] names = generateNames(id);
            //    //get filename
            //    string filepath = "C:\\Text.txt";
            //    //create new pathname for copy/move operation
            //    string ext = Path.GetExtension(filepath);
            //    string respath = Path.Combine("C:\\", Path.ChangeExtension(names[3], ext));
            //    Console.WriteLine(String.Format("Path is {0}", respath));
            //    //move or copy file
            //    //create directory then copy file
            //    Directory.CreateDirectory(Path.GetDirectoryName(respath));//ok
            //    File.Copy("C:\\Text.txt", respath); //ок
            
            //}
            //test - get max file
            string dir = "c:\\test1\\test\\";
            Console.WriteLine("TimeStamp is " + DateTime.Now.ToLongTimeString());
            //get max file id
            UInt32 res = getMaxFileId(dir);
            Console.WriteLine(String.Format("MaxFileId is {0}", res));
            Console.WriteLine("TimeStamp is " + DateTime.Now.ToLongTimeString());
            long s = getDirectorySize(dir);
            Console.WriteLine(String.Format("DirSize is {0}", s));
            Console.WriteLine("TimeStamp is " + DateTime.Now.ToLongTimeString());
            s = getDirectoryFilesCount(dir);
            Console.WriteLine(String.Format("DirCount is {0}", s));
            Console.WriteLine("TimeStamp is " + DateTime.Now.ToLongTimeString());

            uint fid = 0x474F9DBF;
            if(isFileExists(fid))
                Console.WriteLine(String.Format("FileExists: {0}", fid));



            Console.ReadLine();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Returns array of directory names and file pathname without extension</returns>
        static string[] generateNames(UInt32 id)
        {
            //1) get string representation of id
            string ids = String.Format("{0:X8}", id);

            string[] res = new String[4];
            //2) get first dir name
            res[0] = String.Concat("A", ids.Substring(0, 2));
            //3) get second dir name
            res[1] = String.Concat("B", ids.Substring(2, 2));
            //4) get third dir name
            res[2] = String.Concat("C", ids.Substring(4, 2));
            //5) get file path
            res[3] = Path.Combine(Path.Combine(res[0], res[1]), Path.Combine(res[2], ids));
          
            return res;
        }

        /// <summary>
        /// Get max of file id
        /// </summary>
        /// <param name="rootdir">Root directory</param>
        /// <returns>Max file id number or 0 if not found</returns>
        /// <remarks>
        /// This function removes visited dummy directories, but not all.
        /// For speed, need to remove all dummy directories in optimization service.
        /// </remarks>
        static UInt32 getMaxFileId(string rootdir)
        {
            //1) search max folder at level A
            //if no folders, return 0
            //2) search max folder at level B
            //if no folders, delete current folder A, restart search
            //3) search max folder at level C
            //if no folders, delete current folder B, restart search
            //4) search max file in folder C
            //if no files, delete current folder C, restart search
            //5) convert filename to uint and return
            
            //TODO: Сейчас если папка пустая, она удаляется, и поиск запускается с самого начала. Надо бы подумать и если можно, то переделать.
            string maxFilename = null;
            while(true)
            {
                string pathA = getMaxFolderA(rootdir);
                if (pathA == null) break;   //
                string pathB = getMaxFolderB(pathA);
                if (pathB == null)
                {
                    //folder A is dummy
                    //remove folder A, restart search
                    Directory.Delete(pathA, true);
                    continue;
                }
                else
                {
                    string pathC = getMaxFolderC(pathB);
                    if (pathC == null)
                    {
                        //folder B is dummy
                        //remove folder B, restart search
                        Directory.Delete(pathB, true);
                        continue;
                    }
                    else
                    {
                        maxFilename = getMaxFileName(pathC);
                        if (maxFilename == null)
                        {
                            //folder C is dummy
                            //remove folder C, restart search
                            Directory.Delete(pathC, true);
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                }

            }
            //maxFileName is null or filename
            if (String.IsNullOrEmpty(maxFilename)) return 0;
            //remove extensions
            string ff = maxFilename.Substring(0, 8);
            //parse filename to uint
            uint result;
            if (UInt32.TryParse(ff, System.Globalization.NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture,  out result)) return result;
            return 0;
        }

        /// <summary>
        /// Get max name of folder at A level
        /// </summary>
        /// <param name="dirpath"></param>
        /// <returns>Return null if no folders. Return folder name otherwise.</returns>
        static string getMaxFolderA(string dirpath)
        {
            //get max of level A folders - named Axx only
            string[] sar = Directory.GetDirectories(dirpath, "A??");
            string max = getMaxFolderName(sar);
            return max;
        }

        /// <summary>
        /// Get max name of folder at B level
        /// </summary>
        /// <param name="dirpath"></param>
        /// <returns>Return null if no folders. Return folder name otherwise.</returns>
        static string getMaxFolderB(string dirpath)
        {
            //get max of level A folders - named Axx only
            string[] sar = Directory.GetDirectories(dirpath, "B??");
            string max = getMaxFolderName(sar);
            return max;
        }

        /// <summary>
        /// Get max name of folder at C level
        /// </summary>
        /// <param name="dirpath"></param>
        /// <returns>Return null if no folders. Return folder name otherwise.</returns>
        static string getMaxFolderC(string dirpath)
        {
            //get max of level A folders - named Axx only
            string[] sar = Directory.GetDirectories(dirpath, "C??");
            string max = getMaxFolderName(sar);
            return max;
        }

        static string getMaxFileName(string dirpath)
        {
            //get files
            string[] sar = Directory.GetFiles(dirpath, "????????.*", SearchOption.TopDirectoryOnly);
            //find max filename
            string max = null;
            foreach (string s in sar)
            {
                string fn = Path.GetFileName(s);
                if (isValidFileName(fn))
                {
                    if (String.Compare(max, fn) < 0)
                        max = fn;
                }
            }
            return max;
        }

        /// <summary>
        /// Check that filename contains only hex symbols like hhhhhhhh.ext
        /// </summary>
        /// <param name="s">filename</param>
        /// <returns></returns>
        private static bool isValidFileName(string s)
        {
            char[] car = s.ToCharArray(0, 8);
            foreach (char c in car)
                if (!isHexDigit(c)) return false;
            return true;
        }

        private static bool isHexDigit(char c)
        {
            if (Char.IsDigit(c)) return true;
            char t = Char.ToUpper(c);
            if ((t == 'A') || (t == 'B') || (t == 'C') || (t == 'D') || (t == 'E') || (t == 'F')) return true;
            return false;
        }

        /// <summary>
        /// Get max name from 
        /// </summary>
        /// <param name="names"></param>
        /// <returns></returns>
        static string getMaxFolderName(string[] names)
        {
            if (names.Length == 0) return null;
            else
            {
                string max = names[0];
                foreach (string s in names)
                {
                    if (String.Compare(max, s) < 0)
                        max = s;
                }
                return max;
            }
        }

        /// <summary>
        /// Get directory size
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        private static long getDirSize(DirectoryInfo d)
        {
            long Size = 0;
            // Add file sizes.
            FileInfo[] fis = d.GetFiles();
            foreach (FileInfo fi in fis)
            {
                Size += fi.Length;
            }
            // Add subdirectory sizes.
            DirectoryInfo[] dis = d.GetDirectories();
            foreach (DirectoryInfo di in dis)
            {
                Size += getDirSize(di);
            }
            return (Size);
        }

        /// <summary>
        /// Get directory files count
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        private static long getDirFileCount(DirectoryInfo d)
        {
            long Count = 0;
            // Add file.
            FileInfo[] fis = d.GetFiles();
            Count += fis.Length;
            
            // Add subdirectory sizes.
            DirectoryInfo[] dis = d.GetDirectories();
            foreach (DirectoryInfo di in dis)
            {
                Count += getDirFileCount(di);
            }
            return (Count);
        }

        /// <summary>
        /// Get directory size for stats
        /// </summary>
        /// <param name="dirpath"></param>
        /// <returns></returns>
        public static long getDirectorySize(string dirpath)
        {
            DirectoryInfo di = new DirectoryInfo(dirpath);
            return getDirSize(di);
        }

        public static long getDirectoryFilesCount(string dirpath)
        {
            DirectoryInfo di = new DirectoryInfo(dirpath);
            return getDirFileCount(di);
        }

        public static bool isFileExists(uint fileId)
        {
            //Расширение файла неизвестно, поэтому ищем по имени.
            //для поиска создаем маску, и получаем по ней массив файлов с таким именем и разными расширениями.
            //Если массив не пустой, файл существует.
            string[] names = generateNames(fileId);
            string fpath = Path.Combine("c:\\test1\\test\\", names[3]);
            string folder = Path.GetDirectoryName(fpath);
            DirectoryInfo di = new DirectoryInfo(folder);
            string fmask = Path.ChangeExtension(Path.GetFileName(fpath), ".*");
            FileInfo[] fir = di.GetFiles(fmask, SearchOption.TopDirectoryOnly);
            if (fir.Length > 0) return true;
            else return false;
        
            //вообще-то лучше сделать функцию для получения FileInfo файла по ИД,
            //а потом уже что-то с ним делать - открывать, удалять, проверять наличие и свойства. 
        }

    }
}
