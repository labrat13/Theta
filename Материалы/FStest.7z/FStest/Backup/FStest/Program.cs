﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security.AccessControl;

namespace FStest
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //create file c://00//00//00//00000000.ext
            //File.Copy("C:\\Text.txt", "C:\\A00\\B00\\C00\\00000000.txt"); //fail
            //File.Create("C:\\A00\\B00\\C00\\00000001.txt"); //fail
            //create directory then copy file
            Directory.CreateDirectory("C:\\A00\\B00\\C00\\");//ok
            File.Copy("C:\\Text.txt", "C:\\A00\\B00\\C00\\00000000.txt"); //ок

            generateNames(0x22334455);
        }

        static string[] generateNames(UInt32 id)
        {
            string ids = id.ToString("H8");


            return null;
        }



    }
}
